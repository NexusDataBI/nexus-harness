---
name: nexus-ship
description: >-
  Metodologia Nexus de commit → PR → CI → merge → deploy com orçamento de
  GitHub Actions (~2000 min/mês na org). Use ao abrir/atualizar PR, mergear,
  rodar CI, fazer push em série, ou quando o usuário falar em shipping, CI
  minutes, draft PR, ou deploy após merge.
---

# nexus-ship — Commit, PR, CI, merge e deploy

Skill **global** (Nexus). Cada repo pode ter espelho em `.claude/skills/nexus-ship/`.
Deploy concreto: skill `deploy` + `.claude/deploy-profile.md` do repo.

## Por que existe

A org Free compartilha ~**2000 minutos**/mês de Actions entre Marketing Hub,
Elabore (api/web/ia) e demais repos. Push em toda branch + 3 jobs pesados +
muitos PRs WIP esgota o bucket e o CI para de iniciar (billing).

Esta skill define o **fluxo padrão** para agents não queimarem minutos.

## Princípios

1. **Validar local antes de push que dispara CI.**
2. **Um PR curto** (horas/1–2 dias), não fila de 5–10 PRs abertos.
3. **Draft = barato** (só quality). **Ready = completo** (integration + security).
4. **Push de feature não dispara CI** — só `pull_request` e `push` em `main`.
5. **Docs/skills/markdown sozinhos** não disparam CI (`paths-ignore`).
6. **Deploy só com confirmação** e perfil do repo (`/deploy`).
7. **Bucket compartilhado** — se outro repo está quente, não floodar este.

## Fluxo obrigatório (ordem)

```
local validate → commit(s) → push branch → PR draft
  → quality verde → marcar ready (CI pesado)
  → review/merge → main (CI full + deploy se workflow existir)
```

### 1. Antes de qualquer push

No repo (adapte aos scripts locais):

| Stack | Gate mínimo |
|-------|-------------|
| Next/TS (Hub) | `npm run typecheck` + testes unitários tocados (`npm test` / vitest path) |
| Rails/API | suite unitária relevante + lint do projeto |
| Qualquer | sem secrets no diff; `git status` limpo do que não vai no commit |

Se o gate local falha → **não push**. CI não é debugger pago.

### 2. Branch e commits

- Feature branch: `tipo/nome-kebab` (`feat/`, `fix/`, `chore/`).
- Conventional Commits em PT-BR; commit **só quando Rubens pedir** (regra Nexus).
- Preferir poucos commits atômicos; squash no merge se a política do repo permitir.
- Evitar sequência “fix typo” com 6 pushes — cada push em PR ready reaquece CI pesado.

### 3. Abrir / atualizar PR

1. Push da branch (`-u` se nova).
2. Abrir como **`--draft`** se ainda for WIP ou se o CI pesado ainda não deve rodar.
3. Título Conventional; body com Summary + Test plan.
4. Base: **`main`** (nunca base legada tipo `chore/initial-scaffold` salvo pedido explícito).
5. Máximo informal: **~2–3 PRs abertos por repo**. Fechar ou mergear zumbis antes de abrir outro.

**Draft → Ready:** só quando quality local/CI quality ok e a fatia está pronta para merge.
Isso dispara `integration` + `security` no Marketing Hub.

### 4. O que o CI deve fazer (padrão Hub; espelhar nos outros)

| Evento | quality | integration | security |
|--------|---------|-------------|----------|
| PR **draft** | sim | não | não |
| PR **ready** | sim | sim | sim |
| Push **main** | sim | sim | sim |
| Push feature branch | **não** | — | — |
| Só `*.md` / `docs/` / skills | **não roda** | — | — |

Obrigatório em todo workflow de CI Nexus:

```yaml
concurrency:
  group: ci-${{ github.workflow }}-${{ github.event.pull_request.number || github.ref }}
  cancel-in-progress: true

on:
  pull_request:
  push:
    branches: [main]   # NUNCA branches: ["**"]
```

### 5. Merge

- Merge só com quality (+ heavy se ready) verdes **ou** com billing bloqueado e validação local explícita aprovada pelo Rubens.
- Preferir squash se a branch tiver commits de WIP.
- Após merge: apagar branch remota se o repo fizer isso automaticamente; senão limpar.

### 6. Deploy

- Seguir skill **`deploy`**: ler `.claude/deploy-profile.md`, ecoar alvo, **confirmar**, depois agir.
- Marketing Hub: merge em `main` dispara `Deploy Production` (GHCR + VPS). Não re-disparar à toa.
- Se Actions estiver em billing fail: deploy manual na VPS só com confirmação + SHA explícito (nunca `:latest` cego).

## Checklist do agent (copiar mentalmente)

- [ ] Gate local passou
- [ ] Branch `tipo/nome`; commits pedidios
- [ ] PR draft até estar pronto
- [ ] Base = `main`
- [ ] Não abrir o 4º PR se já há 3 abertos no mesmo repo
- [ ] Ready só quando for mergear em breve
- [ ] Deploy: skill `deploy` + confirmação
- [ ] Se CI falhou por **billing** → não “fix código”; avisar admin (Billing & plans) e validar local

## Anti-padrões

- `on.push.branches: ["**"]` (duplica CI com o PR)
- Rodar Testcontainers / Semgrep / Trivy em todo push de WIP
- Abrir PR ready “para ver se passa” a cada commit de agente
- Manter PRs abertos semanas (#zumbis) re-triggerando CI
- Usar CI como substituto de `tsc`/testes locais
- Deploy sem ecoar repo/branch/VPS/containers
- Forçar re-runs em massa quando o bucket já estourou

## Quando o billing já estourou

1. Não re-rodar workflows até um admin corrigir Billing & plans.
2. Validar localmente o gate completo do repo.
3. Merge/deploy só com OK explícito do Rubens (risco aceito sem CI cloud).
4. Priorizar **um** repo quente por vez na org.

## Espelho por repo

Se o repo tiver `.claude/skills/nexus-ship/SKILL.md`, preferir essa cópia (pode citar scripts/`ci.yml` locais).
Manter alinhada com esta skill global ao mudar a política.

## Referência rápida Marketing Hub

- CI: `.github/workflows/ci.yml`
- Deploy GH: `.github/workflows/deploy.yml`
- Deploy skill: `deploy` + `.claude/deploy-profile.md`
- Host prod: ver deploy-profile / `docs/ops/deploy-runbook.md`
