---
name: frontend-redesign-orchestrator
description: "Orchestrates complete frontend redesigns without duplicating specialist knowledge. Use for multi-screen or substantial UI/UX redesigns that require discovery, audit, direction selection, implementation and visual validation."
---

# Frontend Redesign Orchestrator

## Role

Coordinate redesign. Do not re-teach UX, design systems, motion, React or Playwright inside this skill.

## Phase 1 — Discover

1. Read product/project context and existing source of truth.
2. Inspect representative screens/components/tokens/assets.
3. Classify scope:
   - **preserve** — same visual world, targeted improvement;
   - **refresh** — same identity, substantial presentation changes;
   - **rebuild** — replacement visual world while preserving product truth.
4. Record what must not change silently: flows, URLs, data meaning, field names, brand/legal/factual content.

## Phase 2 — Audit

Choose the smallest relevant audit set:

- web best practices → Vercel `web-design-guidelines`;
- focused interface critique → Jakub `interface-review` or Impeccable `critique`;
- data-dense surface → `ui-craft-dense-dashboard` review;
- accessibility remediation → `fixing-accessibility`.

Do not run every audit specialist by default.

## Phase 3 — Select design authority

- project skill / DESIGN.md / Figma remains source of truth when present;
- marketing/landing → `design-taste-frontend` and/or `frontend-design`;
- data-dense product → `ui-craft-dense-dashboard`;
- general product → `frontend-design` as needed;
- high-end final craft → Impeccable after direction is established;
- motion → `design-motion-principles` only when motion is in scope.

Document which specialist is primary and which are advisory.

## Phase 4 — Implement

Follow `nexus-frontend` policy.

Use Vercel `vercel-react-best-practices` and `vercel-composition-patterns` for implementation architecture/performance. Reuse existing components and tokens before inventing new abstractions.

Do not invoke retired local skills: `ux-audit`, `ux-writing`, `frontend-architecture-review`, `design-system-engineer`, `saas-product-review`.

## Phase 5 — Validate

Invoke `visual-validation`.

Validation must cover representative breakpoints, primary flows/states and browser errors. Perform no more than two automatic correction passes.

## Completion

Report:

- preserve/refresh/rebuild classification;
- source of truth used;
- specialists used and why;
- major changes;
- validation evidence;
- unresolved risks/decisions.
