---
name: "source-command-pr"
description: "Create a Pull Request with a structured description from the diff"
---

# source-command-pr

Use this skill when the user asks to run the migrated source command `pr`.

## Command Template

Create a Pull Request for the current branch.

## Information Gathering

```bash
!git branch --show-current
```

```bash
!git log main..HEAD --oneline
```

```bash
!git diff main..HEAD --stat
```

## Generate PR

Based on the commits and diff, generate:

### Title
Format: `<type>(<scope>): <description>`
Same pattern as Conventional Commits.

### Description (template)
```markdown
## What changes
[Summary of the changes in 2-3 sentences]

## Why
[Context and motivation]

## How to test
1. [Step 1]
2. [Step 2]
3. [Expected verification]

## Checklist
- [ ] Tests added/updated
- [ ] Documentation updated (if applicable)
- [ ] No hardcoded secrets
- [ ] Self-review completed
- [ ] Works on mobile (if UI)

## Screenshots (if UI)
[if applicable]
```

### Create the PR via GitHub CLI:
```bash
gh pr create --title "<title>" --body "<description>" --base main
```

If `gh` is not available, show the direct link:
```bash
!echo "https://github.com/$(git remote get-url origin | sed 's/.*github.com[:/]//' | sed 's/.git$//')/compare/main...$(git branch --show-current)"
```

## MANUAL MIGRATION REQUIRED

Migrated from source command `pr` into a Codex skill. Invoke it as `$source-command-pr` and manually rewrite any slash-command behavior that depended on provider-specific runtime expansion.

Review unsupported command metadata manually: `allowed-tools`.
