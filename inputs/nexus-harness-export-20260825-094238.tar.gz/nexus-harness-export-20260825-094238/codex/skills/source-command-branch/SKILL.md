---
name: "source-command-branch"
description: "Create a feature branch with a standardized name and initial setup"
---

# source-command-branch

Use this skill when the user asks to run the migrated source command `branch`.

## Command Template

Create a feature branch for: $ARGUMENTS

## Process

1. Ensure we are on the most up-to-date branch:
```bash
git checkout main && git pull origin main
```

2. Create the branch with a standardized name:
- Format: `feat/description-kebab-case` or `fix/description-kebab-case`
- Maximum 50 characters in the name
- No special characters

3. Check out the new branch

4. Confirm the result:
```bash
git branch --show-current
```

Report the name of the created branch and that it is ready for work.

## MANUAL MIGRATION REQUIRED

Migrated from source command `branch` into a Codex skill. Invoke it as `$source-command-branch` and manually rewrite any slash-command behavior that depended on provider-specific runtime expansion.

Provider argument placeholders like `$ARGUMENTS` or `$1` were preserved as text; rewrite them into natural-language instructions for Codex.

Review unsupported command metadata manually: `allowed-tools`, `argument-hint`.
