---
name: deploy
description: Deploy para produção via perfil local do repo. Use com /deploy. Lê `.claude/deploy-profile.md` (VPS, packages, containers, volumes, tabelas, health). Confirma alvo antes de agir; forensic/log antes de recreate.
---

# /deploy — Deploy baseado em perfil do repo

Skill **global**. Cada repositório documenta o próprio ambiente em:

```
.claude/deploy-profile.md
```

Sem esse arquivo → pare e peça para criar o perfil (use o template abaixo). Não invente VPS/containers.

## Procedimento (sempre nesta ordem)

1. **Localizar perfil** em `$CLAUDE_PROJECT_DIR/.claude/deploy-profile.md` (ou cwd do git root).
2. **Ler** seções: Identity, VPS, Install, Containers, Volumes/DB, Tables, Deploy procedure, Health, Rollback, Danger.
3. **Resolver alvo** se o perfil listar múltiplos apps/tenants (ex.: vuca vs thiago). Ambíguo → AskUserQuestion.
4. **Pré-checks** do perfil (branch esperada, `git status`, `docker ps` remoto se aplicável).
5. **Ecoar** repo + branch + VPS + containers afetados + comando planejado → **confirmação explícita**.
6. Se houver forensic/log aprovado na conversa → executar **antes** de qualquer recreate/up.
7. Executar o procedimento do perfil (sem pular health).
8. Reportar: commit/sha, duração, health. Em falha: rollback do perfil.

## Regras

- Nunca deployar com testes/lint quebrados quando o perfil exigir gate.
- Nunca `docker compose up` sem `-f` quando o perfil especifica o compose.
- DB/volumes: só o que o perfil autorizar; backup antes de touch em SQLite/Postgres prod.
- Firewall local pode bloquear `rm -rf` / `docker rm -f` / force-push — use alternativas do perfil.
- Multi-tenant (SDR): **nunca** copiar `skills_prompt`/branding/DB entre tenants.

## Template `.claude/deploy-profile.md`

```markdown
# Deploy profile — <nome>

## Identity
- Repo / path local:
- GitHub:
- Domínio(s):
- Tenant/app aliases: (ex. vuca, thiago, 137)

## VPS
- Host / SSH user:
- App path on host:
- Edge (Traefik/Coolify/Dokploy/Apache):
- Network Docker:

## Install / packages
- Package manager + lockfile:
- Install commands (local + CI/VPS):
- Build commands:

## Containers
| Name | Image/build | Role | Ports |
|------|-------------|------|-------|

## Volumes / database
- Engine (Postgres/SQLite/…):
- Volume name → mount path:
- Backup command before deploy:

## Tables (or schema source)
- Lista ou: "ver migrations em …" / "schema.sql"

## Deploy procedure
Passos numerados (rsync/GHCR/compose/etc.)

## Health checks
Comandos + resposta esperada

## Rollback
Como reverter imagem/código sem perder volume

## Danger
O que nunca fazer neste repo
```

## Índice rápido dos perfis Nexus (01-Projetos)

Atualize este bloco quando criar/mover repos:

| Repo | Profile path | VPS (resumo) |
|------|----------------|--------------|
| vuca-sdr (CRM monorepo) | `CRM-Comercial/vuca-sdr-agent/apps/vuca-sdr/.claude/deploy-profile.md` | 137.131.236.229 |
| thiago-sdr | `…/apps/thiago-sdr/.claude/deploy-profile.md` | mesma VPS / paths separados |
| Koinon | `Koinon/.claude/deploy-profile.md` | Dokploy network |
| Marketing Hub | `Marketing Hub/.claude/deploy-profile.md` | 76.13.225.91 |
| mh-backfill | `marketing-hub-backfill-metas/.claude/deploy-profile.md` | mesma VPS MH (worker/jobs) |
| elabore-api/ia/web | `Elabore/elabore-*/.claude/deploy-profile.md` | compose production |
| Ghasper | `Ghasper/.claude/deploy-profile.md` | 147.93.179.118 |
| landing-vuca | `Vuca/landing-page-vuca/.claude/deploy-profile.md` | ver perfil |
| Rebeca | `Projeto - Rebeca/.claude/deploy-profile.md` | Hostinger Traefik |
