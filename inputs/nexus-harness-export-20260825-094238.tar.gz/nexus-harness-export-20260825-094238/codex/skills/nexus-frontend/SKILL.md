---
name: nexus-frontend
description: "Nexus frontend router and implementation policy. Use for frontend UI work to resolve project source of truth, classify the surface, route the minimum necessary specialist skills, preserve the existing stack/design system, and require final visual validation. Do not use as a generic design encyclopedia."
---

# Nexus Frontend

## Role

This skill is the **routing and policy layer** for Rubens' frontend work. It does not replace upstream specialists.

## Model

Subagents invoked for frontend work (this skill, visual-validation, design specialists, UI implementation) must use `model: "kimi-k3-max"`. Prefer delegating non-trivial UI implementation to a Kimi K3 subagent over implementing in the parent chat.

Installed specialist names (use these exact names):

- Vercel React/Next: `vercel-react-best-practices`, `vercel-composition-patterns`, `web-design-guidelines`, `vercel-react-view-transitions`
- aliases accepted in briefs: `react-best-practices` → `vercel-react-best-practices`; `composition-patterns` → `vercel-composition-patterns`; `react-view-transitions` → `vercel-react-view-transitions`
- Never install or default-enable `gpt-taste`
- Never treat Vercel **hosting** as a deploy target; Vercel **skills** are engineering guidance only

## 1. Resolve source of truth first

Use this precedence:

1. explicit user request;
2. project-specific skill / DESIGN.md / existing design system;
3. explicit Figma or visual target;
4. surface/domain specialist;
5. framework engineering guidance;
6. craft/polish guidance;
7. generic design intelligence.

Never silently override a project brand or an explicit visual target.

## 2. Classify the task

Choose one primary surface class:

- `marketing`: landing, portfolio, campaign, public product page;
- `product`: normal SaaS/app UI;
- `data-dense`: CRM, admin, BI, analytics, tables/operator tools;
- `redesign`: multi-surface or replacement work;
- `motion`: animation/transition is the primary problem;
- `figma`: Figma is the implementation target;
- `architecture`: React/component/app structure is the problem;
- `validation`: review/evidence only.

## 3. Route the minimum specialists

Load budget per phase: 1 source of truth + 1 surface specialist + 0–1 technical specialist + `visual-validation` at the end.

### Marketing

Use `design-taste-frontend` for anti-slop/art direction. Add `frontend-design` when creating the visual direction from a broad brief. Use Impeccable for a later polish pass, not automatically at the same time.

**Deny:** `ui-craft-dense-dashboard`, `gpt-taste`.

### Data-dense product UI

Use `ui-craft-dense-dashboard`. Do not use Taste on dashboards/admin/data tables.

**Deny:** `design-taste-frontend`, `gpt-taste`.

### General product UI

Use the project source of truth + `frontend-design` when a new visual solution is needed. Use Impeccable for critique/polish when requested or when the result clearly needs craft refinement.

### Motion

Use `design-motion-principles` to decide and design motion. Use `fixing-motion-performance` and/or `fixing-accessibility` afterward when implementation quality requires it.

**Deny:** `gpt-taste` as motion authority.

### React / Next engineering

Use Vercel specialists:

- `vercel-react-best-practices` for React/Next performance;
- `vercel-composition-patterns` for component API/architecture (boolean-prop explosion, compound components);
- `web-design-guidelines` for web UI best-practice audits;
- `vercel-react-view-transitions` when that API is specifically relevant.

Use `feature-sliced-design` only for sufficiently large frontend architecture problems. Do not impose FSD on small apps or landing pages.

### Figma

Figma is source of truth when explicitly provided. Route through `figma-design-to-code`. Other specialists may fix implementation/a11y/performance without changing the visual target silently.

### Reference site

Use `extract-design-system` to collect starter tokens/evidence. Treat output as reference, never as authoritative project DS.

### Design intelligence

Use `ui-ux-pro-max` to search/explore possibilities. Its recommendation never outranks project brand/Figma/explicit brief.

### Specialized review passes

Jakub `interface-review`, `better-writing`, `better-accessibility` only when the task is an explicit focused pass.

## 4. Nexus implementation policy

- Inspect the existing stack before changing dependencies or conventions.
- Reuse project components/tokens before creating new ones.
- Prefer TypeScript for React/Next code in TypeScript projects.
- Default stack **when the project already uses it**: Next.js + TypeScript strict, Tailwind v4 (`@theme`), shadcn/ui via existing `components.json` / registry, React Native/Expo for mobile surfaces.
- Use Context7 for framework/lib APIs when the gap matters — do not guess stale APIs.
- User-facing copy in PT-BR unless the project language is different.
- Honor modular monolith (`src/modules/<domain>` + `src/shared`, imports only via `index.ts` or `src/shared`) when that ADR is in force.
- Do not add a dependency if the current stack already solves the problem adequately.
- Implement real loading, empty, error and disabled states when the flow requires them.
- Preserve URL structure, field names, product truth and legal/factual copy unless change is explicitly in scope.
- Do not make visual redesign decisions during a narrow bugfix.

## 5. Conflict rules

- Project source of truth wins over Taste, UI Craft, Impeccable and UI UX Pro Max.
- Taste and Dense Dashboard are mutually exclusive by surface by default.
- Motion Principles owns motion decisions.
- Framework specialists own React/Next engineering details.
- Never load multiple generic craft skills just to "increase quality".
- Retired local skills (`ux-audit`, `ux-writing`, `frontend-architecture-review`, `design-system-engineer`, `saas-product-review`) must not be invoked.

## 6. Delivery gate

For significant frontend changes:

1. run the project's relevant build/typecheck/lint/tests;
2. run the relevant technical specialist checks;
3. invoke `visual-validation`;
4. fix findings in at most two correction passes;
5. report what changed, why, and the evidence.

A frontend change is not complete merely because it compiles.
