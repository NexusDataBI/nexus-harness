---
name: verification-loop
description: Gate de verificação antes de PR ou ao concluir feature/refactor — build, types, lint, testes, segurança, código morto e diff review, com relatório PASS/FAIL. Use sempre antes de abrir PR e após mudanças significativas.
metadata:
  origin: ECC (adaptado Nexus)
---

# Verification Loop

Rode as fases na ordem. Fase que falha = **pare e conserte antes de seguir** — inclusive falhas que você não causou (suite vermelha ou CI quebrado nunca são "pré-existentes"; são bloqueio).

Detecte o package manager pelo lockfile (pnpm/npm) e ajuste os comandos.

## Fase 1 — Build
```bash
npm run build 2>&1 | tail -20
# Dockerfile/compose tocados no diff? Valide a imagem também:
docker compose build 2>&1 | tail -20
```

## Fase 2 — Types
```bash
npx tsc --noEmit --pretty 2>&1 | head -30   # TS
ruff check . && mypy . 2>&1 | head -30       # Python (se o projeto usa mypy)
```

## Fase 3 — Lint
```bash
npm run lint 2>&1 | head -30
```

## Fase 4 — Testes + cobertura
```bash
npx vitest run --coverage 2>&1 | tail -50    # ou o runner do projeto (ver tdd-workflow)
```
Reporte: total / passou / falhou / cobertura. Alvo 80%+; cenário > percentual.

## Fase 5 — Segurança rápida
```bash
# Secrets esquecidos no diff (não no repo todo):
git diff main...HEAD | grep -niE "api[_-]?key|secret|password|token" | grep -v "process.env\|import\|_KEY\b.*env" | head -10
# Sujeira de debug:
git diff main...HEAD | grep -n "console\.log\|debugger\|print(" | head -10
```
Achou candidato a secret real → pare, remova, e se já foi commitado considere exposto (rotacionar). Achados profundos são do agent `security-reviewer` — esta fase é só a rede de proteção final.

## Fase 6 — Código morto (absorve o antigo refactor-cleaner)
```bash
npx knip 2>&1 | head -20        # exports/arquivos/deps não usados (se configurado)
npx depcheck 2>&1 | head -15    # deps órfãs
```
Remova o que **este diff** órfão deixou (helper que ficou sem uso, import esquecido). Código morto pré-existente fora do diff: anote no napkin, não limpe agora — escopo é escopo.

## Fase 7 — Diff review
```bash
git diff main...HEAD --stat
git diff main...HEAD --name-only
```
Passe arquivo a arquivo: mudança não-intencional? erro engolido? algo fora do escopo aprovado? arquivo que não devia estar aqui (`.env`, lockfile alheio, artefato de build)?

## Relatório final

```
VERIFICAÇÃO — [branch]
Build:      PASS/FAIL
Types:      PASS/FAIL (N erros)
Lint:       PASS/FAIL (N warnings)
Testes:     PASS/FAIL (X/Y, Z% cobertura)
Segurança:  PASS/FAIL (N achados)
Cód. morto: PASS/FAIL (N itens removidos)
Diff:       N arquivos — escopo OK?

Veredito:   PRONTO PARA PR / NÃO PRONTO
Pendências: 1) ... 2) ...
```

PRONTO → invoque o agent `code-reviewer` (e `security-reviewer`/`database-reviewer` se o diff tocar os triggers deles) antes de abrir o PR. NÃO PRONTO → corrija e repita da fase que falhou.
