---
name: "source-command-review"
description: "Code review focused on bugs, security, and quality"
---

# source-command-review

Use this skill when the user asks to run the migrated source command `review`.

## Command Template

Perform a rigorous code review of the current changes.

```bash
!git diff --cached --name-only 2>/dev/null || git diff --name-only
```

```bash
!git diff --cached 2>/dev/null || git diff
```

## Review Process

### 1. Overview
- Which files were modified and why?
- Is the change cohesive (does ONE thing) or does it mix concerns?

### 2. Bugs & Logic (HIGHEST PRIORITY)
- Are there logical errors, off-by-one issues, untreated null/undefined?
- Race conditions, deadlocks, memory leaks?
- Uncovered edge cases?
- Unvalidated inputs?

### 3. Security
- SQL injection, XSS, IDOR, SSRF?
- Secrets hardcoded?
- Permissions checked on each endpoint?
- Sensitive data in logs?

### 4. Performance
- Queries N+1?
- O(n²) operations that could be O(n)?
- Unnecessarily loaded data?
- Missing indexes for frequent queries?

### 5. Maintainability
- Clear and descriptive names?
- Functions with a single responsibility?
- Duplicated code that should be extracted?
- Tests covering the new paths?

## Response Format

For each issue found:
```
CRITICAL / IMPORTANT / SUGGESTION

File: path/to/file.ts:42
Problem: [concise description]
Risk: [what can happen if not fixed]
Suggested fix: [code or direction]
```

At the end, give a verdict: APROVADO ✅ / PRECISA DE AJUSTES ⚠️ / BLOQUEAR 🚫

## MANUAL MIGRATION REQUIRED

Migrated from source command `review` into a Codex skill. Invoke it as `$source-command-review` and manually rewrite any slash-command behavior that depended on provider-specific runtime expansion.

Review unsupported command metadata manually: `allowed-tools`.
