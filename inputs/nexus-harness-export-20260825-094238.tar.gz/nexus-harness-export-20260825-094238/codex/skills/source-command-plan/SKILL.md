---
name: "source-command-plan"
description: "Structured planning before implementation - Explore -> Plan -> Spec -> Execute"
---

# source-command-plan

Use this skill when the user asks to run the migrated source command `plan`.

## Command Template

Follow the structured planning workflow for the task: $ARGUMENTS

## Phase 1: EXPLORE
Explore the codebase to understand the relevant context:
- Which existing files, modules, and patterns are relevant?
- How were similar features implemented?
- Which dependencies and contracts exist?

Summarize what you found before proceeding.

## Phase 2: PLAN
Propose 2-3 approaches, starting with the simplest:

For each approach:
- **Description:** What changes and how
- **Affected files:** Complete list
- **Pros:** Advantages
- **Cons:** Disadvantages and risks
- **Estimate:** Complexity (low/medium/high)

Recommend an approach with justification.

## Phase 3: SPEC
Create a `plan.md` file at the project root with:

```markdown
# Spec: [Feature Name]

## Objective
[One sentence describing the final outcome]

## Chosen approach
[Which one and why]

## Requirements
- [ ] Functional requirement 1
- [ ] Functional requirement 2
- [ ] Non-functional requirement (performance, security)

## Milestones
### M1: [Name] (estimate: Xh)
- [ ] Task 1 (~5min)
- [ ] Task 2 (~5min)
- [ ] Task 3 (~5min)

### M2: [Name] (estimate: Xh)
- [ ] Task 4
- [ ] Task 5

## Edge Cases
- [case 1]
- [case 2]

## Risks
- [risk 1] -> mitigation: [...]
- [risk 2] -> mitigation: [...]

## Definition of Done
- [ ] All tests passing
- [ ] Code review completed
- [ ] Documentation updated
```

Save the file and ask whether to start execution with Milestone 1.

## MANUAL MIGRATION REQUIRED

Migrated from source command `plan` into a Codex skill. Invoke it as `$source-command-plan` and manually rewrite any slash-command behavior that depended on provider-specific runtime expansion.

Provider argument placeholders like `$ARGUMENTS` or `$1` were preserved as text; rewrite them into natural-language instructions for Codex.

Review unsupported command metadata manually: `allowed-tools`, `argument-hint`.
