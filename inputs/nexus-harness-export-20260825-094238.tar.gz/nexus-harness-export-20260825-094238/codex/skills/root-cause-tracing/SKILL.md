---
name: "root-cause-tracing"
description: "Use when errors occur deep in the execution stack and you need to trace back to find the original trigger. Complements systematic-debugging when the stack trace alone is not enough."
---

# Root Cause Tracing

## When to use

- The error happens in a "leaf" function (e.g. parser, formatter, helper) but the real cause is in a distant caller
- Stack trace shows "Cannot read property X of undefined" but the `undefined` came from somewhere - you need to find where
- Bug appears in production but not in dev - something on the path between external input and the affected function is different

## Technique: reverse tracing

### Step 1 - Mark the point where the error happens
This is the "end". Note the exact file:line.

### Step 2 - List ALL callers
```bash
# Find who calls the problematic function
grep -rn "nomeDaFuncao(" src/
```

Build a tree:
```
PiiMasker.mask(name)  <- error here
├── ExportService.exportConversation()
│   └── ExportController.handleExport()
│       └── POST /api/export route handler
└── ConversationFormatter.format()
    └── WebhookHandler.processIncoming()
        └── POST /api/webhook/evolution route handler
```

### Step 3 - For each path, trace the origin of the problematic data

For each caller, ask: "where does the `name` it passes to mask() come from?"

```
ExportService.exportConversation(conversationId)
  -> fetches conversation from repo: ConversationRepo.findById(id)
  -> repo returns Conversation with .contactName
  -> where did Conversation.contactName come from?
  -> schema.sql: contact_name TEXT NULL  <- HERE IS THE NULL PERMISSION
```

### Step 4 - Add temporary instrumentation
If you cannot trace through the code (dynamic calls, events, jobs), add temporary logs:

```ts
// REMOVE BEFORE COMMIT
console.log('[DEBUG-trace]', {
  caller: 'ExportService.exportConversation',
  conversationId,
  contactName: conversation.contactName,
  stack: new Error().stack
})
```

Reproduce the bug. Look at the logs. Identify where the problematic value really comes from.

### Step 5 - Find the input boundary
The root cause is at the outermost boundary where the problematic data entered the system:
- Webhook payload
- Form input
- Database query
- External API
- Environment variable

Fix it at the boundary (input validation/normalization) or in the contract (make the type explicit).

### Step 6 - Clean up instrumentation
**ALWAYS** remove debug `console.log` before committing. Use grep:
```bash
grep -rn "DEBUG-trace" src/
```

## Signs you are on the right path

- The correction is far from where the error was observed
- You discovered an implicit system assumption
- The fix protects multiple callers at once

## Signs you are NOT on the right path

- You are adding defenses to every caller individually
- The fix is an if statement at the error location
- You cannot explain in one sentence where the problematic value came from
