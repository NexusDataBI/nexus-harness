---
name: "source-command-push"
description: "Safe push with pre-push checks (tests, lint, branch protection)"
---

# source-command-push

Use this skill when the user asks to run the migrated source command `push`.

## Command Template

Execute a safe push with checks:

## Pre-checks

1. **Check current branch** (NEVER push directly to main):
```bash
!git branch --show-current
```

2. **Check whether there are uncommitted changes:**
```bash
!git status --short
```

3. **Run tests:**
```bash
!pnpm test 2>&1 | tail -20
```

4. **Run linter:**
```bash
!pnpm lint 2>&1 | tail -10
```

## Decision

- If branch is `main` or `master`: **BLOCK**. Tell the user to create a feature branch.
- If there are uncommitted changes: **WARN**. Ask whether to commit first.
- If tests failed: **BLOCK**. Show the errors and suggest fixes.
- If lint failed: **WARN**. Offer to run auto-fix.

## Push

If everything passes:
```bash
git push origin HEAD
```

Report the result and suggest creating a PR if one does not already exist.

## MANUAL MIGRATION REQUIRED

Migrated from source command `push` into a Codex skill. Invoke it as `$source-command-push` and manually rewrite any slash-command behavior that depended on provider-specific runtime expansion.

Review unsupported command metadata manually: `allowed-tools`.
