---
name: "source-command-commit"
description: "Generate a commit message using Conventional Commits from the current diff"
---

# source-command-commit

Use this skill when the user asks to run the migrated source command `commit`.

## Command Template

Analyze the staged changes (or all changes if nothing is staged):

```bash
!git diff --cached --stat
```

```bash
!git diff --cached
```

If there are no staged changes, analyze the unstaged diff:
```bash
!git diff --stat
```

Based on the diff above, generate a commit message following Conventional Commits:

## Format
```
<type>(<scope>): <short description in English>

<optional body: what changed and why>

<optional footer: breaking changes, closed issues>
```

## Types
- `feat`: New feature
- `fix`: Bug fix
- `refactor`: Refactor without behavior change
- `test`: Test addition/modification
- `docs`: Documentation
- `style`: Formatting (no logic change)
- `chore`: Maintenance tasks, deps, CI
- `perf`: Performance improvement

## Rules
- Short description in English, imperative, maximum 72 characters
- Scope is the affected module/area (auth, api, db, ui, etc.)
- If changes span multiple areas, use the most significant scope
- Breaking changes: add `BREAKING CHANGE:` in the footer
- If the diff is large (>10 files), group the changes in the body

Present the suggested commit message and ask whether I should execute the commit.

## MANUAL MIGRATION REQUIRED

Migrated from source command `commit` into a Codex skill. Invoke it as `$source-command-commit` and manually rewrite any slash-command behavior that depended on provider-specific runtime expansion.

Review unsupported command metadata manually: `allowed-tools`.
