#!/usr/bin/env bash
# Claude Code status line — rich & colorful
# ~/.claude/statusline-command.sh

input=$(cat)

# ── Cores ANSI ──
RST='\033[0m'
DIM='\033[2m'
BOLD='\033[1m'
GREEN='\033[32m'
YELLOW='\033[33m'
RED='\033[31m'
CYAN='\033[36m'
MAGENTA='\033[35m'
BLUE='\033[34m'
WHITE='\033[37m'

# ── Extrair todos os dados via jq (uma chamada só para performance) ──
eval "$(echo "$input" | jq -r '
  @sh "model=\(.model.display_name // "Claude")",
  @sh "cwd=\(.workspace.current_dir // .cwd // "")",
  @sh "used_pct=\(.context_window.used_percentage // "")",
  @sh "remaining_pct=\(.context_window.remaining_percentage // "")",
  @sh "ctx_size=\(.context_window.context_window_size // 0)",
  @sh "total_input=\(.context_window.total_input_tokens // 0)",
  @sh "total_output=\(.context_window.total_output_tokens // 0)",
  @sh "cache_read=\(.context_window.current_usage.cache_read_input_tokens // 0)",
  @sh "cache_write=\(.context_window.current_usage.cache_creation_input_tokens // 0)",
  @sh "input_tokens=\(.context_window.current_usage.input_tokens // 0)",
  @sh "cost=\(.cost.total_cost_usd // 0)",
  @sh "duration_ms=\(.cost.total_duration_ms // 0)",
  @sh "api_duration_ms=\(.cost.total_api_duration_ms // 0)",
  @sh "lines_added=\(.cost.total_lines_added // 0)",
  @sh "lines_removed=\(.cost.total_lines_removed // 0)",
  @sh "agent_name=\(.agent.name // "")",
  @sh "worktree_name=\(.worktree.name // "")",
  @sh "worktree_branch=\(.worktree.branch // "")",
  @sh "exceeds_200k=\(.exceeds_200k_tokens // false)",
  @sh "cur_output_tokens=\(.context_window.current_usage.output_tokens // 0)",
  @sh "rl_5h=\(.rate_limits.five_hour.used_percentage // "")",
  @sh "rl_7d=\(.rate_limits.seven_day.used_percentage // "")"
' 2>/dev/null)"

dir=$(basename "$cwd")

# ── Git branch (cache 10s para performance) ──
cache_file="/tmp/claude-statusline-git-cache"
branch=""
if [ -n "$cwd" ] && [ -d "$cwd" ]; then
  if [ -f "$cache_file" ] && [ $(($(date +%s) - $(stat -f %m "$cache_file" 2>/dev/null || echo 0))) -lt 10 ]; then
    branch=$(cat "$cache_file")
  else
    branch=$(git -C "$cwd" branch --show-current 2>/dev/null || echo "")
    echo "$branch" > "$cache_file" 2>/dev/null
  fi
fi

# ── Separador ──
SEP="${DIM} │ ${RST}"

# ── Formatar duração ──
format_duration() {
  local ms=$1
  local total_sec=$(( ms / 1000 ))
  local hours=$(( total_sec / 3600 ))
  local mins=$(( (total_sec % 3600) / 60 ))
  local secs=$(( total_sec % 60 ))
  if [ "$hours" -gt 0 ]; then
    printf "%dh%02dm" "$hours" "$mins"
  elif [ "$mins" -gt 0 ]; then
    printf "%dm%02ds" "$mins" "$secs"
  else
    printf "%ds" "$secs"
  fi
}

# ── Formatar tokens ──
format_tokens() {
  local t=$1
  if [ "$t" -ge 1000000 ]; then
    echo "$(echo "scale=1; $t / 1000000" | bc)M"
  elif [ "$t" -ge 1000 ]; then
    echo "$(echo "scale=1; $t / 1000" | bc)k"
  else
    echo "$t"
  fi
}

# ── Context window size badge ──
ctx_badge=""
if [ "$ctx_size" -ge 1000000 ]; then
  ctx_badge=" 1M"
elif [ "$ctx_size" -ge 200000 ]; then
  ctx_badge=" 200k"
fi

# ══════════════════════════════════════════
#  LINHA 1: Modelo │ Projeto │ Branch │ Contexto
# ══════════════════════════════════════════
line1=""

# Modelo + context window badge
line1="${BOLD}${MAGENTA}${model}${RST}"

# Agent badge (quando usando --agent)
if [ -n "$agent_name" ]; then
  line1="${line1} ${DIM}[${CYAN}${agent_name}${DIM}]${RST}"
fi

# Worktree badge
if [ -n "$worktree_name" ]; then
  wt_label="${worktree_branch:-$worktree_name}"
  line1="${line1} ${DIM}[${YELLOW}⎇ ${wt_label}${DIM}]${RST}"
fi

# Diretório
if [ -n "$dir" ]; then
  line1="${line1}${SEP}${CYAN}${dir}${RST}"
fi

# Branch git
if [ -n "$branch" ]; then
  line1="${line1}${SEP}${BLUE} ${branch}${RST}"
fi

# Barra de contexto colorida
if [ -n "$used_pct" ] && [ -n "$remaining_pct" ]; then
  used_int=${used_pct%.*}

  if [ "$used_int" -lt 50 ]; then
    BAR_COLOR="$GREEN"
  elif [ "$used_int" -lt 75 ]; then
    BAR_COLOR="$YELLOW"
  else
    BAR_COLOR="$RED"
  fi

  # Alerta >200k
  alert=""
  if [ "$exceeds_200k" = "true" ]; then
    alert=" ${RED}⚠${RST}"
  fi

  # Barra com blocos Unicode de alta resolução (8 níveis por célula)
  bar_width=12
  total_units=$(( bar_width * 8 ))
  filled_units=$(( used_int * total_units / 100 ))
  bar=""
  blocks=("" "▏" "▎" "▍" "▌" "▋" "▊" "▉" "█")
  for i in $(seq 0 $(( bar_width - 1 ))); do
    cell_start=$(( i * 8 ))
    cell_fill=$(( filled_units - cell_start ))
    if [ "$cell_fill" -ge 8 ]; then
      bar="${bar}█"
    elif [ "$cell_fill" -le 0 ]; then
      bar="${bar}░"
    else
      bar="${bar}${blocks[$cell_fill]}"
    fi
  done

  line1="${line1}${SEP}${BAR_COLOR}${bar}${RST} ${BAR_COLOR}${BOLD}${used_int}%${RST}${alert}"
fi

# ══════════════════════════════════════════
#  LINHA 2: Tempo │ Tokens │ Cache │ Custo │ Diff
# ══════════════════════════════════════════
line2=""

# Tempo de sessão
if [ "$duration_ms" -gt 0 ]; then
  dur_fmt=$(format_duration "$duration_ms")
  line2="${DIM}⏱ ${RST}${WHITE}${dur_fmt}${RST}"
fi

# Tokens do contexto: usados / livres (↑output última resposta)
if [ "$ctx_size" -gt 0 ]; then
  if [ "$input_tokens" -gt 0 ]; then
    # current_usage disponível — cálculo preciso
    ctx_used=$(( input_tokens + cache_read + cache_write ))
  elif [ -n "$used_pct" ]; then
    # Fallback: derivar de used_percentage (menos preciso)
    used_int=${used_pct%.*}
    ctx_used=$(( ctx_size * used_int / 100 ))
  else
    ctx_used=0
  fi
  ctx_free=$(( ctx_size - ctx_used ))
  if [ "$ctx_free" -lt 0 ]; then ctx_free=0; fi
  used_fmt=$(format_tokens "$ctx_used")
  free_fmt=$(format_tokens "$ctx_free")
  if [ -n "$line2" ]; then line2="${line2}${SEP}"; fi
  line2="${line2}${YELLOW}${used_fmt}${RST}${DIM} used${RST} ${GREEN}${free_fmt}${RST}${DIM} free${RST}"
  if [ "$cur_output_tokens" -gt 0 ]; then
    out_fmt=$(format_tokens "$cur_output_tokens")
    line2="${line2} ${DIM}(↑${out_fmt})${RST}"
  fi
fi

# Custo USD
if [ "$cost" != "0" ] && [ "$cost" != "null" ]; then
  cost_fmt=$(printf "%.2f" "$cost" 2>/dev/null || echo "$cost")
  if [ -n "$line2" ]; then line2="${line2}${SEP}"; fi
  line2="${line2}${GREEN}\$ ${cost_fmt}${RST}"
fi

# Linhas alteradas
if [ "$lines_added" -gt 0 ] || [ "$lines_removed" -gt 0 ]; then
  changes=""
  if [ "$lines_added" -gt 0 ]; then
    changes="${GREEN}+${lines_added}${RST}"
  fi
  if [ "$lines_removed" -gt 0 ]; then
    [ -n "$changes" ] && changes="${changes} "
    changes="${changes}${RED}-${lines_removed}${RST}"
  fi
  if [ -n "$line2" ]; then line2="${line2}${SEP}"; fi
  line2="${line2}${changes}"
fi

# Rate limits (só aparece se disponível)
if [ -n "$rl_5h" ]; then
  rl5_int=${rl_5h%.*}
  if [ "$rl5_int" -lt 50 ]; then RL5_C="$GREEN"
  elif [ "$rl5_int" -lt 80 ]; then RL5_C="$YELLOW"
  else RL5_C="$RED"; fi
  if [ -n "$line2" ]; then line2="${line2}${SEP}"; fi
  line2="${line2}${DIM}5h ${RST}${RL5_C}${rl5_int}%${RST}"
fi
if [ -n "$rl_7d" ]; then
  rl7_int=${rl_7d%.*}
  if [ "$rl7_int" -lt 50 ]; then RL7_C="$GREEN"
  elif [ "$rl7_int" -lt 80 ]; then RL7_C="$YELLOW"
  else RL7_C="$RED"; fi
  if [ -n "$line2" ]; then line2="${line2}${SEP}"; fi
  line2="${line2}${DIM}7d ${RST}${RL7_C}${rl7_int}%${RST}"
fi

# Hora atual
hora=$(date +%H:%M)
if [ -n "$line2" ]; then line2="${line2}${SEP}"; fi
line2="${line2}${DIM}${hora}${RST}"

# ── Output ──
printf "%b\n" "$line1"
printf "%b" "$line2"
