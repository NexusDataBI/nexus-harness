# ATTRIBUTION — Nexus Claude Harness v2

Proveniência de conteúdo de terceiros incorporado neste harness. Rebuild: jul/2026.
Substitui o `ATTRIBUTION-ECC.md` (v1), cujo conteúdo está consolidado abaixo.

## ECC — Everything Claude Code (MIT)
https://github.com/affaan-m/ECC

- **Rules** `rules/{common,react,typescript,python}/` — cherry-pick de 2026-06-19, mantidas no v2
  com edições: `common/git-workflow.md` reescrita (convenções Nexus PT-BR + worktrees),
  `common/code-review.md` com seção Comments adicionada, `common/code-review-graph.md` nova (origem Nexus).
- **Agents** — no v1 foram copiados 8 agents do ECC; no v2 foram **reescritos** em PT-BR e
  adaptados à stack Nexus: `planner`, `architect`, `tdd-guide`, `build-error-resolver`,
  `database-reviewer` derivam da estrutura ECC. `code-reviewer` e `security-reviewer` são
  originais Nexus informados pela filosofia ECC.
- **Skills** `tdd-workflow/` e `verification-loop/` — adaptações PT-BR condensadas dos originais ECC
  (583→77 e 127→~90 linhas), marcadas com `metadata.origin: ECC`.
- Arquitetura geral (CLAUDE.md enxuto, skills como superfície primária, rules sob demanda,
  disciplina de contexto) segue a filosofia documentada do ECC.

## rtk — Rust Token Killer (Apache License 2.0)
https://github.com/rtk-ai/rtk

- `hooks/rtk-rewrite.sh` (hook oficial v3) e `hooks/test-rtk-rewrite.sh` — copiados do repo
  em jul/2026. `hooks/.rtk-hook.sha256` gerado localmente. `RTK.md` é documentação local Nexus.

## mattpocock/skills (MIT)
https://github.com/mattpocock/skills

- `skills/research/`, `skills/grill-with-docs/`, `skills/resolving-merge-conflicts/` —
  copiadas verbatim em jul/2026 (standalone, sem dependência do setup do repo original).

## ponytail (MIT) — plugin, não copiado
https://github.com/DietrichGebert/ponytail

- Instalado como plugin oficial via marketplace (ver MIGRACAO.md). Nenhum conteúdo copiado
  para este harness. A rule `common/code-review.md` referencia a convenção de marcadores
  `ponytail:` para que reviewers a respeitem.

## Avaliados e não incorporados (jul/2026)

- **claude-mem** (thedotmack) — trial opcional documentado no MIGRACAO.md; não incorporado.
- **graphify** (Graphify-Labs) — alternativa designada ao MCP code-review-graph; decisão
  registrada em `rules/common/code-review-graph.md`.
- **Understand-Anything** (Egonex-AI) — não incorporado (sobreposição de categoria).

## Harness Slim v3 (2026-07-15)

Alinhamento filosófico com ECC (always-on mínimo, skills > commands, cross-harness adapters) sem instalar o pack ECC. Detalhe: `docs/harness-slim-2026-07-15.md`.
