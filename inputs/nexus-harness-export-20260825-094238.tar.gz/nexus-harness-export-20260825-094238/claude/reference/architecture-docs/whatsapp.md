# WhatsApp Integration — VUCA SDR Agent

**Provider:** Evolution API (Baileys em dev, Cloud API em prod)
**Abstração:** WhatsAppProvider interface — trocar modo = mudar .env

---

## 1. Por que Evolution API

| Critério | ChatPro | Meta direto | Evolution API |
|---|---|---|---|
| Custo | R$97-297/mês + markup | Só Meta fees | Self-hosted + Meta fees |
| Controle | Baixo | Total | Total |
| Setup dev | Minutos | Dias (aprovação) | Minutos (Baileys) |
| Risco de ban | Não | Não | Sim Baileys / Não Cloud API |
| Lock-in | Alto | Baixo | Zero |
| Open source | Não | N/A | Sim (MIT) |

---

## 2. Abstração WhatsAppProvider

```
SEU AGENTE SDR
Buffer → Pipeline → Judge → Sender
                               │
                    ┌──────────┴──────────┐
                    │  WhatsAppProvider    │ ← Interface
                    └──────────┬──────────┘
                               │
             ┌─────────────────┼─────────────────┐
             │                 │                  │
     Evolution (Baileys)  Evolution (Cloud)  Meta direto
         DEV/TESTE          PRODUÇÃO          FUTURO
```

### Interface

```typescript
interface WhatsAppProvider {
  sendText(to: string, text: string): Promise<SendResult>;
  sendTemplate(to: string, templateName: string, params: string[]): Promise<SendResult>;
  sendMedia(to: string, mediaUrl: string, type: string, caption?: string): Promise<SendResult>;
  sendButtons(to: string, text: string, buttons: Button[]): Promise<SendResult>;
  sendTyping(to: string, duration?: number): Promise<void>;
  markAsRead(messageId: string): Promise<void>;
  isConnected(): Promise<boolean>;
  getInstanceInfo(): Promise<InstanceInfo>;
  downloadAudio(audioUrl: string): Promise<Buffer>;
  checkHealth(): Promise<HealthStatus>;           // NOVO: health check
}

interface SendResult {
  success: boolean;
  messageId?: string;
  error?: string;
  timestamp: string;
  retryable?: boolean;   // NOVO: indica se vale retry
}

interface HealthStatus {                           // NOVO
  connected: boolean;
  instanceState: string;
  lastMessageAt: string | null;
  latencyMs: number;
}
```

### Implementação com resiliência

```typescript
class EvolutionProvider implements WhatsAppProvider {
  private baseUrl: string;
  private apiKey: string;
  private instanceName: string;
  private healthCache: { status: HealthStatus; cachedAt: number } | null = null;

  // NOVO: retry com backoff exponencial
  private async fetchWithRetry(
    url: string,
    options: RequestInit,
    maxRetries = 3
  ): Promise<Response> {
    let lastError: Error;
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 10000); // 10s timeout
        const response = await fetch(url, { ...options, signal: controller.signal });
        clearTimeout(timeout);

        if (response.ok) return response;
        if (response.status === 429) {
          // Rate limit: esperar antes de retry
          const retryAfter = parseInt(response.headers.get('retry-after') || '5');
          await this.sleep(retryAfter * 1000);
          continue;
        }
        if (response.status >= 500) {
          // Server error: retry com backoff
          await this.sleep(Math.pow(2, attempt) * 1000);
          continue;
        }
        // Client error (4xx): não retryable
        return response;
      } catch (err) {
        lastError = err as Error;
        if (attempt < maxRetries - 1) {
          await this.sleep(Math.pow(2, attempt) * 1000);
        }
      }
    }
    throw lastError!;
  }

  async sendText(to: string, text: string): Promise<SendResult> {
    try {
      const response = await this.fetchWithRetry(
        `${this.baseUrl}/message/sendText/${this.instanceName}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'apikey': this.apiKey },
          body: JSON.stringify({ number: to, text })
        }
      );
      const data = await response.json();
      return {
        success: response.ok,
        messageId: data.key?.id,
        error: data.error,
        timestamp: new Date().toISOString(),
        retryable: response.status >= 500
      };
    } catch (err) {
      return {
        success: false,
        error: (err as Error).message,
        timestamp: new Date().toISOString(),
        retryable: true
      };
    }
  }

  async sendTemplate(to: string, templateName: string, params: string[]): Promise<SendResult> {
    const mode = await this.getIntegrationMode();
    if (mode === 'WHATSAPP-BUSINESS') {
      return this.fetchWithRetry(
        `${this.baseUrl}/message/sendTemplate/${this.instanceName}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'apikey': this.apiKey },
          body: JSON.stringify({
            number: to,
            name: templateName,
            language: 'pt_BR',
            components: [{
              type: 'body',
              parameters: params.map(p => ({ type: 'text', text: p }))
            }]
          })
        }
      ).then(r => this.parseResponse(r));
    } else {
      // Fallback Baileys: texto normal
      const text = await this.getTemplateText(templateName, params);
      return this.sendText(to, text);
    }
  }

  // NOVO: health check com cache de 30s
  async checkHealth(): Promise<HealthStatus> {
    if (this.healthCache && Date.now() - this.healthCache.cachedAt < 30000) {
      return this.healthCache.status;
    }
    const start = Date.now();
    try {
      const response = await fetch(
        `${this.baseUrl}/instance/connectionState/${this.instanceName}`,
        { headers: { 'apikey': this.apiKey }, signal: AbortSignal.timeout(5000) }
      );
      const data = await response.json();
      const status: HealthStatus = {
        connected: data.instance?.state === 'open',
        instanceState: data.instance?.state || 'unknown',
        lastMessageAt: null,
        latencyMs: Date.now() - start
      };
      this.healthCache = { status, cachedAt: Date.now() };
      return status;
    } catch {
      return { connected: false, instanceState: 'error', lastMessageAt: null, latencyMs: Date.now() - start };
    }
  }

  // NOVO: download de áudio com timeout
  async downloadAudio(audioUrl: string): Promise<Buffer> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000); // 30s max
    try {
      const response = await fetch(audioUrl, {
        headers: { 'apikey': this.apiKey },
        signal: controller.signal
      });
      if (!response.ok) throw new Error(`Audio download failed: ${response.status}`);
      const buffer = Buffer.from(await response.arrayBuffer());
      if (buffer.length > 25 * 1024 * 1024) throw new Error('Audio exceeds 25MB Whisper limit');
      return buffer;
    } finally {
      clearTimeout(timeout);
    }
  }

  async sendTyping(to: string, duration = 3000): Promise<void> {
    // Fire-and-forget — typing failure should never block pipeline
    try {
      await fetch(`${this.baseUrl}/chat/presence/${this.instanceName}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': this.apiKey },
        body: JSON.stringify({ number: to, delay: duration, presence: 'composing' }),
        signal: AbortSignal.timeout(5000)
      });
    } catch { /* silently ignore */ }
  }

  private sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }
}
```

---

## 3. Webhook Handler (seguro)

```typescript
// src/whatsapp/webhook.handler.ts

interface EvolutionWebhookPayload {
  event: string;
  instance: string;
  data: {
    key: { remoteJid: string; fromMe: boolean; id: string };
    pushName: string;
    message: {
      conversation?: string;
      extendedTextMessage?: { text: string };
      audioMessage?: { url: string; mimetype: string };
      imageMessage?: { url: string; caption?: string };
      documentMessage?: { url: string; fileName: string };
      buttonsResponseMessage?: { selectedButtonId: string };
      listResponseMessage?: { singleSelectReply: { selectedRowId: string } };
    };
    messageTimestamp: number;
  };
}

function parseWebhookMessage(payload: EvolutionWebhookPayload): WhatsAppIncomingMessage | null {
  if (payload.event !== 'messages.upsert') return null;
  if (payload.data.key.fromMe) return null;

  const msg = payload.data.message;
  const contactNumber = payload.data.key.remoteJid.replace('@s.whatsapp.net', '');

  let text = '';
  let type: 'text' | 'audio' | 'image' | 'document' | 'button_reply' | 'list_reply' = 'text';
  let audioUrl: string | undefined;
  let mediaUrl: string | undefined;
  let buttonReplyId: string | undefined;

  if (msg.conversation) {
    text = msg.conversation;
  } else if (msg.extendedTextMessage?.text) {
    text = msg.extendedTextMessage.text;
  } else if (msg.audioMessage) {
    type = 'audio';
    audioUrl = msg.audioMessage.url;
    text = '[ÁUDIO]';
  } else if (msg.imageMessage) {
    type = 'image';
    mediaUrl = msg.imageMessage.url;
    text = msg.imageMessage.caption || '[IMAGEM]';
  } else if (msg.documentMessage) {
    type = 'document';
    mediaUrl = msg.documentMessage.url;
    text = `[DOCUMENTO: ${msg.documentMessage.fileName}]`;
  } else if (msg.buttonsResponseMessage) {
    type = 'button_reply';
    buttonReplyId = msg.buttonsResponseMessage.selectedButtonId;
    text = buttonReplyId;
  } else if (msg.listResponseMessage) {
    type = 'list_reply';
    buttonReplyId = msg.listResponseMessage.singleSelectReply.selectedRowId;
    text = buttonReplyId;
  }

  return {
    contactNumber, text, type, audioUrl, mediaUrl, buttonReplyId,
    timestamp: new Date(payload.data.messageTimestamp * 1000).toISOString(),
    messageId: payload.data.key.id
  };
}
```

### Webhook route (com segurança)

```typescript
// src/api/routes/webhook.routes.ts

router.post('/webhook/whatsapp', webhookRateLimit, async (req, res) => {
  try {
    // 1. Validar assinatura/apikey
    if (!verifyWebhookSignature(req)) {
      auditLog('webhook_rejected', { reason: 'invalid_signature', ip: req.ip });
      return res.sendStatus(401);
    }

    // 2. Validar schema com Zod
    const parsed = webhookSchema.safeParse(req.body);
    if (!parsed.success) {
      auditLog('webhook_rejected', { reason: 'invalid_payload' });
      return res.sendStatus(400);
    }

    // 3. Parse mensagem
    const message = parseWebhookMessage(parsed.data);
    if (!message) return res.sendStatus(200);

    // 4. Sanitizar texto (prevenir XSS/injection)
    message.text = sanitizeText(message.text);

    // 5. Áudio: transcrever com timeout
    if (message.type === 'audio' && message.audioUrl) {
      try {
        const audio = await whatsappProvider.downloadAudio(message.audioUrl);
        message.text = await transcribeAudio(audio);
        message.type = 'text';
      } catch (err) {
        // NOVO: não enviar "[Áudio não transcrito]" ao GPT
        // Em vez disso, informar ao lead que não conseguiu processar
        message.text = '';
        message.type = 'text';
        // O pipeline vai detectar texto vazio e ignorar
        auditLog('audio_transcription_failed', { error: (err as Error).message });
      }
    }

    // 6. Enviar ao buffer (buffer cuida do resto)
    await bufferManager.handleIncomingMessage(message.contactNumber, {
      text: message.text,
      timestamp: message.timestamp,
      type: message.type === 'audio' ? 'audio_transcription' : 'text',
    });

    res.sendStatus(200);
  } catch (error) {
    // Nunca retornar detalhes do erro
    res.sendStatus(500);
  }
});
```

---

## 4. Outbound Queue (resiliência no envio)

Em vez de enviar mensagens diretamente pelo sender, todas passam pela `whatsapp_outbound_queue`:

```
Sender prepara mensagens
         │
         ▼
whatsapp_outbound_queue (status: queued)
         │
         ▼
Outbound Worker (processa fila)
         │
    ┌────┴────┐
  sucesso    falha
    │          │
  sent     retry (backoff)
             │
         max retries?
             │
           dead → dead_letters
```

Isso garante que se a Evolution API cair momentaneamente, nenhuma mensagem é perdida.

---

## 5. Setup de Desenvolvimento

### docker-compose.dev.yml

```yaml
version: '3.8'
services:
  evolution-api:
    image: atendai/evolution-api:v2.3.7
    container_name: evolution-api
    restart: unless-stopped
    ports:
      - "127.0.0.1:8080:8080"    # Só localhost em dev
    environment:
      - SERVER_URL=http://localhost:8080
      - AUTHENTICATION_API_KEY=${EVOLUTION_API_KEY}
      - DATABASE_PROVIDER=postgresql
      - DATABASE_CONNECTION_URI=postgresql://evolution:${EVOLUTION_DB_PASSWORD}@postgres:5432/evolution
      - DATABASE_SAVE_DATA_INSTANCE=true
      - DATABASE_SAVE_DATA_NEW_MESSAGE=true
      - CACHE_REDIS_ENABLED=true
      - CACHE_REDIS_URI=redis://redis:6379
      - LOG_LEVEL=WARN
    depends_on:
      - postgres
      - redis

  postgres:
    image: postgres:17-alpine
    container_name: evolution-postgres
    environment:
      - POSTGRES_USER=evolution
      - POSTGRES_PASSWORD=${EVOLUTION_DB_PASSWORD}
      - POSTGRES_DB=evolution
    ports:
      - "127.0.0.1:5433:5432"
    volumes:
      - evolution_pg_data:/var/lib/postgresql/data

  redis:
    image: redis:8-alpine
    container_name: evolution-redis
    ports:
      - "127.0.0.1:6380:6379"

volumes:
  evolution_pg_data:
```

### Criar instância Baileys

```bash
# Criar instância
curl -X POST http://localhost:8080/instance/create \
  -H "Content-Type: application/json" \
  -H "apikey: ${EVOLUTION_API_KEY}" \
  -d '{"instanceName": "vuca-sdr-dev", "qrcode": true, "integration": "WHATSAPP-BAILEYS"}'

# Pegar QR code
curl http://localhost:8080/instance/connect/vuca-sdr-dev \
  -H "apikey: ${EVOLUTION_API_KEY}"

# Configurar webhook
curl -X POST http://localhost:8080/webhook/set/vuca-sdr-dev \
  -H "Content-Type: application/json" \
  -H "apikey: ${EVOLUTION_API_KEY}" \
  -d '{
    "url": "http://host.docker.internal:3000/webhook/whatsapp",
    "webhook_by_events": false,
    "events": ["MESSAGES_UPSERT","MESSAGES_UPDATE","CONNECTION_UPDATE"]
  }'
```

---

## 6. Migração para Produção (Cloud API)

### Pré-requisitos Meta (fazer em paralelo ao dev)
1. Facebook Business Manager — CNPJ, verificação empresa (1-5 dias)
2. App Facebook Developers com WhatsApp product
3. Número dedicado (nunca usado no WhatsApp pessoal)
4. Templates aprovados: reengajamento, confirmação agendamento, follow-up

### Trocar instância

```bash
# Criar instância Cloud API
curl -X POST http://evolution-prod:8080/instance/create \
  -H "Content-Type: application/json" \
  -H "apikey: ${EVOLUTION_API_KEY}" \
  -d '{
    "instanceName": "vuca-sdr-prod",
    "token": "${META_BUSINESS_TOKEN}",
    "number": "${META_PHONE_NUMBER}",
    "businessId": "${META_BUSINESS_ID}",
    "qrcode": false,
    "integration": "WHATSAPP-BUSINESS"
  }'
```

### .env: mudar apenas 3 variáveis
```
EVOLUTION_API_URL=https://evolution-prod.seu-dominio.com
EVOLUTION_API_KEY=chave-prod
EVOLUTION_INSTANCE_NAME=vuca-sdr-prod
```

**Zero mudança no código.** A abstração WhatsAppProvider cuida de tudo.

### O que muda no comportamento

| Aspecto | Baileys (dev) | Cloud API (prod) |
|---|---|---|
| Templates | Fallback texto livre | Templates aprovados Meta |
| Janela 24h | Não existe | Real — fora = só template |
| Botões | Funcionam (sem garantia) | Garantidos |
| Risco de ban | Real | Zero |
| Custo por msg | R$0 | Service: grátis na janela; Utility: ~R$0.25 |

---

## 7. Custos Estimados (100 leads/mês)

- ~80% respondem dentro da janela 24h → custo Meta R$0
- ~20% precisam reengajamento → 60 msgs × R$0.25 = R$15
- Infra Evolution API (VPS) → R$50-100/mês
- **Total: ~R$65-115/mês**

---

## 8. Checklist de Produção

- [ ] Facebook Business Manager criado e verificado
- [ ] App com WhatsApp product no Facebook Developers
- [ ] Número dedicado registrado
- [ ] Permanent token gerado
- [ ] Templates aprovados: reengajamento (×2), confirmação, follow-up
- [ ] Evolution API deployed com HTTPS
- [ ] Instância modo WHATSAPP-BUSINESS criada
- [ ] Webhook Meta → Evolution configurado
- [ ] .env atualizado com credenciais prod
- [ ] Health check endpoint configurado e monitorado
- [ ] Testes E2E com número real
- [ ] Alertas para: instância desconectada, falhas de envio, janela 24h
