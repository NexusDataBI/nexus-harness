# Arquitetura — VUCA SDR Agent v5

**Modelo:** GPT-4.1 mini | **Padrão:** Context Engineering (Anthropic, Set/2025)
**Princípios:** Zero hardcoded. Menor conjunto de tokens de alto sinal. Observabilidade first-class.

---

## 1. Visão Geral

```
CONTEXTO DISPONÍVEL          CONTEXT WINDOW (GPT-4.1 mini)         OUTPUT
(banco de dados)             (curadoria seleciona o mínimo)
                                                                    
● System Prompt (core)       System Prompt (core)                   Resposta do
● Skills (N disponíveis)     Skills selecionadas (≤5)     ──▶      agente
● Histórico completo   ──▶  Dados do lead + score                  
● Dados do lead        cur.  Histórico (compactado)                 Tool calls
● Tools (todas)              Mensagem do cliente                    (se necessário)
● Configs dinâmicas          Tools do stage                         
                                                                    
                             OBSERVABILIDADE
                             ● pipeline_audit_logs (replay completo)
                             ● ai_costs, skill_usage, validation_logs
                             ● daily_metrics, unanswered_questions
```

---

## 2. Configuração Dinâmica (agent_config)

Todas as constantes, thresholds e comportamentos vivem no banco — editáveis pelo admin sem deploy.

```sql
CREATE TABLE agent_config (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  config_key TEXT UNIQUE NOT NULL,
  config_value TEXT NOT NULL,
  config_type TEXT NOT NULL CHECK(config_type IN ('string','number','boolean','json')),
  category TEXT NOT NULL,
  label TEXT NOT NULL,
  description TEXT,
  min_value REAL,
  max_value REAL,
  updated_by TEXT,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

**Consumo no backend:** `await config.get('buffer.debounce_ms')` — cache em memória com TTL 60s, invalidado via evento quando admin altera.

### Categorias de config (seed completo em database_schema.md)

| Categoria | Exemplos de chaves | Qtd |
|---|---|---|
| Buffer | debounce_ms, max_accumulation_ms, abort_on_new_message | 3 |
| Context Window | max_skills_per_call, history_max_messages, compaction_instruction | 10 |
| Output / Judge | max_chars_per_message, max_questions_per_message, min_confidence | 9 |
| Modelo | name, temperature, max_tokens, timeout_ms | 4 |
| Sender | typing_min_ms, inter_message_delay_ms, randomize_delay | 4 |
| Skills | keyword_match_threshold, scoring_mode, global_negative_keywords | 5 |
| Horário Comercial | start_hour, end_hour, timezone, weekend_enabled | 8 |
| Handoff Humano | auto_pause_ai, sentiment_threshold, confidence_threshold, keywords | 6 |
| Reengajamento | enabled, business_hours_only, check_interval_minutes, max_attempts | 4 |
| WhatsApp | session_window_hours, template_reengagement_id, warn_before_close | 3 |
| Lead Scoring | enabled, recalculate_on_save, grade_thresholds | 3 |
| Segurança | jwt_access_expiry_minutes, max_failed_logins, lockout_minutes | 6 |

---

## 3. Buffer — Máquina de 3 Estados

```
mensagem recebida
      │
      ▼
┌──────────────┐
│  ACUMULANDO   │◀── nova msg antes de debounce_ms (reseta timer)
│  (debounce)   │
└──────┬───────┘
       │ timer expira OU max_accumulation_ms
       ▼
┌──────────────┐     Verificações pré-pipeline:
│  PROCESSANDO  │──── 1. Horário comercial?
│  (GPT rodando)│     2. Janela 24h WhatsApp?
└───┬──────┬───┘     3. Handoff ativo?
    │      │         4. Lead descartado/agendado?
GPT ok   nova msg (se abort=true)
    │      │
    ▼      ▼
 ENVIANDO  CANCELANDO → abort GPT + reacumular
```

**Verificações pré-pipeline:**

| Verificação | Config | Se falhar |
|---|---|---|
| Horário comercial | `business.*` | queue ou respond_delayed |
| Janela 24h WhatsApp | `whatsapp.session_window_hours` | Template aprovado |
| Handoff ativo | `human_handoff_queue.ai_paused` | Msg para pending_messages |
| Lead descartado | `leads.stage = 'descartado'` | Ignora (log em audit) |
| Lead agendado | `leads.stage = 'agendado'` | Resposta simplificada |
| Flood protection | 50 msgs/5min por contato | Drop + alerta |

```typescript
interface ContactBuffer {
  contactNumber: string;
  messages: BufferedMessage[];
  timer: NodeJS.Timeout | null;
  abortController: AbortController | null;
  state: 'idle' | 'accumulating' | 'processing';
  firstMessageAt: Date;
}
```

---

## 4. Skills — Configuráveis pelo Frontend

```sql
CREATE TABLE agent_skills (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE NOT NULL,
  category TEXT NOT NULL CHECK(category IN ('core','etapa','situacional','produto')),
  title TEXT NOT NULL,
  description TEXT,
  content TEXT NOT NULL,
  trigger_stage TEXT,
  trigger_keywords TEXT,  -- JSON formato weighted
  trigger_mode TEXT DEFAULT 'auto'
    CHECK(trigger_mode IN ('auto','always','manual','disabled')),
  priority INTEGER DEFAULT 0,
  max_tokens_estimate INTEGER,
  is_active BOOLEAN DEFAULT 1,
  version INTEGER DEFAULT 1,
  created_by TEXT,
  updated_by TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Modos de trigger

| Modo | Comportamento | Uso |
|---|---|---|
| always | Toda chamada | Skills core (identidade, formato) |
| auto | Por stage ou keyword match | Etapas, produtos, objeções |
| manual | Só se explicitamente selecionada | Testes, experimentais |
| disabled | Nunca carrega | Manutenção |

### Keywords ponderadas

```json
{
  "positive": [
    {"keyword": "estoque", "weight": 3},
    {"keyword": "produto acabou", "weight": 4}
  ],
  "negative": [
    {"keyword": "não preciso", "weight": -5}
  ],
  "threshold": 3
}
```

Lógica: soma dos weights das keywords que matcham. Se score ≥ threshold, ativa. Keywords globais negativas (`skills.global_negative_keywords`) desativam qualquer skill de produto.

### Mapa de skills

```
CORE (always)         identidade, formato_whatsapp
ETAPAS (auto/stage)   abertura, qualificacao, ponte_valor, agendamento
SITUACIONAIS (auto/kw) objecoes, descarte, reengajamento, handoff_humano
PRODUTO (auto/kw)     financeiro, estoque, delivery, multi, rh, operacao, producao, relatorios
```

---

## 5. Pipeline de Curadoria — 12 Passos

Ver **agent_docs/pipeline_flow.md** para detalhes de cada passo.

Resumo:
1. Carregar lead + config + recalcular score
2. Verificar pré-condições (janela 24h, handoff, knockout)
3. Selecionar skills (core → etapa → situacional → produto, com tetos)
4. Compactar histórico (observation masking → reversível → sumarização)
5. Montar dados do lead + score/grade
6. Selecionar tools do stage
7. Estimar tokens (warn se > threshold, trim se necessário)
8. Montar payload sandwich + enviar GPT
9. Validar resposta + confidence check
10. Verificar handoff proativo (sentiment, loops, confidence, keywords)
11. Executar tools + atualizar scoring
12. Enviar resposta + persistir + audit completo

Cada passo gera log em `pipeline_audit_logs` com correlation_id.

---

## 6. Payload — Sandwich Method

```
SYSTEM MESSAGE:
┌─────────────────────────────────────────┐
│ [STABLE PREFIX]                          │
│ Skills CORE (identidade + formato)       │
│ Skill da etapa atual                     │
│ Skill de produto (se relevante)          │
│ Skill situacional (se relevante)         │
│                                          │
│ [VARIABLE]                               │
│ Dados do lead + score + grade            │
│ last_client_message_at, handoff_active   │
│                                          │
│ [SANDWICH REFORÇO]                       │
│ Formato JSON, limites, regras            │
│ Lembretes GPT-4.1: persistence,          │
│   tool-calling, planning                 │
│ Handoff instructions                     │
└─────────────────────────────────────────┘

MESSAGES: [sumário se compactado] + [últimas N msgs] + [nova msg do buffer]

TOOLS: só as habilitadas pro stage (campo dedicado da API)
```

### Structured Output

```json
{
  "messages": [
    { "text": "E aí, tudo bem?", "delay_ms": 0 },
    { "text": "Como tá a operação aí?", "delay_ms": 2000 }
  ],
  "internal": {
    "detected_stage": "abertura",
    "detected_intent": "greeting",
    "detected_pain": null,
    "sentiment": "positive",
    "confidence": 0.85,
    "handoff_recommended": false,
    "knockout_detected": false
  }
}
```

---

## 7. Tools do Agente

| Tool | Stages permitidos | O que faz |
|---|---|---|
| save_lead_data | todos | Salva dado + recalcula score |
| update_lead_stage | todos | Avança lead (adjacente only) |
| book_demo | agendamento | Google Calendar + Meet link |
| send_document | ponte_valor, agendamento | Envia doc via WhatsApp |
| flag_for_human | todos | Cria entry no handoff queue |

**Mapeamento stage→tools** em `stage_tool_mapping` (editável no admin).

---

## 8. Judge / Validator

Regras configuráveis via `agent_config` (prefixo `judge.*`):

| Regra | Config | Ação se falhar |
|---|---|---|
| Chars por mensagem | max_chars_per_message (280) | Truncar ou retry |
| Frases por mensagem | max_sentences_per_message (2) | Truncar |
| Perguntas por mensagem | max_questions_per_message (1) | Truncar |
| Msgs no array | max_messages_in_response (3) | Truncar |
| Stage adjacente | enforce_adjacent_stage (true) | Bloquear pulo |
| Confidence mínima | min_confidence_threshold (0.6) | ask_clarification / handoff |

`judge.on_failure`: "adapt" (trunca in-place) ou "retry" (reenvia ao GPT, max 1x).

---

## 9. Lead Scoring

Regras em `lead_scoring_rules` (ver database_schema.md). Recalculado a cada `save_lead_data`.

| Grade | Score | Ação |
|---|---|---|
| A | 80-100 | Prioridade máxima, encurtar qualificação |
| B | 60-79 | Fluxo normal |
| C | 40-59 | Continuar qualificando |
| D | 20-39 | Nurturing leve |
| F | 0-19 ou knockout | Descarte educado |

---

## 10. Handoff Humano

Triggers proativos (detectados no passo 10 do pipeline):

| Trigger | Detecção | Urgência |
|---|---|---|
| client_request | Keywords em `handoff.keywords` | high |
| negative_sentiment | N msgs negativas consecutivas | normal |
| agent_low_confidence | confidence < threshold | normal |
| high_value_lead | Grade A + 2+ msgs sem avanço | high |
| repeated_failure | 2+ falhas no judge | high |

Fluxo: trigger → GPT gera context_summary → msg de transição ao lead → entry na fila → notifica consultor → monitora timeout.

---

## 11. Reengajamento Temporal

Cron job a cada 15min verifica leads silenciosos por stage. Respeita janela 24h WhatsApp (template se fora), horário comercial, e max_global_attempts. Ver database_schema.md para regras seed.

---

## 12. Observabilidade

7 tabelas dedicadas (ver database_schema.md):
- `pipeline_audit_logs` — replay completo de qualquer interação
- `ai_costs` — custo por chamada, por lead, por purpose
- `skill_usage_log` — qual skill ativou, por que, A/B variant
- `unanswered_questions` — fila de perguntas sem resposta → alimenta skills
- `validation_logs` — quais regras do judge falham mais
- `daily_metrics` — snapshot diário para dashboard
- `skill_ab_tests` — A/B testing de skills

---

## 13. Resiliência

- `pending_messages` — mensagens que falharam no pipeline, com retry exponencial
- `dead_letters` — falhas que excederam max_retries, revisão manual
- Recovery worker roda a cada 30s

### 5 Cron Jobs

| Job | Intervalo | Função |
|---|---|---|
| Recovery Worker | 30s | Reprocessar pending_messages |
| Reengajamento | 15min | Follow-up em leads silenciosos |
| Handoff Expiry | 1h | Expirar handoffs pendentes |
| Daily Metrics | 00:00 | Snapshot de métricas do dia |
| WhatsApp Window | 30min | Alertar janelas 24h fechando |

---

## 14. Segurança (integrada em todo o sistema)

| Princípio | Implementação |
|---|---|
| Zero Trust | Validar todo input com Zod, nunca confiar |
| Defense in Depth | Helmet, CORS, rate-limit (4 camadas), auth, Zod |
| Least Privilege | RBAC admin/vendedor/viewer em toda rota |
| Secrets | .env only, nunca agent_config, nunca logs |
| Fail Secure | Erro = negar acesso, msg genérica em prod |
| Audit | security_audit_log para ações sensíveis |
| Encrypt | HTTPS obrigatório em produção |

Auth: JWT access (15min, memória) + refresh (7d, httpOnly cookie). Account lockout após 5 tentativas.

---

## 15. Project Structure

```
backend/src/
├── config/          # agent_config loader (cache 60s)
├── auth/            # JWT, RBAC, password utils
├── security/        # Helmet, CORS, rate-limiter, Zod, webhook-verifier, audit
├── database/        # SQLite, migrations/ (SQL), seeds/ (TypeScript)
├── whatsapp/        # WhatsAppProvider abstração + providers/evolution
├── buffer/          # Máquina 3 estados + business hours
├── curator/         # Skill selector, keyword matcher, compactação 3 níveis
├── pipeline/        # 12 passos com audit
├── tools/           # save_lead_data, update_stage, book_demo, send_doc, flag_for_human
├── judge/           # Validator com regras configuráveis + confidence
├── sender/          # Typing, delay, janela 24h
├── scoring/         # Lead scoring dinâmico
├── handoff/         # Fila + triggers proativos + timeout
├── reengagement/    # Cron rules por stage
├── cron/            # 5 workers
├── observability/   # Audit, costs, metrics
├── websocket/       # Socket.io real-time
└── api/             # REST routes + middleware

frontend/src/app/
├── (auth)/          # Login
├── (dashboard)/     # Layout com sidebar
│   ├── inbox/       # Chat real-time (WebSocket)
│   ├── kanban/      # Pipeline drag-and-drop
│   ├── leads/[id]/  # Perfil do lead
│   ├── dashboard/   # Métricas e funil
│   ├── skills/      # CRUD + editor markdown
│   ├── config/      # agent_config por categoria
│   ├── scoring/     # Regras de scoring
│   ├── handoff/     # Fila pendente
│   └── settings/    # Consultores, system prompt, tools
└── components/      # Compartilhados (shadcn/ui)
```

---

## 16. Adaptações GPT-4.1 Mini

| Característica | Implicação |
|---|---|
| Instruction following literal | Skills explícitas, sem ambiguidade |
| Sandwich method | Core no topo, reforço no fim |
| Tools via API nativa | Nunca injetar no prompt |
| Sem reasoning nativo | CoT explícito nas skills que precisam |
| 3 lembretes obrigatórios | Persistence, tool-calling, planning no reforço |
| Structured Output | response_format com JSON Schema |
