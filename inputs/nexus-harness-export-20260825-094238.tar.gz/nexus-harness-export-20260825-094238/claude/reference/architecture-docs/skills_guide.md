# Guia de Skills — VUCA SDR Agent

Skills são blocos de instrução injetados dinamicamente no system prompt do GPT. O admin cria, edita e ativa skills pelo frontend sem deploy.

---

## 1. Anatomia de uma Skill

```sql
-- Cada skill é uma linha na tabela agent_skills
slug:              'qualificacao'              -- identificador único
category:          'etapa'                     -- core | etapa | situacional | produto
title:             'Qualificação BANT'         -- nome legível
content:           '... instruções ...'        -- o texto injetado no prompt
trigger_stage:     'qualificacao'              -- stage que ativa (para etapas)
trigger_keywords:  '{"positive":[...]}'        -- JSON de keywords (para auto/kw)
trigger_mode:      'auto'                      -- always | auto | manual | disabled
priority:          10                          -- desempate quando há teto
max_tokens_estimate: 300                       -- estimativa para budget
```

---

## 2. Categorias

### CORE (trigger_mode = 'always')
Carregadas em toda chamada. Definem identidade e formato.

| Skill | O que contém |
|---|---|
| identidade | Quem é o agente, tom, personalidade, nome, empresa |
| formato_whatsapp | Regras de formatação: max chars, max frases, uma pergunta por vez, usar [BREAK] |

### ETAPAS (trigger_mode = 'auto', trigger_stage = X)
Ativadas pelo stage do lead. Uma por stage.

| Skill | Stage | O que contém |
|---|---|---|
| abertura | abertura | Como abrir conversa, knockout questions, critério de transição |
| qualificacao | qualificacao | Perguntas BANT, ordem de coleta, critério de transição |
| ponte_valor | ponte_valor | Conectar dor com solução, não despejar features, critério de transição |
| agendamento | agendamento | Pedir a demo, confirmar horário, lidar com hesitação |

### SITUACIONAIS (trigger_mode = 'auto', trigger_keywords)
Ativadas por keywords no texto do lead.

| Skill | Keywords (exemplos) | O que contém |
|---|---|---|
| objecoes | "caro", "não sei", "depois" | Tratamento de objeções comuns |
| descarte | "não tenho restaurante" | Encerrar educadamente |
| reengajamento | (ativado por cron, não keyword) | Retomar após silêncio |
| handoff_humano | "falar com humano", "atendente" | Script de transição |

### PRODUTO (trigger_mode = 'auto', trigger_keywords)
Ativadas quando o lead menciona funcionalidades específicas.

| Skill | Keywords (exemplos) | O que contém |
|---|---|---|
| produto_financeiro | "DRE", "nota fiscal", "financeiro" | Funcionalidades financeiras da VUCA |
| produto_estoque | "estoque", "inventário", "produto acabou" | Funcionalidades de estoque |
| produto_delivery | "iFood", "delivery", "entrega" | Integrações de delivery |
| produto_multi | "franquia", "filiais", "multi-loja" | Multi-unidade e consolidado |
| produto_rh | "funcionário", "ponto", "folha" | Gestão de pessoas |
| produto_operacao | "mesa", "comanda", "KDS" | Operação de salão |
| produto_producao | "cozinha", "produção", "ficha técnica" | Cozinha central |
| produto_relatorios | "relatório", "painel", "métricas" | BI e analytics |

---

## 3. Como Escrever uma Skill Eficaz

### Princípios

1. **Específica e literal.** GPT-4.1 mini faz exatamente o que está escrito. Se você escrever "sugira", ele sugere. Se escrever "implemente", ele implementa. Seja preciso.

2. **Uma responsabilidade.** Cada skill faz uma coisa. Se uma skill está tentando cobrir qualificação E tratamento de objeções, divida em duas.

3. **Critérios de transição.** Toda skill de etapa deve dizer quando transicionar para o próximo stage. Ex: "Quando tiver tipo_operacao, num_unidades e dor_principal preenchidos, use update_lead_stage para avançar."

4. **Tom WhatsApp.** Mensagens curtas, informais, brasileiras. Máximo 2 frases. Uma pergunta por vez. Sem bullet points, sem emojis excessivos, sem linguagem corporativa.

5. **Não repetir instruções globais.** As skills CORE já definem formato e identidade. Não repita essas regras em cada skill de etapa.

### Template de skill de etapa

```markdown
## [Nome da Etapa]

**Objetivo:** [o que o agente deve alcançar nesta etapa]

**Dados a coletar:**
- [campo_1]: [o que perguntar, como perguntar]
- [campo_2]: [o que perguntar, como perguntar]

**Sequência:** Colete um dado por vez, na ordem acima. Quando o lead responde, use save_lead_data para salvar e passe para o próximo.

**Tom:** [instruções específicas de tom para esta etapa]

**Critério de transição:** Quando [condição], use update_lead_stage para avançar para [próximo_stage].

**Se o lead resistir:** [como lidar com resistência nesta etapa]
```

### Template de skill de produto

```markdown
## [Nome do Produto/Módulo]

**Quando usar:** Lead mencionou [dor/necessidade relacionada].

**Conecte dor com solução:**
- Se a dor é [X]: mencione [funcionalidade Y] que resolve
- Se a dor é [Z]: mencione [funcionalidade W] que resolve

**Regra de ouro:** Nunca despejar lista de funcionalidades. Mencione NO MÁXIMO 2 funcionalidades, conectadas diretamente com a dor que o lead expressou.

**Exemplo de boa resposta:**
"Entendi que controle de estoque tá te dando dor de cabeça. A VUCA tem contagem automática com alerta quando produto tá acabando. Quer ver como funciona na demo?"

**Exemplo de resposta ruim:**
"A VUCA tem controle de estoque, contagem, cotação de fornecedores, alerta de estoque mínimo, inventário automático, ficha técnica, custo de receita..."
```

---

## 4. Keywords Ponderadas

### Formato JSON

```json
{
  "positive": [
    {"keyword": "estoque", "weight": 3},
    {"keyword": "contagem", "weight": 2},
    {"keyword": "inventário", "weight": 2},
    {"keyword": "produto acabou", "weight": 4},
    {"keyword": "controle de produto", "weight": 3}
  ],
  "negative": [
    {"keyword": "não preciso", "weight": -5},
    {"keyword": "já tenho sistema de estoque", "weight": -3}
  ],
  "threshold": 3
}
```

### Como funciona
1. Para cada keyword positiva encontrada no texto: soma weight
2. Para cada keyword negativa encontrada: subtrai weight
3. Se score total ≥ threshold da skill: ativa
4. Keywords globais negativas (em agent_config) desativam qualquer skill de produto

### Boas práticas para keywords
- Use frases além de palavras soltas ("produto acabou" > "produto")
- Peso maior = match mais forte (4-5 para frases muito específicas, 1-2 para genéricas)
- Sempre inclua negative keywords para evitar falsos positivos
- Threshold 3 é um bom padrão — exige pelo menos uma keyword forte ou duas médias

---

## 5. Limites e Budget de Tokens

O pipeline respeita estes limites (todos de agent_config):

| Config | Default | Impacto |
|---|---|---|
| context.max_skills_per_call | 5 | Total de skills injetadas |
| context.max_product_skills | 1 | Máximo skills de produto |
| context.max_situational_skills | 1 | Máximo skills situacionais |
| context.max_input_tokens_estimate | 3000 | Alerta se payload exceder |

Cada skill deve ter `max_tokens_estimate` preenchido. O curador usa esse valor para estimar se o payload vai caber no budget.

**Regra prática:** skills de 200-400 tokens são ideais. Acima de 500 tokens, considere dividir.

---

## 6. A/B Testing de Skills

O admin pode criar testes A/B entre duas versões de uma skill:

1. Criar versão B da skill (slug diferente, ex: `qualificacao_v2`)
2. Criar teste em `skill_ab_tests` com skill_id_a e skill_id_b
3. Definir split (default 50/50) e métrica (stage_advance_rate, meeting_booked_rate)
4. Quando o curador seleciona a skill A e há teste ativo: aplica split
5. Variante usada é logada em skill_usage_log (ab_test_variant)
6. Encerrar teste quando min_sample_size atingido

---

## 7. Ciclo de Melhoria

```
Lead faz pergunta que o agente não soube responder
         │
         ▼
unanswered_questions (status: pending)
         │
         ▼
Admin revisa no painel
         │
    ┌────┴────────┐
    │             │
 Resolver      Adicionar a skill
 (ignora)      (expande conteúdo)
                  │
                  ▼
         Skill atualizada → versão incrementada
```

Esse loop garante que o agente melhora continuamente com base em gaps reais detectados em conversas.
