# VUCA SDR Agent

Agente SDR conversacional via WhatsApp que qualifica leads e agenda demos para food service. Plataforma completa: inbox real-time, kanban, dashboard, admin configurável.

## Tech Stack

### Backend
- TypeScript / Node.js 20+ / Express.js
- SQLite via better-sqlite3 (queries diretas, sem ORM)
- OpenAI API (gpt-4.1-mini) com structured output + tools
- Evolution API (WhatsApp — Baileys em dev, Cloud API em prod)
- Socket.io (real-time), node-cron (5 jobs), Whisper API (áudio)

### Frontend
- Next.js 15 (App Router) / Tailwind CSS / shadcn/ui
- Socket.io client / Recharts / @hello-pangea/dnd

## Commands
```
npm run dev              # Backend (watch)
npm run dev:frontend     # Frontend (next dev)
npm run build            # Build ambos
npm run test             # Vitest
npm run migrate          # Migrations SQLite
npm run seed             # Dados iniciais
npm run lint             # ESLint + Prettier
```

## Architecture Decisions
- Zero hardcoded: todo parâmetro vem de agent_config (editável pelo admin)
- Sandwich method: core no topo, reforço no final, dados variáveis no meio
- Tools via campo `tools` da API OpenAI (nunca no prompt)
- Compactação 3 níveis: observation masking → reversível → sumarização
- WhatsAppProvider abstrai Baileys/Cloud API — trocar = mudar config
- Auth: JWT access (15min) + refresh httpOnly (7d), RBAC admin/vendedor/viewer
- Input validation: Zod em todos os endpoints, sem exceção

## Boundaries
- Nunca modificar agent_docs/ (referência, não código)
- Nunca hardcodar valores configuráveis (usar agent_config)
- Nunca injetar tools no system prompt (usar campo tools da API)
- Nunca armazenar API keys em agent_config (usar .env)
- Nunca armazenar tokens em localStorage (access em memória, refresh httpOnly)
- Nunca usar innerHTML/dangerouslySetInnerHTML (usar textContent)
- Nunca concatenar strings em SQL (prepared statements com ?)
- Migrations SQL puro, seeds TypeScript
- Frontend: shadcn/ui exclusivo, um componente por arquivo, named exports

## Key Patterns
- Config: `await config.get('buffer.debounce_ms')` — tipado, cache 60s
- Auth: authenticate → authorize(role) → validateBody(zodSchema) → handler
- Webhook: webhook-verifier (HMAC) → validateBody → handler
- API: REST /api/v1/, todas rotas autenticadas (exceto /auth e /webhook)

## Documentation (ler quando relevante)
- agent_docs/architecture.md    → Design completo, pipeline, buffer, skills
- agent_docs/database_schema.md → DDL 27 tabelas + seeds
- agent_docs/whatsapp.md        → Evolution API, webhook, providers, resiliência
- agent_docs/pipeline_flow.md   → 12 passos do pipeline detalhados
- agent_docs/skills_guide.md    → Como escrever skills, keywords, exemplos

## Before Committing
npm run lint && npm run test
