# Pipeline de Curadoria — 12 Passos Detalhados

Cada passo gera log em `pipeline_audit_logs` com o mesmo `correlation_id`.

---

## Passo 1 — Carregar Lead + Config + Recalcular Score

**Input:** contactNumber do buffer
**Ações:**
- Buscar lead no banco (ou criar novo com stage='abertura')
- Carregar todas as configs de agent_config (cache 60s)
- Se `scoring.recalculate_on_save` e lead tem dados novos: recalcular score
- Gerar correlation_id (uuid v4)
- **AUDIT:** log início do pipeline, lead_id, stage, score, grade

**Output:** lead object, configs carregadas, correlation_id

---

## Passo 2 — Verificar Pré-condições

**Input:** lead, configs, mensagens do buffer
**Verificações (em ordem):**

| # | Verificação | Config | Se falhar |
|---|---|---|---|
| 1 | Lead descartado? | leads.stage | Ignorar + audit |
| 2 | Lead agendado? | leads.stage | Resposta simplificada ou handoff consultor |
| 3 | Handoff ativo? | human_handoff_queue.ai_paused | Salvar em pending_messages para humano |
| 4 | Janela 24h WhatsApp? | whatsapp.session_window_hours | Se fora: template aprovado |
| 5 | Horário comercial? | business.* | Se queue: acumular. Se delayed: processar com delay |
| 6 | Knockout check? | lead_scoring_rules.is_knockout | Se knockout: descarte rápido |

**AUDIT:** log pré-condições verificadas e resultados

**Output:** proceed=true/false, bypass_reason se aplicável

---

## Passo 3 — Selecionar Skills

**Input:** lead.stage, mensagens do buffer (texto), configs
**Lógica (em ordem de prioridade):**

```
1. Skills CORE (trigger_mode = 'always')
   → Sempre: identidade + formato_whatsapp

2. Skill da etapa atual
   → WHERE trigger_stage = lead.stage AND trigger_mode = 'auto'

3. Skills de produto (keyword match ponderado)
   → Se skills.enable_product = true
   → Se scoring_mode = 'weighted': soma de weights ≥ threshold
   → Se scoring_mode = 'binary': 1 keyword basta
   → Verificar global_negative_keywords antes
   → Limite: context.max_product_skills (default 1)

4. Skills situacionais
   → Se skills.enable_situational = true
   → Keyword match no texto do buffer
   → Limite: context.max_situational_skills (default 1)

5. Teto global
   → Se total > context.max_skills_per_call (default 5)
   → Priorizar: core > etapa > situacional > produto
   → Trim excedentes

6. A/B test check
   → Se skill selecionada tem A/B test ativo: aplicar split
```

**AUDIT:** log skills selecionadas, motivo de cada, skills rejeitadas

**Output:** lista de skills com conteúdo

---

## Passo 4 — Compactar Histórico

**Input:** conversations do lead, configs de compactação
**Estratégia em 3 níveis (preferir reversível):**

### Nível 1: Observation Masking (reversível)
- Remover tool outputs antigos do histórico
- Dados de save_lead_data, update_lead_stage já estão no banco
- Substituir por: `[Tool: save_lead_data → campo=valor salvo]`
- Preservar ações e raciocínio, mascarar apenas observações

### Nível 2: Compactação Reversível
- Se ainda > context.history_compaction_threshold msgs
- Remover mensagens de sistema redundantes
- Manter referências em vez de conteúdo completo

### Nível 3: Sumarização Estruturada (lossy, último recurso)
- Se ainda > threshold após nível 2
- Usar context.compaction_instruction (configurável):

```
Sumarize preservando OBRIGATORIAMENTE:
[LEAD] Nome, operação, unidades, sistema atual
[DOR] Dor principal (palavras exatas do cliente)
[DADOS] Todos os campos coletados: campo=valor
[STAGE] Stage atual e razão da última transição
[OBJEÇÕES] Objeções levantadas e tratamento
[COMPROMISSOS] O que foi prometido
[SCORING] Score e grade atual
[CONTEXTO] Tom da conversa, pontos sensíveis
[PENDENTE] Última pergunta ou tema em aberto
Formato: JSON compacto. Máximo 500 tokens.
```

- Manter últimas context.history_keep_recent msgs raw

**AUDIT:** log se compactou, método usado, tokens economizados

**Output:** histórico compactado (sumário + msgs recentes)

---

## Passo 5 — Montar Dados do Lead

**Input:** lead atualizado
**Ações:**
- Extrair campos preenchidos e faltantes
- Incluir lead_score, lead_grade
- Incluir last_client_message_at
- Incluir handoff_active

**Output:** bloco de dados do lead para o payload

---

## Passo 6 — Selecionar Tools do Stage

**Input:** lead.stage
**Ações:**
- Consultar stage_tool_mapping WHERE stage = lead.stage AND is_enabled = true
- **AUDIT:** log tools disponibilizadas

**Output:** lista de tool definitions para o campo `tools` da API

---

## Passo 7 — Estimar Tokens

**Input:** skills + histórico + dados lead + tools
**Ações:**
- Contar tokens estimados do payload completo
- Se > context.max_input_tokens_estimate:
  - WARN no log
  - Trim: reduzir histórico, remover skill de produto se não essencial
  - Re-estimar até ficar abaixo
- Se > 80% do limite do modelo: alertar

**AUDIT:** log estimativa antes e depois de trim

**Output:** payload pronto com estimativa final

---

## Passo 8 — Montar Payload + Enviar GPT

**Input:** todos os outputs anteriores
**Montagem (Sandwich Method):**

```
SYSTEM MESSAGE:
  [STABLE PREFIX]
  - Skills CORE (identidade + formato_whatsapp)
  - Skill da etapa
  - Skill de produto (se selecionada)
  - Skill situacional (se selecionada)

  [VARIABLE]
  - Dados do lead + score + grade
  - Metadados: last_client_message_at, handoff_active

  [SANDWICH REFORÇO]
  - Formato JSON obrigatório
  - Limites: max_chars, max_sentences, max_questions
  - Lembretes GPT-4.1: persistence, tool-calling, planning
  - Handoff instructions

MESSAGES:
  - [Sumário se houve compactação]
  - [Últimas N mensagens raw]
  - [Nova mensagem do buffer] ← sempre por último

TOOLS: (campo dedicado da API)
  - Só tools habilitadas pro stage

RESPONSE_FORMAT:
  - JSON Schema com messages[] + internal{}
```

- Enviar com model.temperature e model.max_tokens da config
- Timeout: model.timeout_ms
- Se timeout: retry 1x. Se falha de novo: salvar em pending_messages.

**AUDIT:** log payload completo (hash), model_name, temperature

**Output:** resposta raw do GPT

---

## Passo 9 — Validar Resposta + Confidence Check

**Input:** resposta do GPT, configs do judge
**Validações:**

| Regra | Config | Ação se falhar |
|---|---|---|
| JSON válido | — | retry (max 1x) |
| chars ≤ max | judge.max_chars_per_message | truncar |
| frases ≤ max | judge.max_sentences_per_message | truncar |
| perguntas ≤ max | judge.max_questions_per_message | remover excedentes |
| msgs ≤ max | judge.max_messages_in_response | truncar array |
| stage adjacente | judge.enforce_adjacent_stage | bloquear tool call |
| confidence ≥ min | judge.min_confidence_threshold | ask_clarification / handoff |

**judge.on_failure:** "adapt" (corrige in-place) ou "retry" (reenvia ao GPT, max judge.max_retries)

**AUDIT:** log pass/fail de cada regra, ação tomada

**Output:** resposta validada (ou adaptada)

---

## Passo 10 — Verificar Handoff Proativo

**Input:** resposta validada, histórico recente, lead
**Detecção de triggers:**

| Trigger | Como detectar |
|---|---|
| client_request | Keywords de handoff.keywords no texto do buffer |
| negative_sentiment | internal.sentiment = 'negative' por N msgs consecutivas |
| agent_low_confidence | internal.confidence < handoff.confidence_threshold |
| repeated_failure | 2+ msgs onde judge validation_passed = false |
| high_value_lead | lead_grade = 'A' + 2+ msgs sem avanço de stage |

Se trigger detectado E handoff.proactive_enabled = true:
- Gerar context_summary via GPT (~200 tokens)
- Adicionar mensagem de transição à resposta
- Criar entry em human_handoff_queue
- Pausar IA se handoff.auto_pause_ai = true

**AUDIT:** log trigger type, summary gerado

**Output:** handoff_triggered boolean, resposta possivelmente modificada

---

## Passo 11 — Executar Tools + Atualizar Scoring

**Input:** tool_calls da resposta do GPT
**Para cada tool call:**

### save_lead_data
1. UPDATE leads SET {field} = {value}
2. Se scoring.recalculate_on_save: recalcular score e grade
3. Se is_knockout: sinalizar para descarte educado
4. Retornar { saved, new_score, new_grade, is_knockout }

### update_lead_stage
1. Verificar adjacência (se enforce_adjacent_stage)
2. UPDATE leads SET stage = {new_stage}
3. **AUDIT:** log transição com reason

### book_demo
1. Buscar próximo consultor (round-robin, respeitando max_demos_per_week)
2. Criar evento Google Calendar + Meet link
3. Salvar em meeting_summaries (com lead_pain_summary)
4. Atualizar lead.stage → 'agendado'
5. Recalcular score
6. Retornar { meet_link, consultant_name, confirmed_datetime }

### send_document
1. Enviar via WhatsAppProvider.sendMedia
2. Logar envio

### flag_for_human
1. Criar entry em human_handoff_queue
2. Se handoff.auto_pause_ai: pausar IA
3. Notificar consultor (WhatsApp/email)
4. Retornar { queued, handoff_id }

**AUDIT:** log cada tool call + resultado + tempo

**Output:** resultados das tools, score atualizado

---

## Passo 12 — Enviar Resposta + Persistir

**Input:** mensagens validadas, lead, correlation_id
**Ações:**

1. Verificar janela 24h antes de cada envio
2. Para cada mensagem no array:
   a. Enviar typing indicator (sender.typing_min_ms a typing_max_ms)
   b. Aguardar delay (sender.inter_message_delay_ms, randomizado se configurado)
   c. Enviar via WhatsAppProvider (ou whatsapp_outbound_queue)
   d. Se falha: salvar em pending_messages
3. Persistir no banco:
   - Mensagens do buffer → conversations (role: user)
   - Mensagens da resposta → conversations (role: assistant)
4. Atualizar lead.last_client_message_at
5. Registrar custos em ai_costs
6. Completar pipeline_audit_logs com todos os campos

**AUDIT:** log pipeline completo — status, duração, mensagens enviadas, erros

**Output:** pipeline_status (success/partial/failed/aborted/handoff)
