# Guia de Execução — VUCA SDR Agent

**Ferramenta:** Claude Code (terminal)
**Estimativa total:** 90-120 dias úteis (1 dev)

---

## Regras de Uso com Claude Code

1. **Uma fase por sessão.** Ao terminar, commite e inicie sessão nova.
2. **Sempre comece** com: `Leia agent_docs/[arquivo relevante] antes de começar.`
3. **Use `/compact`** se a sessão ficar longa (30+ mensagens).
4. **Verifique antes de commitar:** `npm run lint && npm run test`
5. **Se algo falhar 2x:** limpe contexto, sessão nova, prompt melhorado.

---

## Mapa de Fases (22 fases)

```
INFRA + SEGURANÇA (Fase 0)        ██░░░░░░░░░░░░░░░░  ~3 dias
BACKEND CORE (Fases 1-9)          ████████████░░░░░░  ~35-45 dias
REAL-TIME (Fase 10)               █░░░░░░░░░░░░░░░░░  ~3 dias
API + AUTH (Fase 11)              ██░░░░░░░░░░░░░░░░  ~6 dias
SKILLS (Fase 12) — paralelo       ██░░░░░░░░░░░░░░░░  ~5 dias
FRONTEND (Fases 13-19)            ██████████░░░░░░░░  ~30-40 dias
HARDENING (Fase 20)               ██░░░░░░░░░░░░░░░░  ~5 dias
TESTES E2E (Fase 21)              ██░░░░░░░░░░░░░░░░  ~5 dias
DEPLOY (Fase 22)                  █░░░░░░░░░░░░░░░░░  ~3 dias
```

**Caminho crítico:** 0 → 1 → 2 → 3 → 5 → 6 → 7 → 8 → 9 → 10 → 11 → 13 → 14

---

## FASE 0 — Setup Infra + Segurança Base

```
Leia o CLAUDE.md na raiz do projeto.

Crie a estrutura completa do monorepo com segurança desde o dia zero:

1. Inicializar:
   mkdir vuca-sdr-agent && cd vuca-sdr-agent && git init

2. Criar .gitignore ANTES de qualquer outro arquivo:
   node_modules/, dist/, .env, .env.*, !.env.example, *.db, data/, *.log,
   .DS_Store, coverage/, .next/

3. Criar .env.example com placeholders (SEM valores reais):
   NODE_ENV=development
   PORT=3000
   FRONTEND_URL=http://localhost:3001
   DATABASE_PATH=./data/vuca-sdr.db
   JWT_SECRET=GERE_COM_openssl_rand_hex_32
   JWT_REFRESH_SECRET=GERE_OUTRO
   WEBHOOK_SECRET=GERE_OUTRO
   ADMIN_INITIAL_PASSWORD=DEFINA_E_TROQUE
   OPENAI_API_KEY=sk-...
   EVOLUTION_API_URL=http://localhost:8080
   EVOLUTION_API_KEY=GERE_COM_openssl_rand_hex_24
   EVOLUTION_INSTANCE_NAME=vuca-sdr-dev

4. Criar estrutura backend/:
   backend/src/ com pastas: config/, auth/, security/, database/migrations/,
   database/seeds/, whatsapp/providers/, buffer/, curator/, pipeline/, tools/,
   judge/rules/, sender/, scoring/, handoff/, reengagement/, cron/,
   observability/, websocket/, api/routes/, api/middleware/, types/, utils/

5. Criar estrutura frontend/ (Next.js 15 — apenas scaffolding)

6. Backend package.json com dependencies:
   express, better-sqlite3, openai, socket.io, node-cron, uuid, dotenv, cors,
   helmet, express-rate-limit, zod, bcryptjs, jsonwebtoken, hpp, express-slow-down
   DevDeps: typescript, @types/*, vitest, tsx, eslint, prettier

7. docker-compose.dev.yml conforme agent_docs/whatsapp.md seção 5
   Portas expostas SOMENTE para 127.0.0.1 em dev

8. Criar scripts/generate-secrets.sh para gerar todos os secrets

Verificação: .env.example existe sem valores reais. .gitignore inclui .env.
```

---

## FASE 1 — Schema do Banco

```
Leia agent_docs/database_schema.md inteiro.

Crie todas as 27 tabelas em migrations SQL puras:

migrations/001_core.sql         → leads, conversations, consultants, meeting_summaries
migrations/002_auth.sql         → users, refresh_tokens, security_audit_log
migrations/003_prompt_system.sql → system_prompts, agent_config, agent_skills, stage_tool_mapping, prompt_sections
migrations/004_scoring.sql      → lead_scoring_rules
migrations/005_handoff.sql      → human_handoff_queue
migrations/006_reengagement.sql → reengagement_rules, reengagement_log
migrations/007_observability.sql → pipeline_audit_logs, ai_costs, skill_usage_log, unanswered_questions, validation_logs, daily_metrics, skill_ab_tests
migrations/008_resilience.sql   → pending_messages, dead_letters, schema_migrations
migrations/009_whatsapp.sql     → whatsapp_outbound_queue

Criar database/db.ts com:
- Conexão SQLite via better-sqlite3
- Pragmas: WAL, busy_timeout=5000, foreign_keys=ON, secure_delete=ON
- Função runMigrations() que executa migrations em ordem
- Função de health check do banco

Verificação: npm run migrate cria banco sem erros. Todas as 27 tabelas existem.
```

---

## FASE 2 — Config + Seeds + Auth

```
Leia agent_docs/database_schema.md (seção Seed agent_config) e agent_docs/architecture.md (seção 2).

1. Seed de agent_config: todas as categorias da tabela de seeds (65+ chaves)
   Usar TypeScript — seeds/001_agent_config.ts

2. Seed de stage_tool_mapping conforme database_schema.md seção 3
   seeds/002_stage_tool_mapping.ts

3. Seed de lead_scoring_rules conforme database_schema.md seção 4
   seeds/003_scoring_rules.ts

4. Seed de reengagement_rules conforme database_schema.md seção 6
   seeds/004_reengagement_rules.ts

5. Seed do admin user: admin@vuca.com, hash de ADMIN_INITIAL_PASSWORD,
   role=admin, must_change_password=true
   seeds/005_admin_user.ts

6. Config loader (backend/src/config/):
   - get(key): tipado, cache em memória 60s
   - invalidate(): evento para limpar cache (quando admin edita)
   - getAll(category): todas as configs de uma categoria

7. Auth system (backend/src/auth/):
   - password.utils.ts: bcryptjs salt=12, timing-safe compare
   - auth.service.ts: login (com lockout), refresh, logout, changePassword
   - auth.middleware.ts: authenticate (JWT), authorize (RBAC)
   - JWT access (15min, memória) + refresh (7d, httpOnly cookie)
   - Account lockout após 5 falhas × 15min
   - security_audit_log em toda ação de auth

Verificação: npm run seed popula tudo. Config loader retorna valores tipados.
Login funciona. Lockout após 5 tentativas.
```

---

## FASE 3 — WhatsApp Provider + Webhook

```
Leia agent_docs/whatsapp.md inteiro.

1. Interface WhatsAppProvider (whatsapp/whatsapp.provider.ts):
   Conforme agent_docs/whatsapp.md seção 2 — incluindo checkHealth()

2. Evolution Provider (whatsapp/providers/evolution.provider.ts):
   Implementar com:
   - fetchWithRetry (backoff exponencial, 3 tentativas)
   - Timeout de 10s em todas as chamadas
   - Health check com cache 30s
   - downloadAudio com timeout 30s e limite 25MB
   - sendTyping fire-and-forget (nunca bloqueia pipeline)

3. Webhook handler (whatsapp/webhook.handler.ts):
   - parseWebhookMessage conforme agent_docs/whatsapp.md seção 3
   - Zod schema para validar payload
   - Sanitização de texto (prevenir XSS/injection)

4. Webhook route (api/routes/webhook.routes.ts):
   - Verificar assinatura/apikey antes de tudo
   - Rate limit separado (100 req/min por IP)
   - Transcrição de áudio com Whisper (com fallback graceful)
   - Enviar ao buffer (buffer cuida do resto)

5. Security: webhook-verifier.ts
   - Evolution: verificar header apikey
   - Meta Cloud API: HMAC SHA-256 timing-safe

Verificação: webhook sem apikey retorna 401. Payload malformado retorna 400.
Health check retorna status da instância.
```

---

## FASE 4 — Buffer Manager

```
Leia agent_docs/architecture.md seção 3 (Buffer) e pipeline_flow.md passos 1-2.

Implementar máquina de 3 estados (idle/accumulating/processing):

1. buffer.manager.ts:
   - Map<contactNumber, ContactBuffer> em memória
   - handleIncomingMessage: inicia/reseta timer de debounce
   - Timer expira → verificações pré-pipeline → dispara pipeline
   - Abort: se nova msg durante processing E abort_on_new_message = true
   - max_accumulation_ms como safety net (nunca acumula infinitamente)

2. Verificações pré-pipeline (antes de enviar ao GPT):
   - Horário comercial (business.*)
   - Janela 24h WhatsApp
   - Handoff ativo
   - Lead descartado/agendado
   - Flood protection: max 50 msgs/5min por contato

3. Todos os valores de timing vêm de agent_config (nunca hardcoded)

Verificação: testes unitários para cada estado do buffer.
Debounce funciona. Abort cancela processamento. Flood é bloqueado.
```

---

## FASE 5 — Skills + Context Curator

```
Leia agent_docs/architecture.md seção 4 (Skills) e agent_docs/skills_guide.md.

1. Skills CRUD (curator/skills.service.ts):
   - Criar, editar, ativar/desativar, versionar
   - Sanitizar conteúdo da skill antes de injetar (prevenir prompt injection)

2. Keyword matcher (curator/keyword.matcher.ts):
   - Modo weighted: soma de weights, respeitar threshold
   - Modo binary: fallback simples
   - Negative keywords (por skill E globais)

3. Context curator (curator/context.curator.ts):
   - Selecionar skills conforme lógica do pipeline_flow.md passo 3
   - Compactar histórico em 3 níveis (pipeline_flow.md passo 4)
   - Montar dados do lead (passo 5)
   - Estimar tokens (passo 7) — alertar se > threshold, trim se necessário
   - A/B test check (passo 3.6)

4. Skill usage logging (toda seleção é logada com motivo)

Verificação: keyword match retorna scores corretos. Compactação preserva campos obrigatórios.
Teto de skills é respeitado. Estimativa de tokens funciona.
```

---

## FASE 6 — Pipeline + GPT Integration

```
Leia agent_docs/pipeline_flow.md inteiro e agent_docs/architecture.md seção 6 (Payload).

1. Pipeline orchestrator (pipeline/pipeline.ts):
   - Orquestra os 12 passos na sequência
   - Cada passo logado em pipeline_audit_logs
   - Correlation_id único por execução

2. GPT integration (pipeline/gpt.client.ts):
   - Montar payload sandwich method (pipeline_flow.md passo 8)
   - Enviar com model.* configs
   - Structured output via response_format (JSON Schema)
   - Timeout configurável + retry 1x em caso de timeout
   - Backoff exponencial em 429 (rate limit)
   - API key APENAS de .env (nunca agent_config)
   - Validar resposta com Zod antes de processar
   - NUNCA logar API key em nenhum nível

3. Cost tracker (observability/cost.tracker.ts):
   - Registrar tokens input/output/cached, custo por chamada
   - Separar por purpose: chat, compaction, transcription, scoring, handoff_summary

Verificação: pipeline roda end-to-end com mock GPT. Audit log completo.
Custos registrados. API key não aparece em logs.
```

---

## FASE 7 — Judge + Scoring + Handoff Detection

```
Leia agent_docs/pipeline_flow.md passos 9, 10 e agent_docs/architecture.md seções 8, 9, 10.

1. Judge / Validator (judge/validator.ts):
   - Todas as regras configuráveis via agent_config (judge.*)
   - on_failure: "adapt" (trunca) ou "retry" (max 1x)
   - Logar cada validação em validation_logs

2. Lead Scoring (scoring/scoring.service.ts):
   - Carregar regras ativas de lead_scoring_rules
   - evaluateRule para cada operador
   - Clamp 0-100, determinar grade
   - Detectar knockouts
   - Recalcular a cada save_lead_data

3. Handoff detector (handoff/handoff.detector.ts):
   - Verificar triggers proativos: keywords, sentiment, confidence, loops, high_value
   - Se trigger: gerar context_summary via GPT
   - Criar entry em human_handoff_queue
   - Pausar IA se configurado

Verificação: judge trunca mensagens longas. Score calcula corretamente.
Knockout dispara descarte. Handoff detecta keywords.
```

---

## FASE 8 — Tool Executors

```
Leia agent_docs/pipeline_flow.md passo 11 e agent_docs/architecture.md seção 7.

Implementar cada tool:

1. save_lead_data: salvar + recalcular score + detectar knockout
2. update_lead_stage: validar adjacência + atualizar
3. book_demo: buscar consultor (round-robin) + Google Calendar + Meet link
4. send_document: enviar via WhatsAppProvider
5. flag_for_human: criar handoff + pausar IA + notificar

Cada tool retorna resultado estruturado para o GPT processar.
Cada execução logada em pipeline_audit_logs.

Verificação: cada tool executada isoladamente funciona. Scoring atualiza após save.
Stage adjacente é validado.
```

---

## FASE 9 — Sender + Outbound Queue

```
Leia agent_docs/whatsapp.md seção 4 (Outbound Queue) e agent_docs/architecture.md seção 3.

1. Sender (sender/sender.ts):
   - Enviar typing indicator (fire-and-forget)
   - Delay entre mensagens (randomizado se configurado)
   - Verificar janela 24h antes de cada envio
   - Se fora da janela: usar template

2. Outbound queue:
   - Todas as mensagens passam pela whatsapp_outbound_queue
   - Worker processa fila: enviar → marcar sent / retry em falha
   - Max retries com backoff → dead_letters se exceder
   - Garante zero mensagem perdida se Evolution cair

3. Persistir conversas no banco após envio confirmado

Verificação: mensagens enfileiradas e enviadas. Retry funciona em falhas.
Delay entre mensagens é humanizado.
```

---

## FASE 10 — WebSocket + Real-time

```
1. Socket.io server (websocket/):
   - Autenticação por JWT no handshake
   - Rooms por contactNumber
   - Eventos: new_message, lead_updated, handoff_created, notification

2. Emitir eventos em tempo real de:
   - Pipeline (nova mensagem processada)
   - Handoff (novo item na fila)
   - Scoring (lead grade mudou)

Verificação: frontend recebe mensagens em tempo real. Auth no socket funciona.
```

---

## FASE 11 — REST API

```
1. Todas as rotas com prefixo /api/v1/
2. Middleware chain: authenticate → authorize(role) → validateBody(Zod) → handler
3. Rate limiting em 4 camadas: global, auth, webhook, socket

Endpoints:
- /auth: login, refresh, logout, change-password
- /leads: CRUD, filtros, perfil completo
- /conversations: por lead, paginado
- /skills: CRUD, ativar/desativar, versionar
- /config: listar por categoria, editar (invalida cache)
- /scoring: CRUD regras, preview score
- /handoff: fila, atribuir, resolver
- /consultants: CRUD, round-robin
- /dashboard: métricas, funil, custos
- /audit: pipeline logs, filtros
- /unanswered: fila, resolver, adicionar a skill

Verificação: todas as rotas autenticadas (exceto /auth e /webhook).
RBAC funciona. Zod rejeita payloads inválidos.
```

---

## FASE 12 — Skills Content (paralelo)

```
Leia agent_docs/skills_guide.md inteiro.

Escrever o conteúdo de cada skill:

CORE: identidade, formato_whatsapp
ETAPAS: abertura, qualificacao, ponte_valor, agendamento
SITUACIONAIS: objecoes, descarte, reengajamento, handoff_humano
PRODUTO: financeiro, estoque, delivery, multi, rh, operacao, producao, relatorios

Total: 16+ skills. Cada uma seguindo os templates do skills_guide.md.
Incluir keywords ponderadas para skills situacionais e de produto.

Seed em: seeds/006_skills.ts

Verificação: todas as skills no banco. Keywords ponderadas configuradas.
```

---

## FASES 13-19 — Frontend

```
Fase 13: Layout base (Next.js 15, Tailwind, shadcn, sidebar, navbar)
Fase 14: Auth (login, refresh automático, proteção de rotas, RBAC visual)
Fase 15: Inbox (chat real-time via WebSocket, lista de conversas, status do lead)
Fase 16: Kanban (drag-and-drop por stage, badges de score/grade)
Fase 17: Lead profile (dados, histórico, score breakdown, resumo IA)
Fase 18: Dashboard (métricas, funil, custos, tendências — Recharts)
Fase 19: Admin pages (skills CRUD, config editor, scoring rules, handoff queue,
         consultants, system prompt versioning, audit viewer, unanswered questions)

Cada fase: um prompt para Claude Code, uma sessão, um commit.
Ler agent_docs/architecture.md seção 15 (Project Structure) antes de cada fase.
```

---

## FASE 20 — Security Hardening

```
1. Penetration testing manual:
   - SQL injection em todos os inputs
   - XSS em mensagens de chat
   - JWT manipulation (expirado, forjado, refresh stolen)
   - Webhook spoofing (sem assinatura, assinatura errada)
   - Rate limit bypass attempts
   - RBAC bypass (viewer tentando ações de admin)

2. Helmet headers corretos em produção
3. CORS restrito ao FRONTEND_URL
4. Remover stack traces de erros em produção
5. Verificar que nenhum secret aparece em logs
6. Content Security Policy headers
```

---

## FASE 21 — Testes E2E

```
1. Fluxo completo: webhook → buffer → pipeline → GPT → judge → sender → WhatsApp
2. Reengajamento: cron dispara → mensagem enviada → lead responde → cron para
3. Handoff: trigger → fila → notificação → consultor resolve → IA resume
4. Scoring: knockout → descarte automático
5. Compactação: conversa longa → compacta → contexto preservado
6. Resiliência: GPT timeout → pending_messages → recovery → success
7. Auth: login → refresh → lockout → unlock
```

---

## FASE 22 — Deploy

```
1. VPS com HTTPS (Let's Encrypt)
2. PM2 para processo Node.js (backend)
3. Evolution API em Docker com Cloud API configurada
4. Nginx reverse proxy (backend + frontend + Evolution)
5. Backup automático do SQLite (cron diário)
6. Monitoramento: health check endpoints, alertas de erro
7. .env de produção com secrets fortes
8. Templates WhatsApp aprovados pelo Meta
```
