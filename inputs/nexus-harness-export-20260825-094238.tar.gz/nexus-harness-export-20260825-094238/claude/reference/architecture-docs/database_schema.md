# Database Schema — VUCA SDR Agent

**Engine:** SQLite via better-sqlite3 | **Total: 27 tabelas** | **Migrations: SQL puro, Seeds: TypeScript**

**Pragmas obrigatórios (no db.ts):**
```sql
PRAGMA journal_mode = WAL;
PRAGMA busy_timeout = 5000;
PRAGMA foreign_keys = ON;
PRAGMA secure_delete = ON;
```

---

## Domínios

| Domínio | Tabelas | Qtd |
|---|---|---|
| Core do Negócio | leads, conversations, consultants, meeting_summaries | 4 |
| Auth & Security | users, refresh_tokens, security_audit_log | 3 |
| Sistema de Prompt/IA | system_prompts, agent_config, agent_skills, stage_tool_mapping, prompt_sections | 5 |
| Scoring & Qualificação | lead_scoring_rules | 1 |
| Handoff Humano | human_handoff_queue | 1 |
| Reengajamento | reengagement_rules, reengagement_log | 2 |
| Observabilidade | pipeline_audit_logs, ai_costs, skill_usage_log, unanswered_questions, validation_logs, daily_metrics, skill_ab_tests | 7 |
| Resiliência | pending_messages, dead_letters, schema_migrations | 3 |
| Controle de WhatsApp | whatsapp_outbound_queue | 1 |

---

## 1. Core do Negócio

```sql
CREATE TABLE leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_number TEXT UNIQUE NOT NULL,
  name TEXT,
  stage TEXT DEFAULT 'abertura'
    CHECK(stage IN ('abertura','qualificacao','ponte_valor','agendamento','agendado','descartado')),
  tipo_operacao TEXT,
  num_unidades INTEGER,
  sistema_atual TEXT,
  dor_principal TEXT,
  faturamento_estimado TEXT,
  email TEXT,
  cargo TEXT,
  empresa TEXT,
  segmento TEXT,
  sentiment TEXT CHECK(sentiment IN ('positive','neutral','negative','unknown')),
  notes TEXT,
  source TEXT,
  lead_score INTEGER DEFAULT 0,
  lead_grade TEXT DEFAULT 'C' CHECK(lead_grade IN ('A','B','C','D','F')),
  is_icp BOOLEAN,
  scored_at DATETIME,
  last_client_message_at DATETIME,
  handoff_active BOOLEAN DEFAULT 0,
  discard_reason TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_leads_stage ON leads(stage);
CREATE INDEX idx_leads_contact ON leads(contact_number);
CREATE INDEX idx_leads_grade ON leads(lead_grade);
CREATE INDEX idx_leads_score ON leads(lead_score DESC);

CREATE TABLE conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_number TEXT NOT NULL,
  lead_id INTEGER REFERENCES leads(id),
  role TEXT NOT NULL CHECK(role IN ('user','assistant','system','summary')),
  content TEXT NOT NULL,
  message_type TEXT DEFAULT 'text'
    CHECK(message_type IN ('text','audio','image','document','summary')),
  is_summary BOOLEAN DEFAULT 0,
  token_count INTEGER,
  correlation_id TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_conversations_contact ON conversations(contact_number, created_at);
CREATE INDEX idx_conversations_lead ON conversations(lead_id);

CREATE TABLE consultants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  google_calendar_id TEXT,
  specialization TEXT,
  is_active BOOLEAN DEFAULT 1,
  queue_position INTEGER DEFAULT 0,
  max_demos_per_week INTEGER DEFAULT 20,
  current_demos_this_week INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE meeting_summaries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL REFERENCES leads(id),
  consultant_id INTEGER REFERENCES consultants(id),
  scheduled_date DATE NOT NULL,
  scheduled_time TIME NOT NULL,
  google_meet_link TEXT,
  google_event_id TEXT,
  meet_link_sent BOOLEAN DEFAULT 0,
  meet_link_sent_at DATETIME,
  status TEXT DEFAULT 'agendada'
    CHECK(status IN ('agendada','realizada','cancelada','no_show','reagendada')),
  lead_pain_summary TEXT,
  lead_score_at_booking INTEGER,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## 2. Auth & Security

```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'vendedor' CHECK(role IN ('admin','vendedor','viewer')),
  is_active BOOLEAN DEFAULT 1,
  last_login_at DATETIME,
  failed_login_attempts INTEGER DEFAULT 0,
  locked_until DATETIME,
  must_change_password BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);

CREATE TABLE refresh_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  token_hash TEXT NOT NULL,
  expires_at DATETIME NOT NULL,
  revoked BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id, revoked);

CREATE TABLE security_audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  details TEXT,
  success BOOLEAN NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_security_audit_action ON security_audit_log(action, created_at);
```

**Seed:** admin@vuca.com / hash de ADMIN_INITIAL_PASSWORD do .env / role=admin / must_change_password=true

---

## 3. Sistema de Prompt/IA

```sql
CREATE TABLE system_prompts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  version INTEGER NOT NULL,
  content TEXT NOT NULL,
  is_active BOOLEAN DEFAULT 0,
  notes TEXT,
  created_by TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- agent_config: ver seção dedicada abaixo
-- agent_skills: ver architecture.md seção 4

CREATE TABLE stage_tool_mapping (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  stage TEXT NOT NULL,
  tool_name TEXT NOT NULL,
  is_enabled BOOLEAN DEFAULT 1,
  UNIQUE(stage, tool_name)
);

CREATE TABLE prompt_sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  section_order INTEGER NOT NULL,
  is_active BOOLEAN DEFAULT 1,
  version INTEGER DEFAULT 1,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Seed: stage_tool_mapping

| stage | tool_name |
|---|---|
| abertura | save_lead_data, update_lead_stage, flag_for_human |
| qualificacao | save_lead_data, update_lead_stage, flag_for_human |
| ponte_valor | save_lead_data, update_lead_stage, send_document, flag_for_human |
| agendamento | save_lead_data, update_lead_stage, book_demo, send_document, flag_for_human |

---

## 4. Scoring & Qualificação

```sql
CREATE TABLE lead_scoring_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  field_name TEXT NOT NULL,
  operator TEXT NOT NULL CHECK(operator IN ('eq','neq','gt','gte','lt','lte','contains','not_contains','in','not_in','exists','not_exists')),
  value TEXT NOT NULL,
  points INTEGER NOT NULL,
  category TEXT NOT NULL CHECK(category IN ('fit','intent','engagement','timing')),
  is_knockout BOOLEAN DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  description TEXT,
  created_by TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_scoring_active ON lead_scoring_rules(is_active);
```

### Seed: regras de scoring

**Fit:** tipo_operacao IN food_service (+15), num_unidades ≥ 3 (+20), num_unidades ≥ 1 (+10), cargo contains "proprietário" (+15), cargo contains "gerente" (+10), segmento eq "estudante" (-50, knockout)

**Intent:** dor_principal exists (+20), sistema_atual exists (+10), faturamento_estimado ≥ 50000 (+15)

**Engagement:** stage eq qualificacao (+10), ponte_valor (+20), agendamento (+30), sentiment positive (+10), negative (-10)

---

## 5. Handoff Humano

```sql
CREATE TABLE human_handoff_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL REFERENCES leads(id),
  contact_number TEXT NOT NULL,
  trigger_type TEXT NOT NULL CHECK(trigger_type IN (
    'client_request','negative_sentiment','agent_low_confidence',
    'out_of_scope','high_value_lead','repeated_failure','manual'
  )),
  urgency TEXT DEFAULT 'normal' CHECK(urgency IN ('low','normal','high','critical')),
  context_summary TEXT NOT NULL,
  lead_data_snapshot TEXT NOT NULL,
  conversation_excerpt TEXT,
  assigned_to INTEGER REFERENCES consultants(id),
  status TEXT DEFAULT 'pending' CHECK(status IN ('pending','assigned','in_progress','resolved','expired')),
  ai_paused BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  assigned_at DATETIME,
  resolved_at DATETIME,
  resolution_notes TEXT,
  resolution_outcome TEXT CHECK(resolution_outcome IN ('meeting_booked','lead_nurtured','lead_disqualified','issue_resolved','no_response'))
);

CREATE INDEX idx_handoff_status ON human_handoff_queue(status, urgency);
CREATE INDEX idx_handoff_contact ON human_handoff_queue(contact_number);
```

---

## 6. Reengajamento

```sql
CREATE TABLE reengagement_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  stage TEXT NOT NULL,
  hours_since_last_message INTEGER NOT NULL,
  attempt_number INTEGER NOT NULL DEFAULT 1,
  max_attempts INTEGER DEFAULT 3,
  skill_slug TEXT,
  message_template TEXT,
  use_whatsapp_template BOOLEAN DEFAULT 0,
  whatsapp_template_id TEXT,
  is_active BOOLEAN DEFAULT 1,
  created_by TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reengagement_stage ON reengagement_rules(stage, is_active);

CREATE TABLE reengagement_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL REFERENCES leads(id),
  contact_number TEXT NOT NULL,
  rule_id INTEGER NOT NULL REFERENCES reengagement_rules(id),
  attempt_number INTEGER NOT NULL,
  sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  used_whatsapp_template BOOLEAN DEFAULT 0,
  got_response BOOLEAN DEFAULT 0,
  response_at DATETIME,
  correlation_id TEXT
);

CREATE INDEX idx_reengagement_lead ON reengagement_log(lead_id, sent_at);
```

### Seed: regras de reengajamento

| stage | horas | tentativa | skill/template | usa template WhatsApp |
|---|---|---|---|---|
| abertura | 2 | 1 | reengajamento_abertura_1 | não |
| abertura | 24 | 2 | reengajamento_abertura_2 | sim |
| qualificacao | 4 | 1 | reengajamento_qualificacao_1 | não |
| qualificacao | 24 | 2 | reengajamento_qualificacao_2 | sim |
| qualificacao | 72 | 3 | reengajamento_ultima_tentativa | sim |
| ponte_valor | 6 | 1 | reengajamento_ponte_1 | não |
| ponte_valor | 48 | 2 | reengajamento_ponte_2 | sim |
| agendamento | 2 | 1 | reengajamento_agendamento_1 | não |
| agendamento | 12 | 2 | reengajamento_agendamento_2 | não |
| agendamento | 48 | 3 | reengajamento_ultima_tentativa | sim |

---

## 7. Observabilidade

```sql
CREATE TABLE pipeline_audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  correlation_id TEXT UNIQUE NOT NULL,
  contact_number TEXT NOT NULL,
  lead_id INTEGER,
  lead_stage TEXT,
  lead_score INTEGER,
  lead_grade TEXT,
  buffer_messages TEXT NOT NULL,
  buffer_state TEXT,
  buffer_was_reaccumulated BOOLEAN DEFAULT 0,
  whatsapp_window_open BOOLEAN,
  handoff_was_active BOOLEAN DEFAULT 0,
  business_hours_check TEXT,
  skills_selected TEXT NOT NULL,
  skills_rejected TEXT,
  ab_test_variants TEXT,
  tools_available TEXT NOT NULL,
  history_messages_count INTEGER,
  history_was_compacted BOOLEAN DEFAULT 0,
  compaction_method TEXT,
  tokens_input_estimate INTEGER,
  system_prompt_assembled TEXT,
  full_payload_hash TEXT,
  model_name TEXT,
  model_temperature REAL,
  response_raw TEXT,
  tokens_input_actual INTEGER,
  tokens_output_actual INTEGER,
  response_time_ms INTEGER,
  validation_passed BOOLEAN,
  validation_errors TEXT,
  response_adapted TEXT,
  response_confidence REAL,
  handoff_triggered BOOLEAN DEFAULT 0,
  handoff_trigger_type TEXT,
  tool_calls TEXT,
  scoring_updated BOOLEAN DEFAULT 0,
  messages_sent INTEGER,
  send_errors TEXT,
  used_whatsapp_template BOOLEAN DEFAULT 0,
  pipeline_status TEXT NOT NULL
    CHECK(pipeline_status IN ('success','partial','failed','aborted','handoff')),
  error_phase TEXT,
  error_message TEXT,
  error_stack TEXT,
  pipeline_duration_ms INTEGER,
  started_at DATETIME NOT NULL,
  completed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_contact ON pipeline_audit_logs(contact_number, created_at);
CREATE INDEX idx_audit_correlation ON pipeline_audit_logs(correlation_id);
CREATE INDEX idx_audit_status ON pipeline_audit_logs(pipeline_status);

CREATE TABLE ai_costs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  correlation_id TEXT NOT NULL,
  contact_number TEXT NOT NULL,
  model TEXT NOT NULL,
  purpose TEXT NOT NULL CHECK(purpose IN ('chat','compaction','transcription','scoring','handoff_summary')),
  tokens_input INTEGER NOT NULL,
  tokens_output INTEGER NOT NULL,
  tokens_cached INTEGER DEFAULT 0,
  cost_input_usd REAL NOT NULL,
  cost_output_usd REAL NOT NULL,
  cost_total_usd REAL NOT NULL,
  response_time_ms INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_costs_date ON ai_costs(created_at);
CREATE INDEX idx_costs_purpose ON ai_costs(purpose);

CREATE TABLE skill_usage_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  correlation_id TEXT NOT NULL,
  contact_number TEXT NOT NULL,
  lead_stage TEXT NOT NULL,
  skill_id INTEGER NOT NULL,
  skill_slug TEXT NOT NULL,
  trigger_reason TEXT NOT NULL,
  matched_keywords TEXT,
  keyword_score INTEGER,
  ab_test_id INTEGER,
  ab_test_variant TEXT CHECK(ab_test_variant IN ('a','b')),
  tokens_estimate INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_skill_usage_skill ON skill_usage_log(skill_slug);

CREATE TABLE unanswered_questions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  correlation_id TEXT,
  contact_number TEXT NOT NULL,
  lead_id INTEGER REFERENCES leads(id),
  question_text TEXT NOT NULL,
  agent_response TEXT,
  context_stage TEXT,
  status TEXT DEFAULT 'pending'
    CHECK(status IN ('pending','resolved','ignored','added_to_skill')),
  resolution_notes TEXT,
  resolved_by TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME
);

CREATE INDEX idx_unanswered_status ON unanswered_questions(status);

CREATE TABLE validation_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  correlation_id TEXT NOT NULL,
  contact_number TEXT NOT NULL,
  rule_name TEXT NOT NULL,
  rule_config_value TEXT,
  expected TEXT NOT NULL,
  actual TEXT NOT NULL,
  passed BOOLEAN NOT NULL,
  action_taken TEXT,
  details TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_validation_rule ON validation_logs(rule_name, passed);

CREATE TABLE daily_metrics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  metric_date DATE NOT NULL,
  leads_by_stage TEXT NOT NULL,
  new_leads_today INTEGER DEFAULT 0,
  conversions_today INTEGER DEFAULT 0,
  meetings_booked_today INTEGER DEFAULT 0,
  handoffs_today INTEGER DEFAULT 0,
  reengagements_sent_today INTEGER DEFAULT 0,
  reengagements_responded_today INTEGER DEFAULT 0,
  avg_response_time_ms INTEGER,
  avg_messages_per_lead REAL,
  avg_lead_score REAL,
  total_cost_usd REAL,
  cost_per_lead_usd REAL,
  cost_per_meeting_usd REAL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(metric_date)
);

CREATE TABLE skill_ab_tests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  skill_id_a INTEGER NOT NULL REFERENCES agent_skills(id),
  skill_id_b INTEGER NOT NULL REFERENCES agent_skills(id),
  split_percentage INTEGER DEFAULT 50,
  metric_to_track TEXT NOT NULL CHECK(metric_to_track IN ('stage_advance_rate','meeting_booked_rate','response_rate','sentiment_positive_rate')),
  min_sample_size INTEGER DEFAULT 50,
  status TEXT DEFAULT 'draft' CHECK(status IN ('draft','running','completed','cancelled')),
  started_at DATETIME,
  ended_at DATETIME,
  winner TEXT CHECK(winner IN ('a','b','inconclusive')),
  results_summary TEXT,
  created_by TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## 8. Resiliência

```sql
CREATE TABLE pending_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_number TEXT NOT NULL,
  messages_json TEXT NOT NULL,
  original_webhook_payload TEXT,
  failure_reason TEXT NOT NULL,
  retry_count INTEGER DEFAULT 0,
  max_retries INTEGER DEFAULT 3,
  next_retry_at DATETIME,
  status TEXT DEFAULT 'pending'
    CHECK(status IN ('pending','processing','completed','dead')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_pending_status ON pending_messages(status, next_retry_at);

CREATE TABLE dead_letters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_number TEXT NOT NULL,
  source TEXT NOT NULL,
  original_data TEXT NOT NULL,
  error_history TEXT NOT NULL,
  correlation_id TEXT,
  status TEXT DEFAULT 'unresolved'
    CHECK(status IN ('unresolved','retried','resolved','ignored')),
  resolved_by TEXT,
  resolution_notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME
);

CREATE INDEX idx_dead_letters_status ON dead_letters(status);

CREATE TABLE schema_migrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  version TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## 9. Controle WhatsApp

```sql
CREATE TABLE whatsapp_outbound_queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_number TEXT NOT NULL,
  message_text TEXT,
  message_type TEXT DEFAULT 'text' CHECK(message_type IN ('text','template','media','buttons')),
  template_name TEXT,
  template_params TEXT,
  media_url TEXT,
  priority INTEGER DEFAULT 0,
  correlation_id TEXT,
  status TEXT DEFAULT 'queued' CHECK(status IN ('queued','sending','sent','failed','dead')),
  retry_count INTEGER DEFAULT 0,
  max_retries INTEGER DEFAULT 3,
  last_error TEXT,
  scheduled_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  sent_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_outbound_status ON whatsapp_outbound_queue(status, scheduled_at);
CREATE INDEX idx_outbound_contact ON whatsapp_outbound_queue(contact_number);
```

---

## Seed Completo: agent_config

### Buffer
| key | value | type |
|---|---|---|
| buffer.debounce_ms | 5000 | number |
| buffer.max_accumulation_ms | 120000 | number |
| buffer.abort_on_new_message | true | boolean |

### Context Window
| key | value | type |
|---|---|---|
| context.max_skills_per_call | 5 | number |
| context.max_product_skills | 1 | number |
| context.max_situational_skills | 1 | number |
| context.always_load_core | true | boolean |
| context.history_max_messages | 15 | number |
| context.history_compaction_threshold | 30 | number |
| context.history_keep_recent | 8 | number |
| context.max_input_tokens_estimate | 3000 | number |
| context.compaction_instruction | *(ver architecture.md seção compactação)* | string |
| context.compaction_preserve_fields | ["name","tipo_operacao","dor_principal","stage"] | json |

### Output / Judge
| key | value | type |
|---|---|---|
| judge.max_chars_per_message | 280 | number |
| judge.max_sentences_per_message | 2 | number |
| judge.max_questions_per_message | 1 | number |
| judge.max_messages_in_response | 3 | number |
| judge.enforce_adjacent_stage | true | boolean |
| judge.on_failure | adapt | string |
| judge.max_retries | 1 | number |
| judge.min_confidence_threshold | 0.6 | number |
| judge.low_confidence_behavior | ask_clarification | string |

### Modelo
| key | value | type |
|---|---|---|
| model.name | gpt-4.1-mini | string |
| model.temperature | 0.7 | number |
| model.max_tokens | 500 | number |
| model.timeout_ms | 30000 | number |

### Sender
| key | value | type |
|---|---|---|
| sender.typing_min_ms | 1000 | number |
| sender.typing_max_ms | 3000 | number |
| sender.inter_message_delay_ms | 2000 | number |
| sender.randomize_delay | true | boolean |

### Skills
| key | value | type |
|---|---|---|
| skills.keyword_match_threshold | 3 | number |
| skills.keyword_scoring_mode | weighted | string |
| skills.global_negative_keywords | ["não quero saber","depois eu vejo"] | json |
| skills.enable_situational | true | boolean |
| skills.enable_product | true | boolean |

### Horário Comercial
| key | value | type |
|---|---|---|
| business.enabled | true | boolean |
| business.start_hour | 08:00 | string |
| business.end_hour | 20:00 | string |
| business.timezone | America/Sao_Paulo | string |
| business.weekend_enabled | false | boolean |
| business.off_hours_behavior | respond_delayed | string |
| business.off_hours_delay_min_ms | 300000 | number |
| business.off_hours_delay_max_ms | 900000 | number |

### Handoff
| key | value | type |
|---|---|---|
| handoff.auto_pause_ai | true | boolean |
| handoff.resume_ai_after_hours | 24 | number |
| handoff.sentiment_threshold | 3 | number |
| handoff.confidence_threshold | 0.5 | number |
| handoff.keywords | ["falar com humano","atendente","pessoa real","não quero robô"] | json |
| handoff.proactive_enabled | true | boolean |

### Reengajamento
| key | value | type |
|---|---|---|
| reengagement.enabled | true | boolean |
| reengagement.business_hours_only | true | boolean |
| reengagement.check_interval_minutes | 15 | number |
| reengagement.max_global_attempts | 5 | number |

### WhatsApp
| key | value | type |
|---|---|---|
| whatsapp.session_window_hours | 24 | number |
| whatsapp.template_reengagement_id | | string |
| whatsapp.warn_before_window_close_hours | 2 | number |

### Scoring
| key | value | type |
|---|---|---|
| scoring.enabled | true | boolean |
| scoring.recalculate_on_save | true | boolean |
| scoring.grade_thresholds | {"A":80,"B":60,"C":40,"D":20} | json |

### Segurança
| key | value | type |
|---|---|---|
| security.jwt_access_expiry_minutes | 15 | number |
| security.jwt_refresh_expiry_days | 7 | number |
| security.max_failed_logins | 5 | number |
| security.lockout_minutes | 15 | number |
| security.password_min_length | 8 | number |
| security.force_password_change_on_first_login | true | boolean |
