# Claude Developer Toolkit — Pacote Completo 2026

> Tudo que um desenvolvedor avançado precisa para maximizar produtividade com Claude.
> Baseado em repositórios com 200k+ stars combinados e práticas reais de milhares de devs.

---

## 📦 Conteúdo do Pacote

### 1. CLAUDE.md (Templates)
| Arquivo | Destino | Propósito |
|---------|---------|-----------|
| `CLAUDE.md.global` | `~/.claude/CLAUDE.md` | Regras globais para todas as sessões |
| `CLAUDE.md.project` | `./CLAUDE.md` (raiz do repo) | Regras específicas do projeto |

**Por que importa:** CLAUDE.md é a configuração de maior alavancagem. Modelos frontier seguem ~150-200 instruções de forma confiável. Mantenha abaixo de 300 linhas.

### 2. Configuração MCP (`mcp.json`)
| Server | Stars | Propósito |
|--------|-------|-----------|
| Context7 | 13.7k | Documentação atualizada de libraries (elimina hallucination) |
| GitHub MCP | 4k | PRs, issues, code search, branches |
| Git MCP | — | Operações git locais (sem API key) |
| PostgreSQL MCP | 1.8k | Queries read-only + schema inspection |
| Playwright MCP | 5.5k | Automação de browser e testes |
| Sequential Thinking | 6.6k | Raciocínio estruturado step-by-step |

**Instalação rápida (os 2 mais importantes):**
```bash
claude mcp add context7 --transport http https://mcp.context7.com/mcp
claude mcp add github -- npx -y @modelcontextprotocol/server-github
```

### 3. Slash Commands (6 comandos)
| Comando | O que faz |
|---------|-----------|
| `/commit` | Gera commit message Conventional Commits a partir do diff |
| `/review` | Code review focado em bugs, segurança e qualidade |
| `/plan` | Planejamento estruturado: Explore → Plan → Spec → Execute |
| `/branch` | Cria feature branch com nome padronizado |
| `/push` | Push seguro com pré-checks (testes, lint, branch protection) |
| `/pr` | Cria Pull Request com descrição estruturada |

**Workflow completo:** `/branch "add auth"` → trabalho → `/commit` → `/push` → `/pr` → `/review`

### 4. Hooks (Enforcement Determinístico)
| Hook | Tipo | O que faz |
|------|------|-----------|
| Auto-format Python | PostToolUse | Roda black + isort após cada write em .py |
| Auto-format JS/TS | PostToolUse | Roda prettier após cada write em .ts/.tsx/.js/.jsx |
| Auto-format Go | PostToolUse | Roda gofmt após cada write em .go |
| Block destructive cmds | PreToolUse | Bloqueia rm -rf, git push --force, DROP TABLE |
| Block push to main | PreToolUse | Impede push direto para main/master |
| Migration warning | PreToolUse | Avisa ao modificar migration existente |
| Test reminder | Stop | Lembra de rodar testes antes de finalizar |

**Por que hooks > CLAUDE.md:** CLAUDE.md tem ~70% de compliance. Hooks têm 100%.

### 5. Custom Agents (2 agentes)
| Agente | Propósito |
|--------|-----------|
| `security-reviewer` | Scan OWASP Top 10, busca secrets, SQLi, XSS, IDOR |
| `code-reviewer` | Review de qualidade: bugs, performance, manutenibilidade |

### 6. Anti-Sycophancy Prompt
Instruções de sistema que fazem Claude parar de concordar automaticamente e começar a desafiar seu raciocínio. O tipo de prompt com maior impacto em qualidade de código segundo a comunidade.

### 7. Skills (12 ZIPs para Claude.ai + 5 CLI-only)
Entregue anteriormente. Veja `README-skills-pack.md`.

---

## 🚀 Instalação

### Opção A: Script Automático (Claude Code)
```bash
cd claude-developer-toolkit/
chmod +x setup-claude-toolkit.sh
./setup-claude-toolkit.sh
```

### Opção B: Manual (escolha o que precisa)

**CLAUDE.md:**
```bash
cp claude-md/CLAUDE.md.global ~/.claude/CLAUDE.md
cp claude-md/CLAUDE.md.project ./CLAUDE.md  # na raiz do seu projeto
```

**Slash Commands:**
```bash
mkdir -p ~/.claude/commands
cp slash-commands/*.md ~/.claude/commands/
```

**Agents:**
```bash
mkdir -p ~/.claude/agents
cp agents/*.md ~/.claude/agents/
```

**Hooks:**
```bash
cp hooks/hooks.json ~/.claude/hooks.json
```

**MCP Servers:**
```bash
# Context7 (o mais importante — docs atualizadas)
claude mcp add context7 --transport http https://mcp.context7.com/mcp

# GitHub (PRs, issues)
export GITHUB_TOKEN=ghp_seu_token_aqui
claude mcp add github -- npx -y @modelcontextprotocol/server-github

# Git local (sem API key)
claude mcp add git -- npx -y @modelcontextprotocol/server-git --repository .
```

**Anti-Sycophancy (Claude.ai):**
1. Abra um Claude Project
2. Vá em Project Instructions
3. Cole o conteúdo de `system-prompts/anti-sycophancy.md`

---

## 📊 Sequência de Setup Recomendada (80/20)

Seguindo o documento de referência, esta ordem entrega ~80% dos ganhos:

| Ordem | O quê | Tempo | Impacto |
|-------|-------|-------|---------|
| 1º | CLAUDE.md global + projeto | 10 min | ⭐⭐⭐⭐⭐ |
| 2º | 2 MCP servers (Context7 + GitHub) | 5 min | ⭐⭐⭐⭐⭐ |
| 3º | obra/superpowers | 2 min | ⭐⭐⭐⭐ |
| 4º | 3 slash commands (/commit, /review, /plan) | 2 min | ⭐⭐⭐⭐ |
| 5º | Hook de auto-format | 2 min | ⭐⭐⭐ |
| 6º | Anti-sycophancy prompt | 2 min | ⭐⭐⭐⭐ |

**Total: ~23 minutos para transformar seu setup.**

---

## ⚠️ Notas de Performance

- **MCP token budget:** Cada MCP server consome tokens de contexto. Mais de 20k tokens de MCP descriptions = perda significativa de contexto útil. Comece com 2-3 servers.
- **CLAUDE.md size:** Mantenha abaixo de 300 linhas. Claude Code já tem ~50 instruções no system prompt. Frontier models seguem ~150-200 instruções de forma confiável.
- **Context management:** Use `/clear` entre tarefas não relacionadas. Rode `/compact` manual a ~50% do contexto ao invés de esperar auto-compaction.
- **Writer/Reviewer pattern:** Uma instância Claude escreve, outra fresca revisa. Elimina viés de confirmação.
