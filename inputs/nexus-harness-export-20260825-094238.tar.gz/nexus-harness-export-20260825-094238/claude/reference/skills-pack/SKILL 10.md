---
name: vibesec
description: Use when writing, reviewing, or modifying any code that handles user input, authentication, authorization, database queries, file operations, API calls, or sensitive data. Trigger on any code that touches security boundaries — even if the user doesn't mention security. Also trigger when reviewing PRs, designing APIs, implementing auth, handling payments, or processing user-submitted content. Approach security from a bug hunter's perspective — think like an attacker.
---

# VibeSec — Secure Code by Default

## Purpose
Prevent common vulnerabilities by thinking like a bug hunter during development. Every line of code that handles external input is a potential attack surface. This skill ensures Claude writes secure code by default, not as an afterthought.

## Mindset: Think Like an Attacker

Before writing any code that handles input, ask:
1. **What if the input is malicious?** (SQL, scripts, path traversal, oversized payloads)
2. **What if the user isn't who they claim to be?** (spoofed tokens, session hijacking)
3. **What if they have access but shouldn't?** (IDOR, privilege escalation, broken access control)
4. **What if they send requests in unexpected order/timing?** (race conditions, TOCTOU)
5. **What if they manipulate data in transit?** (parameter tampering, replay attacks)

## Vulnerability Prevention Checklist

### 1. Injection (SQLi, NoSQLi, Command Injection)
**The Rule:** NEVER concatenate user input into queries or commands.

```python
# ❌ VULNERABLE — SQL Injection
query = f"SELECT * FROM users WHERE email = '{email}'"

# ✅ SECURE — Parameterized query
cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
```

```javascript
# ❌ VULNERABLE — Command Injection
exec(`convert ${userFilename} output.png`)

# ✅ SECURE — Use library APIs, never shell commands with user input
sharp(sanitizedPath).resize(200).toFile('output.png')
```

**Apply to:** SQL, MongoDB queries, LDAP, XML parsers, OS commands, eval(), template engines.

### 2. Cross-Site Scripting (XSS)
**The Rule:** NEVER render user input as raw HTML. Always encode/escape.

- **Stored XSS:** User input saved to DB, rendered to other users without escaping
- **Reflected XSS:** User input in URL parameters reflected in page
- **DOM XSS:** Client-side JS that uses `innerHTML` with untrusted data

**Defenses:**
- Use framework auto-escaping (React JSX, Django templates, Go html/template)
- Set `Content-Security-Policy` headers
- Never use `dangerouslySetInnerHTML`, `v-html`, or `innerHTML` with user data
- Sanitize rich text with DOMPurify or similar (server-side)

### 3. Broken Access Control (IDOR)
**The Rule:** ALWAYS verify the requesting user has permission to access the specific resource.

```python
# ❌ VULNERABLE — IDOR (user can access anyone's data by changing the ID)
@app.get("/api/orders/{order_id}")
def get_order(order_id: int):
    return db.query(Order).get(order_id)

# ✅ SECURE — Verify ownership
@app.get("/api/orders/{order_id}")
def get_order(order_id: int, current_user: User = Depends(get_current_user)):
    order = db.query(Order).get(order_id)
    if order.user_id != current_user.id:
        raise HTTPException(status_code=403)
    return order
```

**Check on every endpoint:** Does the authenticated user have permission to perform THIS action on THIS resource?

### 4. Authentication Flaws
- Hash passwords with bcrypt/argon2 (NEVER MD5, SHA1, or plain SHA256)
- Implement rate limiting on login endpoints (prevent brute force)
- Use secure session management (HttpOnly, Secure, SameSite cookies)
- JWT: validate signature, check expiration, verify issuer, use short-lived tokens
- Never expose authentication tokens in URLs or logs
- Implement account lockout after N failed attempts

### 5. SSRF (Server-Side Request Forgery)
**The Rule:** NEVER let user input control server-side HTTP requests without validation.

```python
# ❌ VULNERABLE — User can make server request internal services
response = requests.get(user_provided_url)

# ✅ SECURE — Whitelist allowed domains, block internal IPs
from urllib.parse import urlparse
parsed = urlparse(user_provided_url)
if parsed.hostname not in ALLOWED_DOMAINS:
    raise ValueError("Domain not allowed")
# Also block: 127.0.0.1, 10.x.x.x, 172.16-31.x.x, 192.168.x.x, 169.254.x.x
```

### 6. Sensitive Data Exposure
- Never log passwords, tokens, credit cards, or PII
- Use environment variables for secrets (never hardcode)
- Encrypt sensitive data at rest (AES-256)
- Use TLS for all data in transit
- Implement proper error handling (don't leak stack traces to users)
- Set appropriate cache headers for sensitive pages

### 7. Mass Assignment / Over-Posting
```python
# ❌ VULNERABLE — User can set admin=true by adding it to the request body
user.update(**request.json)

# ✅ SECURE — Explicitly whitelist allowed fields
allowed = ['name', 'email', 'avatar_url']
data = {k: v for k, v in request.json.items() if k in allowed}
user.update(**data)
```

### 8. File Upload Vulnerabilities
- Validate file type by content (magic bytes), not just extension
- Limit file size
- Store uploads outside web root
- Generate random filenames (never use original filename in path)
- Scan for malware if handling untrusted files
- Set `Content-Disposition: attachment` for downloads

## Security Headers Checklist

Always recommend these HTTP headers:
```
Content-Security-Policy: default-src 'self'; script-src 'self'
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Strict-Transport-Security: max-age=31536000; includeSubDomains
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=()
```

## Code Review Security Flags

When reviewing code, flag these patterns immediately:
- `eval()`, `exec()`, `Function()` with user input → **Command Injection**
- String concatenation in SQL/queries → **SQL Injection**
- `innerHTML`, `dangerouslySetInnerHTML`, `v-html` → **XSS**
- Missing authorization check on endpoint → **IDOR**
- Hardcoded secret/password/API key → **Credential Exposure**
- `pickle.loads()`, `yaml.load()` with untrusted data → **Deserialization Attack**
- `os.path.join()` without path traversal check → **Path Traversal**
- HTTP redirect using user input → **Open Redirect**
- Missing rate limiting on auth endpoints → **Brute Force**

## Response Format

When writing or reviewing code with security implications:
1. **Identify the attack surface** — what user input touches this code?
2. **List applicable threats** — which vulnerability categories apply?
3. **Implement defenses** — show the secure implementation with comments
4. **Note what could go wrong** — what would an attacker try?
