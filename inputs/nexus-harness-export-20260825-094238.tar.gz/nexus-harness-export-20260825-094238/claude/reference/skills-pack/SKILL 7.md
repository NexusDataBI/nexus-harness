---
name: varlock
description: Use when working with environment variables, secrets, API keys, database credentials, tokens, or any sensitive configuration. Trigger on mentions of .env, secrets, credentials, API keys, tokens, passwords in code, environment variables, secret management, vault, or when you see hardcoded sensitive values. Also trigger when setting up CI/CD pipelines, Docker configurations, or deployment scripts that handle secrets.
---

# Varlock — Secure Environment Variable Management

## Purpose
Ensure secrets NEVER appear in Claude sessions, terminal outputs, logs, git commits, or error messages. This skill enforces strict secret hygiene across all development workflows.

## The Cardinal Rules

1. **NEVER hardcode secrets in source code.** Not even "temporarily."
2. **NEVER log secrets.** Not even at debug level.
3. **NEVER commit secrets to git.** Not even in private repos.
4. **NEVER display secrets in terminal output.** Mask them.
5. **NEVER pass secrets as command-line arguments.** They appear in process lists.
6. **NEVER include secrets in error messages or stack traces.**
7. **NEVER store secrets in client-side code** (JS bundles, mobile apps).

## .env File Best Practices

### Structure
```bash
# ============================================================
# Application Configuration
# ============================================================
NODE_ENV=development
PORT=3000
LOG_LEVEL=info

# ============================================================
# Database (SENSITIVE)
# ============================================================
DATABASE_URL=postgresql://user:password@localhost:5432/mydb
REDIS_URL=redis://localhost:6379

# ============================================================
# Authentication (SENSITIVE)
# ============================================================
JWT_SECRET=your-secret-here
SESSION_SECRET=your-session-secret

# ============================================================
# External Services (SENSITIVE)
# ============================================================
STRIPE_SECRET_KEY=sk_test_...
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
SENDGRID_API_KEY=SG...
```

### .gitignore — Always Include
```gitignore
# Environment files
.env
.env.local
.env.*.local
.env.production
.env.staging

# Secret files
*.pem
*.key
*.p12
*.pfx
credentials.json
service-account.json
```

### .env.example — Always Provide
```bash
# Copy this to .env and fill in real values
# NEVER commit the actual .env file

DATABASE_URL=postgresql://user:password@localhost:5432/mydb
JWT_SECRET=generate-a-random-string-here
STRIPE_SECRET_KEY=sk_test_your_key_here
```

## Secret Detection — Pre-commit Hook

Recommend setting up a pre-commit hook to prevent accidental commits:

```bash
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.18.0
    hooks:
      - id: gitleaks

  - repo: https://github.com/Yelp/detect-secrets
    rev: v1.4.0
    hooks:
      - id: detect-secrets
        args: ['--baseline', '.secrets.baseline']
```

## Secret Patterns to Flag

When reviewing code, immediately flag these patterns:

| Pattern | Example | Risk |
|---------|---------|------|
| Hardcoded API key | `apiKey = "[REDACTED]"` | Credential exposure |
| Hardcoded password | `password = "admin123"` | Auth bypass |
| Hardcoded JWT secret | `jwt.sign(payload, "mysecret")` | Token forgery |
| DB connection string with creds | `"postgres://admin:pass@prod-db:5432"` | DB compromise |
| AWS keys in code | `AWS_ACCESS_KEY_ID = "AKIA..."` | Cloud account takeover |
| Private key in code | `-----BEGIN RSA PRIVATE KEY-----` | Full system compromise |
| Secret in URL | `https://api.service.com?key=abc123` | Key leakage in logs/referer |
| Secret in log statement | `logger.info(f"Token: {token}")` | Log exposure |

## Per-Environment Secret Management

| Environment | Recommended Approach |
|------------|---------------------|
| Local Development | `.env` file (never committed) |
| CI/CD | Pipeline secrets (GitHub Secrets, GitLab CI Variables) |
| Staging/Production | Secret manager (AWS Secrets Manager, HashiCorp Vault, Doppler) |
| Docker | Docker secrets or env injection at runtime (not in Dockerfile) |
| Kubernetes | K8s Secrets (with encryption at rest) or external secret operator |

## Docker Security

```dockerfile
# ❌ WRONG — Secret baked into image layer
ENV DATABASE_URL=postgresql://admin:password@db:5432/prod

# ❌ WRONG — Secret visible in build args
ARG DATABASE_URL
ENV DATABASE_URL=$DATABASE_URL

# ✅ CORRECT — Inject at runtime only
# docker run -e DATABASE_URL=... or --env-file .env
```

## Claude-Specific Rules

When Claude is working with code that contains secrets:
1. **Never echo or print secret values** in terminal commands
2. **Never include real secret values in code examples** — use placeholders
3. **Replace actual values with descriptive placeholders:** `YOUR_API_KEY_HERE`
4. **If a user accidentally shares a secret,** warn them to rotate it immediately
5. **When generating config files,** always include `.gitignore` entries for them

## Response Format

When working with secrets/environment variables:
1. **Audit current state:** Are there any exposed secrets?
2. **Propose secure structure:** .env layout, .gitignore, .env.example
3. **Recommend tooling:** Pre-commit hooks, secret scanning
4. **Implement safely:** Use placeholders in all examples
