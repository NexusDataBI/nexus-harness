# Catálogo de Claude Skills — Curadoria das Melhores

> **Fonte:** travisvn/awesome-claude-skills, ComposioHQ/awesome-claude-skills, hesreallyhim/awesome-claude-code, post Reddit r/ClaudeAI (30+ skills testadas)
>
> **Filtros aplicados:** Desenvolvimento/Código, Segurança, DevOps/Infra, Produtividade/Documentos
>
> **Destino:** Claude.ai (web) + Claude Code (CLI)

---

## Legenda

- ✅ = Já instalada no seu Claude.ai
- ⭐ = Altamente recomendada pela comunidade (mencionada em múltiplas fontes / alto engajamento)
- 🔧 = Funciona em Claude Code (CLI)
- 🌐 = Funciona em Claude.ai (web)
- 🔧🌐 = Ambos

---

## 1. DESENVOLVIMENTO / CÓDIGO

### 1.1 Fluxo de trabalho & Arquitetura

| # | Skill | Descrição | Plataforma | Fonte | Status |
|---|-------|-----------|------------|-------|--------|
| 1 | **obra/superpowers** | Biblioteca com 20+ skills battle-tested: TDD, debugging, brainstorming, planning. Inclui `/brainstorm`, `/write-plan`, `/execute-plan`. A mais citada pela comunidade. | 🔧 | travisvn, hesreallyhim, Reddit | ⭐ |
| 2 | **software-architecture** | Clean Architecture, SOLID, design patterns, comprehensive best practices para design de software. | 🔧🌐 | ComposioHQ | ⭐ |
| 3 | **test-driven-development** | Workflow TDD: escrever testes antes do código de implementação. | 🔧🌐 | ComposioHQ, BehiSecc | ⭐ |
| 4 | **systematic-debugging** | Metodologia estruturada para debugging antes de propor fixes. Root cause analysis, não chutes. | 🔧🌐 | BehiSecc | ⭐ |
| 5 | **subagent-driven-development** | Despacha subagents independentes por tarefa com code review entre iterações. | 🔧 | ComposioHQ | — |
| 6 | **finishing-a-development-branch** | Guia para completar branches: options claras, workflow de merge/squash/rebase. | 🔧🌐 | ComposioHQ | — |
| 7 | **using-git-worktrees** | Cria git worktrees isoladas com seleção inteligente de diretório e verificação de segurança. | 🔧 | ComposioHQ | — |
| 8 | **prompt-engineering** | Ensina técnicas de prompt engineering conhecidas, incluindo Anthropic best practices. | 🔧🌐 | ComposioHQ | — |
| 9 | **D3.js Visualization** | Ensina Claude a produzir charts D3 e data visualizations interativas. Por @chrisvoncsefalvay. | 🔧🌐 | ComposioHQ | — |

### 1.2 Testing & Qualidade

| # | Skill | Descrição | Plataforma | Fonte | Status |
|---|-------|-----------|------------|-------|--------|
| 10 | **testing-patterns** | Patterns concretos para testes: React Native, Supabase Edge Functions, API, webhooks. | 🔧🌐 | Anthropic | ✅ |
| 11 | **pypict-claude-skill** | Gera suites de teste otimizadas com cobertura pairwise (PICT - Pairwise Independent Combinatorial Testing). | 🔧🌐 | ComposioHQ | — |
| 12 | **webapp-testing (Playwright)** | Testa aplicações web locais com Playwright: verificação UI, debugging, screenshots. | 🔧🌐 | Anthropic | — |

### 1.3 Changelog & Git

| # | Skill | Descrição | Plataforma | Fonte | Status |
|---|-------|-----------|------------|-------|--------|
| 13 | **Changelog Generator** | Gera changelogs user-facing a partir de git commits. Transforma commits técnicos em release notes legíveis. | 🔧🌐 | ComposioHQ | ⭐ |
| 14 | **git-pushing** | Workflow estruturado para push seguro com validações. | 🔧 | mhattingpete | — |

---

## 2. SEGURANÇA

| # | Skill | Descrição | Plataforma | Fonte | Status |
|---|-------|-----------|------------|-------|--------|
| 15 | **VibeSec (vibesec)** | Ajuda Claude a escrever código seguro prevenindo IDOR, XSS, SQL injection, SSRF, auth fraco. Perspectiva de bug hunter. | 🔧🌐 | BehiSecc | ⭐ |
| 16 | **defense-in-depth** | Testing e segurança em camadas múltiplas (multi-layered). | 🔧🌐 | BehiSecc | — |
| 17 | **owasp-security** | OWASP Top 10:2025, ASVS 5.0, Agentic AI security (2026). Checklists para code review, patterns seguros, quirks por linguagem (20+). | 🔧🌐 | BehiSecc | ⭐ |
| 18 | **varlock-claude-skill** | Gerenciamento seguro de environment variables. Garante que secrets nunca apareçam em sessions, terminais, logs ou git commits. | 🔧 | BehiSecc | ⭐ |
| 19 | **sanitize** | Detecta e redacta PII de arquivos texto — 15 categorias (SSN, cartões de crédito, API keys, etc). Zero dependências, processamento 100% local. | 🔧 | openclaw | — |
| 20 | **FFUF Web Fuzzing** | Integra fuzzer ffuf para Claude rodar tarefas de fuzzing e analisar resultados. Por @jthack. | 🔧 | ComposioHQ | — |
| 21 | **Trail of Bits Security Skills** | Análise estática com CodeQL/Semgrep, variant analysis, code auditing, verificação de fixes. | 🔧 | travisvn | ⭐ |
| 22 | **Shannon (pentest)** | Agente autônomo de pen testing. 96.15% exploit success rate no XBOW benchmark. 50+ tipos de vulnerabilidade. Roda em Docker. ~$50/pentest completo. | 🔧 | Medium (unicodeveloper) | ⭐ |
| 23 | **parry** | Scanner de prompt injection para Claude Code hooks. Detecta injection attacks, secrets e tentativas de data exfiltration. Early development. | 🔧 | hesreallyhim | — |

---

## 3. DEVOPS / INFRA

| # | Skill | Descrição | Plataforma | Fonte | Status |
|---|-------|-----------|------------|-------|--------|
| 24 | **aws-skills** | AWS development com CDK best practices, cost optimization, MCP servers, serverless/event-driven patterns. | 🔧🌐 | ComposioHQ | ⭐ |
| 25 | **observability** | Error tracking, logging, monitoring, alerting, debugging em produção. Sentry, health checks, APM, source maps. | 🔧🌐 | User skill | ✅ |
| 26 | **DevOps Mega Skills (chmouel)** | Set "imensamente detalhado" de skills para DevOps. Validations, generators, shell scripts e CLI tools para IaC em múltiplas plataformas. Citado como "vale baixar só como documentação". | 🔧 | hesreallyhim | ⭐ |
| 27 | **Playwright Browser Automation** | Automação Playwright invocada pelo modelo para testar e validar apps web. | 🔧🌐 | ComposioHQ | — |

---

## 4. PRODUTIVIDADE / DOCUMENTOS

| # | Skill | Descrição | Plataforma | Fonte | Status |
|---|-------|-----------|------------|-------|--------|
| 28 | **docx** | Criar, editar, analisar Word docs com tracked changes, comments, formatting. | 🔧🌐 | Anthropic | ✅ |
| 29 | **pdf** | Extrair texto, tabelas, metadata, merge & anotar PDFs. | 🔧🌐 | Anthropic | ✅ |
| 30 | **pptx** | Ler, gerar e ajustar slides, layouts, templates. | 🔧🌐 | Anthropic | ✅ |
| 31 | **xlsx** | Manipulação de spreadsheets: fórmulas, charts, transformações. | 🔧🌐 | Anthropic | ✅ |
| 32 | **internal-comms** | Status reports, newsletters, FAQs, incident reports, project updates. | 🔧🌐 | Anthropic | ✅ |
| 33 | **doc-coauthoring** | Workflow estruturado para co-autoria de documentação, proposals, specs técnicas. | 🔧🌐 | Anthropic | ✅ |
| 34 | **Markdown to EPUB Converter** | Converte markdown e chat summaries em EPUB profissional. Por @smerchek. | 🔧 | ComposioHQ | — |
| 35 | **revealjs-skill** | Gera apresentações polidas com Reveal.js (HTML presentation framework). | 🔧🌐 | BehiSecc | — |
| 36 | **content-research-writer** | Pesquisa, citações, hooks, iteração em outlines, feedback em tempo real por seção. | 🔧🌐 | ComposioHQ | — |
| 37 | **NotebookLM Skill** | Bridge entre Claude Code e Google NotebookLM. Queries em docs, summaries com fontes, flashcards. "O mais underrated" segundo Indie Hackers. | 🔧 | IndiHackers review | ⭐ |
| 38 | **Claude SEO** | Audit SEO estruturado: issues técnicos, análise por página, schema markup, sitemap, otimização AEO/GEO. 12 sub-skills em paralelo. | 🔧 | IndiHackers review | ⭐ |

---

## 5. FERRAMENTAS AUXILIARES & META-SKILLS

| # | Skill | Descrição | Plataforma | Fonte | Status |
|---|-------|-----------|------------|-------|--------|
| 39 | **skill-creator** | Cria, modifica, testa e otimiza skills. | 🔧🌐 | Anthropic | ✅ |
| 40 | **Skill Seekers** | Converte automaticamente qualquer site de documentação em Claude Skill em minutos. Por @yusufkaraaslan. | 🔧 | ComposioHQ | ⭐ |
| 41 | **mcp-builder** | Guia para criar MCP servers de alta qualidade. | 🔧🌐 | Anthropic | ✅ |
| 42 | **planning-router** | Decide qual abordagem de planejamento usar antes de cada tarefa. | 🔧🌐 | User skill | ✅ |
| 43 | **last30days** | Pesquisa trends dos últimos 30 dias no Reddit, X, YouTube, HN, web. Entrega summaries com citações reais. | 🔧 | hesreallyhim, Medium | ⭐ |
| 44 | **file-organizer** | Organiza inteligentemente arquivos e pastas no computador. | 🔧 | ComposioHQ | — |
| 45 | **claude-starter** | Template production-ready com 40 skills auto-ativantes em 8 domínios + TOON format (30-60% token savings). | 🔧 | BehiSecc | ⭐ |

---

## RESUMO RÁPIDO — O que você NÃO tem e vale a pena

### Tier 1 — "Game changers" (citadas por múltiplas fontes, alta recomendação)

| # | Skill | Por quê |
|---|-------|---------|
| 1 | **obra/superpowers** | A mais citada de todas. 20+ skills integradas: TDD, debug, planning, brainstorm. |
| 2 | **software-architecture** | Clean Architecture + SOLID como guia sempre ativo. |
| 3 | **systematic-debugging** | Root cause analysis antes de sair chutando fix. |
| 4 | **test-driven-development** | TDD enforced como workflow padrão. |
| 13 | **Changelog Generator** | Automatiza release notes a partir de git history. |
| 15 | **VibeSec** | Segurança preventiva com mentalidade de bug hunter. |
| 17 | **owasp-security** | OWASP 2025 + checklists práticos por linguagem. |
| 18 | **varlock** | Secrets nunca vazam em logs/terminal/git. |
| 21 | **Trail of Bits** | CodeQL + Semgrep integrados. |
| 24 | **aws-skills** | CDK, serverless, cost optimization. |

### Tier 2 — Muito úteis, mais específicas

| # | Skill | Por quê |
|---|-------|---------|
| 5 | **subagent-driven-development** | Paraleliza tarefas com review entre iterações. |
| 12 | **webapp-testing (Playwright)** | Testa UI automaticamente. |
| 22 | **Shannon** | Pentest autônomo real com 96% success rate. |
| 36 | **content-research-writer** | Research + writing com citações. |
| 40 | **Skill Seekers** | Transforma qualquer doc em skill automaticamente. |
| 43 | **last30days** | Pesquisa de trends em tempo real. |
| 45 | **claude-starter** | Template pronto com 40 skills + economia de tokens. |

### Tier 3 — Úteis mas nicho

| # | Skill | Por quê |
|---|-------|---------|
| 6 | **finishing-a-development-branch** | Workflow de finalização de branch. |
| 7 | **using-git-worktrees** | Worktrees isoladas. |
| 9 | **D3.js Visualization** | Viz de dados avançada. |
| 19 | **sanitize** | Redação de PII local. |
| 34 | **Markdown to EPUB** | Converte md → ebook. |
| 35 | **revealjs-skill** | Apresentações HTML. |
| 38 | **Claude SEO** | Audit SEO completo. |
