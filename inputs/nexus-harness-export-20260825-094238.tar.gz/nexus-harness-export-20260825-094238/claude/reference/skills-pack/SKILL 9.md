---
name: software-architecture
description: Use when designing systems, reviewing architecture, implementing design patterns, or making structural decisions about code. Triggers on mentions of architecture, SOLID, Clean Architecture, design patterns, DDD, hexagonal, ports and adapters, microservices vs monolith, coupling, cohesion, separation of concerns, dependency injection, or any structural code decision. Also use when reviewing PRs for architectural issues or planning new features that affect system structure.
---

# Software Architecture Skill

## Purpose
Guide Claude to apply proven software architecture principles consistently. This skill ensures every structural decision is deliberate, documented, and aligned with long-term maintainability.

## Core Principles

### SOLID Principles — Always Apply
1. **Single Responsibility (SRP):** Every module/class/function has one reason to change. If you can describe what it does with "and", split it.
2. **Open/Closed (OCP):** Open for extension, closed for modification. Use abstractions (interfaces, protocols, abstract classes) to allow new behavior without touching existing code.
3. **Liskov Substitution (LSP):** Subtypes must be substitutable for their base types without altering correctness. If a duck override throws "I can't fly", the abstraction is wrong.
4. **Interface Segregation (ISP):** No client should depend on methods it doesn't use. Prefer many small interfaces over one fat interface.
5. **Dependency Inversion (DIP):** High-level modules must not depend on low-level modules. Both should depend on abstractions. Inject dependencies, don't instantiate them.

### Clean Architecture Layers
```
┌─────────────────────────────────────────┐
│           Frameworks & Drivers          │  ← Web, DB, UI, External APIs
├─────────────────────────────────────────┤
│          Interface Adapters             │  ← Controllers, Gateways, Presenters
├─────────────────────────────────────────┤
│           Application Layer             │  ← Use Cases / Application Services
├─────────────────────────────────────────┤
│              Domain Layer               │  ← Entities, Value Objects, Domain Services
└─────────────────────────────────────────┘
```

**The Dependency Rule:** Dependencies point INWARD only. Domain knows nothing about infrastructure.

### Architecture Decision Workflow

When making any structural decision, follow this process:

1. **Identify the forces:** What are the competing concerns? (performance vs readability, flexibility vs simplicity, consistency vs autonomy)
2. **Name the pattern:** Don't invent ad-hoc structures. Use recognized patterns (Repository, Strategy, Observer, Factory, Mediator, etc.) and name them explicitly.
3. **Evaluate tradeoffs:** Every pattern has costs. Document what you're gaining AND what you're giving up.
4. **Consider the future:** Will this decision be easy to change later? If not, is the commitment justified?
5. **Document the decision:** Use an ADR (Architecture Decision Record) format:
   - **Context:** What situation are we in?
   - **Decision:** What are we doing?
   - **Consequences:** What becomes easier? What becomes harder?

## Design Patterns — When to Apply

### Creational
- **Factory Method:** When you need to decouple object creation from usage. Use when the exact type isn't known until runtime.
- **Builder:** When constructing complex objects with many optional parameters. Prefer over telescoping constructors.
- **Singleton:** Almost never. Use dependency injection instead. Only for truly global, stateless utilities.

### Structural
- **Adapter:** When integrating external services or legacy code. Wrap the foreign interface to match your domain's expectations.
- **Facade:** When simplifying a complex subsystem. Provide a unified interface that hides internal complexity.
- **Decorator:** When adding behavior without modifying existing classes. Prefer over inheritance for cross-cutting concerns.

### Behavioral
- **Strategy:** When you have multiple algorithms for the same task. Extract the varying behavior behind an interface.
- **Observer/Event:** When components need to react to changes without tight coupling. Use for notifications, audit logs, side effects.
- **Command:** When you need to queue, undo, or log operations. Encapsulate requests as objects.
- **Mediator:** When many objects interact in complex ways. Centralize the coordination logic.

## Anti-Patterns — Red Flags to Call Out

Always flag these when reviewing or writing code:
- **God Class/Module:** One class doing everything. Split by responsibility.
- **Anemic Domain Model:** Entities with only getters/setters, all logic in services. Push behavior into domain objects.
- **Shotgun Surgery:** One change requires touching many files. Indicates poor cohesion.
- **Feature Envy:** A method that uses more data from another class than its own. Move it.
- **Circular Dependencies:** Module A depends on B depends on A. Extract shared abstractions.
- **Premature Abstraction:** Creating interfaces/abstractions for things that have only one implementation and no foreseeable variation. Wait for the second use case.
- **Big Ball of Mud:** No discernible architecture. The fix is incremental: draw boundaries, extract modules, enforce dependency rules.

## Code Review Checklist (Architecture Focus)

When reviewing code for architectural quality:

- [ ] Does the change respect existing layer boundaries?
- [ ] Are new dependencies pointing in the right direction (inward)?
- [ ] Is business logic in the domain/application layer, NOT in controllers/handlers?
- [ ] Are external services behind abstractions (interfaces/ports)?
- [ ] Is the change testable in isolation without infrastructure?
- [ ] Are there any new circular dependencies?
- [ ] Is the naming consistent with existing patterns in the codebase?
- [ ] Will this change be easy to modify in 6 months?

## Architectural Styles Decision Matrix

| Need | Consider | Avoid |
|------|----------|-------|
| Simple CRUD app | Layered/MVC | Microservices, Event Sourcing |
| Complex business rules | Clean Architecture, DDD | Anemic models, Transaction Scripts |
| High scalability needs | Microservices, Event-Driven | Monolith with shared DB |
| Rapid prototyping | Modular Monolith | Distributed systems |
| Real-time updates | Event-Driven, CQRS | Request-Response only |
| Multiple teams | Microservices with clear boundaries | Shared monolith |
| Small team (<5 devs) | Modular Monolith | Microservices |

## Response Format

When discussing architecture, always structure the response as:

1. **Context:** What's the current state and what problem are we solving?
2. **Options:** At least 2 approaches with pros/cons of each
3. **Recommendation:** Which option and why, with explicit tradeoffs acknowledged
4. **Implementation Plan:** Concrete next steps, ordered by priority
5. **Risks:** What could go wrong and how to mitigate it
6. **Future Considerations:** What to watch for as the system evolves
