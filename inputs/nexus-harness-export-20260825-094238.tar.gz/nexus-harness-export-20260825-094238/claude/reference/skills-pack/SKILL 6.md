---
name: trail-of-bits-security
description: Use when setting up or running static analysis tools, configuring CodeQL or Semgrep, performing code audits for security vulnerabilities, conducting variant analysis (finding similar bugs after one is discovered), or verifying security fixes. Trigger on mentions of CodeQL, Semgrep, static analysis, SAST, code scanning, variant analysis, security audit, vulnerability detection, taint analysis, or automated security review.
---

# Trail of Bits Security — Static Analysis with CodeQL & Semgrep

## Purpose
Leverage static analysis tools to systematically find security vulnerabilities, enforce coding standards, and verify fixes. Inspired by Trail of Bits' security research methodology.

## Tool Selection Guide

| Need | Use CodeQL | Use Semgrep |
|------|-----------|-------------|
| Deep dataflow/taint analysis | ✅ Best | ⚠️ Limited |
| Custom query development | ✅ Powerful QL language | ✅ Easy YAML rules |
| Quick pattern matching | ⚠️ Slower setup | ✅ Fast, grep-like |
| CI/CD integration speed | ⚠️ Slower (builds DB) | ✅ Fast (~seconds) |
| Language support | Strong (Java, JS, Python, Go, C/C++, Ruby, C#) | Very broad (30+ languages) |
| Free for open source | ✅ Yes | ✅ Yes |
| Learning curve | Steep (QL language) | Low (YAML patterns) |

**Recommendation:** Use BOTH. Semgrep for fast pattern matching in CI. CodeQL for deep analysis in scheduled scans.

## Semgrep — Quick Setup & Essential Rules

### Installation & Running
```bash
# Install
pip install semgrep

# Run with community rules
semgrep --config auto .

# Run specific rulesets
semgrep --config p/owasp-top-ten .
semgrep --config p/javascript .
semgrep --config p/python .

# Run custom rules
semgrep --config ./semgrep-rules/ .
```

### Essential Custom Rules

```yaml
# .semgrep/security-rules.yml
rules:
  - id: hardcoded-secret-in-code
    patterns:
      - pattern-either:
        - pattern: $KEY = "..."
        - pattern: $KEY = '...'
      - metavariable-regex:
          metavariable: $KEY
          regex: '(?i)(password|secret|api_key|token|credential|private_key)'
    message: "Potential hardcoded secret in variable '$KEY'"
    severity: ERROR
    languages: [python, javascript, typescript, go, java]

  - id: sql-injection-format-string
    patterns:
      - pattern-either:
        - pattern: |
            $QUERY = f"...{$INPUT}..."
            ...
            $CURSOR.execute($QUERY)
        - pattern: |
            $QUERY = "..." + $INPUT + "..."
            ...
            $CURSOR.execute($QUERY)
    message: "SQL injection via string formatting. Use parameterized queries."
    severity: ERROR
    languages: [python]

  - id: dangerous-eval
    pattern-either:
      - pattern: eval($X)
      - pattern: exec($X)
    message: "eval/exec with dynamic input is a code injection risk"
    severity: WARNING
    languages: [python, javascript]

  - id: missing-csrf-protection
    patterns:
      - pattern: |
          @app.route("...", methods=["POST", ...])
          def $FUNC(...):
            ...
      - pattern-not-inside: |
          @csrf_protect
          ...
    message: "POST endpoint without CSRF protection"
    severity: WARNING
    languages: [python]
```

### CI/CD Integration (GitHub Actions)
```yaml
# .github/workflows/semgrep.yml
name: Semgrep Security Scan
on: [pull_request]
jobs:
  semgrep:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: semgrep/semgrep-action@v1
        with:
          config: >-
            p/owasp-top-ten
            p/r2c-security-audit
            .semgrep/
```

## CodeQL — Deep Analysis Setup

### GitHub Actions Integration
```yaml
# .github/workflows/codeql.yml
name: CodeQL Analysis
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]
  schedule:
    - cron: '0 6 * * 1'  # Weekly Monday 6am

jobs:
  analyze:
    runs-on: ubuntu-latest
    permissions:
      security-events: write
    strategy:
      matrix:
        language: ['javascript', 'python']
    steps:
      - uses: actions/checkout@v4
      - uses: github/codeql-action/init@v3
        with:
          languages: ${{ matrix.language }}
          queries: security-and-quality
      - uses: github/codeql-action/autobuild@v3
      - uses: github/codeql-action/analyze@v3
```

## Variant Analysis Workflow

When a vulnerability is found, use variant analysis to find similar patterns:

1. **Characterize the bug:** What's the vulnerable pattern? (source → sink without sanitization)
2. **Generalize the pattern:** Abstract from the specific instance to a rule
3. **Write a detection rule:** Semgrep for patterns, CodeQL for data flow
4. **Scan the full codebase:** Find all instances of the same pattern
5. **Triage results:** Not all matches are exploitable. Review each one.
6. **Fix all instances:** Don't just fix the reported bug — fix the category.

## Security Audit Methodology

### Phase 1: Automated Scanning
1. Run Semgrep with `p/owasp-top-ten` and `p/r2c-security-audit`
2. Run CodeQL with `security-and-quality` queries
3. Run dependency scan (`npm audit`, `pip audit`, `go vuln check`)
4. Run secret scanner (gitleaks, trufflehog)

### Phase 2: Manual Review (Focus Areas)
1. **Authentication flows:** Token generation, validation, session management
2. **Authorization logic:** Access control checks, role verification
3. **Data validation boundaries:** Where external input enters the system
4. **Cryptographic operations:** Key management, algorithm choices, randomness
5. **Error handling:** Information leakage, fail-open vs fail-closed

### Phase 3: Fix Verification
1. Write a test case that reproduces the vulnerability
2. Apply the fix
3. Verify the test now passes (vulnerability blocked)
4. Run regression suite to ensure no breakage
5. Add the pattern to CI rules to prevent recurrence

## Response Format

When performing security analysis:
1. **Scan Configuration:** Tools and rulesets used
2. **Findings:** Each vulnerability with severity, location, and evidence
3. **Remediation:** Specific code changes per finding
4. **Verification:** How to confirm each fix
5. **Prevention Rules:** Semgrep/CodeQL rules to prevent recurrence
