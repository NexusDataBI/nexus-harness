# Guia de Instalação — Skills CLI-Only (Claude Code)

> Estas 5 skills dependem de funcionalidades exclusivas do Claude Code (CLI, sistema de arquivos, plugins).
> Não podem ser portadas para Claude.ai (web) sem perder funcionalidade essencial.

---

## 1. obra/superpowers ⭐ (A mais recomendada pela comunidade)

**O que é:** Biblioteca com 20+ skills battle-tested incluindo TDD, debugging sistemático, brainstorming, planning e execution. Inclui comandos `/brainstorm`, `/write-plan`, `/execute-plan`.

**Por que instalar:** É a coleção mais citada em TODOS os repositórios awesome-claude. Se você só pudesse instalar uma coisa, seria esta.

**Instalação:**
```bash
# Via plugin marketplace (recomendado)
/plugin marketplace add obra/superpowers-marketplace

# Ou via git clone manual
git clone https://github.com/obra/superpowers ~/.claude/skills/superpowers
```

**Verificação:**
```bash
# No Claude Code, digite:
/brainstorm
# Deve ativar o skill de brainstorming interativo
```

**Repo:** https://github.com/obra/superpowers
**Lab (experimental):** https://github.com/obra/superpowers-lab

---

## 2. Shannon — Pentest Autônomo ⭐

**O que é:** Agente autônomo de penetration testing que analisa código-fonte, mapeia superfícies de ataque e executa ataques reais em 50+ tipos de vulnerabilidade. 96.15% de success rate no benchmark XBOW.

**Requisitos:**
- Docker instalado e rodando
- ~$50 por pentest completo (usa tokens de LLM)

**Instalação:**
```bash
# Instalar via npx
npx skills add unicodeveloper/shannon

# Ou clone manual
git clone https://github.com/KeygraphHQ/shannon ~/.claude/skills/shannon
```

**Uso:**
```bash
# No Claude Code:
"Usando o skill shannon, rode um pentest no meu projeto local"
```

**⚠️ IMPORTANTE:** Use APENAS contra sistemas que você tem autorização para testar.

**Repo:** https://github.com/KeygraphHQ/shannon

---

## 3. Skill Seekers — Converte Docs em Skills ⭐

**O que é:** Automatiza a conversão de qualquer site de documentação em uma Claude Skill em minutos. Scrape → processamento → geração de SKILL.md + resources.

**Requisitos:**
- Python 3.10+
- Dependências do scraper

**Instalação:**
```bash
git clone https://github.com/yusufkaraaslan/Skill_Seekers ~/.claude/skills/skill-seekers
cd ~/.claude/skills/skill-seekers
pip install -r requirements.txt
```

**Uso:**
```bash
# Criar skill a partir de documentação
python3 doc_scraper.py --config configs/minha_config.json --enhance-local

# Empacotar para uso
python3 package_skill.py output/minha-skill/
```

**Exemplo prático:** Quer criar uma skill para a documentação do Stripe?
```json
// configs/stripe_refunds.json
{
  "name": "stripe-refunds",
  "base_url": "https://docs.stripe.com/refunds",
  "max_depth": 3,
  "output_dir": "output/stripe-refunds"
}
```

**Repo:** https://github.com/yusufkaraaslan/Skill_Seekers

---

## 4. last30days — Pesquisa de Trends em Tempo Real ⭐

**O que é:** Pesquisa tópicos nos últimos 30 dias no Reddit, X/Twitter, YouTube, Hacker News, Bluesky e web. Sintetiza o que a comunidade está realmente upvotando e compartilhando.

**Requisitos:**
- Node.js 22+
- OpenAI API key (para pesquisa no Reddit)
- XAI API key OU auth tokens do X (para pesquisa no Twitter)
- yt-dlp (opcional, para YouTube)

**Instalação:**
```bash
git clone https://github.com/mvanhorn/last30days-skill ~/.claude/skills/last30days

# Configurar API keys
export OPENAI_API_KEY=your-key-here
export XAI_API_KEY=your-key-here  # ou AUTH_TOKEN + CT0 para X

# Opcional: Bluesky
export BSKY_HANDLE=your-handle.bsky.social
export BSKY_APP_PASSWORD=your-app-password
```

**Uso no Claude Code:**
```bash
/last30days Claude Code skills best practices
/last30days cursor vs windsurf  # modo comparativo
/last30days React Server Components production patterns
```

**Repo:** https://github.com/mvanhorn/last30days-skill

---

## 5. claude-starter — Template Production-Ready

**O que é:** Template completo de configuração para Claude Code com 40 skills auto-ativantes em 8 domínios. Inclui suporte a formato TOON (30-60% de economia de tokens) e encoder/decoder nativo em Zig.

**Instalação:**
```bash
git clone https://github.com/nicobailey/claude-starter ~/.claude/skills/claude-starter
```

**O que inclui:**
- 40 skills cobrindo: código, testes, docs, git, CI/CD, segurança, performance, debugging
- Formato TOON para compressão de context window
- Templates de CLAUDE.md otimizados

**⚠️ Nota:** Este template pode conflitar com skills individuais já instaladas. Revise o conteúdo antes de ativar tudo.

**Repo:** https://github.com/nicobailey/claude-starter (verificar URL atualizada)

---

## Script de Instalação Rápida (Todas as CLI-Only)

```bash
#!/bin/bash
# install-cli-skills.sh
# Instala todas as 5 skills CLI-only de uma vez

set -e

SKILLS_DIR="${HOME}/.claude/skills"
mkdir -p "$SKILLS_DIR"

echo "=== Instalando obra/superpowers ==="
if [ ! -d "$SKILLS_DIR/superpowers" ]; then
  git clone https://github.com/obra/superpowers "$SKILLS_DIR/superpowers"
else
  echo "  → Já existe, pulando..."
fi

echo "=== Instalando Skill Seekers ==="
if [ ! -d "$SKILLS_DIR/skill-seekers" ]; then
  git clone https://github.com/yusufkaraaslan/Skill_Seekers "$SKILLS_DIR/skill-seekers"
else
  echo "  → Já existe, pulando..."
fi

echo "=== Instalando last30days ==="
if [ ! -d "$SKILLS_DIR/last30days" ]; then
  git clone https://github.com/mvanhorn/last30days-skill "$SKILLS_DIR/last30days"
else
  echo "  → Já existe, pulando..."
fi

echo ""
echo "=== Instalação concluída ==="
echo ""
echo "⚠️  Skills que precisam de setup adicional:"
echo "  - Shannon: requer Docker. Instale via: npx skills add unicodeveloper/shannon"
echo "  - last30days: configure OPENAI_API_KEY e XAI_API_KEY"
echo "  - claude-starter: revise antes de ativar (pode conflitar com skills existentes)"
echo ""
echo "✅ Para verificar, abra Claude Code e tente: /brainstorm"
```

---

## Resumo de Compatibilidade

| Skill | Claude.ai (web) | Claude Code (CLI) | Observação |
|-------|----------------|-------------------|------------|
| obra/superpowers | ❌ | ✅ | Plugin com 20+ sub-skills |
| Shannon | ❌ | ✅ | Requer Docker |
| Skill Seekers | ❌ | ✅ | Requer Python + scraping |
| last30days | ❌ | ✅ | Requer API keys externas |
| claude-starter | ❌ | ✅ | Template completo com 40 skills |
