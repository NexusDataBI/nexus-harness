---
name: aws-skills
description: Use when working with AWS services, CDK infrastructure, serverless architectures, Lambda functions, or cloud cost optimization. Trigger on mentions of AWS, CDK, CloudFormation, Lambda, S3, DynamoDB, API Gateway, ECS, EKS, RDS, SQS, SNS, EventBridge, Step Functions, IAM, CloudFront, Route53, or any AWS service. Also trigger on cloud architecture decisions, serverless patterns, infrastructure as code, or AWS cost concerns.
---

# AWS Skills — CDK, Serverless & Cost Optimization

## Purpose
Guide AWS development with CDK best practices, serverless/event-driven patterns, and proactive cost optimization. Every infrastructure decision should consider cost, security, scalability, and operational complexity.

## CDK Best Practices

### Project Structure
```
infra/
├── bin/
│   └── app.ts                 # CDK app entry point
├── lib/
│   ├── stacks/
│   │   ├── network-stack.ts   # VPC, subnets, security groups
│   │   ├── database-stack.ts  # RDS, DynamoDB tables
│   │   ├── api-stack.ts       # API Gateway, Lambda functions
│   │   └── monitoring-stack.ts # CloudWatch, alarms, dashboards
│   ├── constructs/
│   │   ├── secure-bucket.ts   # Reusable S3 with encryption
│   │   └── api-lambda.ts      # Lambda with standard config
│   └── config/
│       ├── dev.ts
│       ├── staging.ts
│       └── prod.ts
├── test/
│   └── stacks/
├── cdk.json
└── tsconfig.json
```

### CDK Golden Rules
1. **One stack per domain/responsibility.** Don't create a mega-stack.
2. **Use constructs for reuse.** Extract common patterns into L3 constructs.
3. **Environment-specific config.** Never hardcode account IDs or regions.
4. **Tag everything.** Cost allocation, ownership, environment.
5. **Use `RemovalPolicy.RETAIN`** for production databases and S3 buckets.
6. **Never use `*` in IAM policies.** Principle of least privilege, always.

### Essential CDK Patterns

```typescript
// Secure S3 Bucket (reusable construct)
export class SecureBucket extends Construct {
  public readonly bucket: s3.Bucket;
  
  constructor(scope: Construct, id: string, props?: SecureBucketProps) {
    super(scope, id);
    
    this.bucket = new s3.Bucket(this, 'Bucket', {
      encryption: s3.BucketEncryption.S3_MANAGED,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      enforceSSL: true,
      versioned: true,
      removalPolicy: props?.isProd 
        ? cdk.RemovalPolicy.RETAIN 
        : cdk.RemovalPolicy.DESTROY,
      autoDeleteObjects: !props?.isProd,
      lifecycleRules: [{
        expiration: cdk.Duration.days(props?.retentionDays ?? 90),
        transitions: [{
          storageClass: s3.StorageClass.INFREQUENT_ACCESS,
          transitionAfter: cdk.Duration.days(30),
        }],
      }],
    });
  }
}
```

## Serverless Architecture Patterns

### Event-Driven Pattern
```
API Gateway → Lambda → SQS → Lambda (processor) → DynamoDB
                                    ↓
                              Dead Letter Queue → CloudWatch Alarm
```

### Key Principles
1. **Think in events, not requests.** Decouple producers from consumers.
2. **Use SQS between services.** Absorbs spikes, enables retries, prevents cascading failures.
3. **DLQ on everything.** Every queue and Lambda needs a Dead Letter Queue.
4. **Idempotency everywhere.** Events may be delivered more than once.
5. **Lambda timeout < SQS visibility timeout.** Prevent duplicate processing.

### Lambda Best Practices
```typescript
// Lambda with proper configuration
const handler = new lambda.Function(this, 'Handler', {
  runtime: lambda.Runtime.NODEJS_20_X,
  handler: 'index.handler',
  code: lambda.Code.fromAsset('lambda/handler'),
  memorySize: 256,            // Right-size based on profiling
  timeout: cdk.Duration.seconds(30),  // Always set explicit timeout
  environment: {
    TABLE_NAME: table.tableName,
    POWERTOOLS_SERVICE_NAME: 'my-service',
    LOG_LEVEL: 'INFO',
  },
  tracing: lambda.Tracing.ACTIVE,  // X-Ray tracing
  insightsVersion: lambda.LambdaInsightsVersion.VERSION_1_0_229_0,
  reservedConcurrentExecutions: 100,  // Prevent runaway scaling
});

// Minimal permissions
table.grantReadWriteData(handler);
// NOT: handler.addToRolePolicy(new iam.PolicyStatement({ actions: ['*'], resources: ['*'] }))
```

## Cost Optimization Checklist

### Immediate Wins (Check First)
- [ ] **Unused resources:** EC2 instances running 24/7 with <5% CPU? Stop/terminate them.
- [ ] **Oversized instances:** RDS db.r5.xlarge for a 2GB database? Downsize.
- [ ] **Missing lifecycle policies:** S3 buckets growing indefinitely? Add transitions to IA/Glacier.
- [ ] **NAT Gateway data transfer:** Each GB costs $0.045. Use VPC endpoints for AWS services.
- [ ] **Unused EBS volumes:** Detached volumes still cost money. Delete or snapshot.
- [ ] **CloudWatch Logs retention:** Default is forever. Set retention policies (30/90 days).

### Architecture-Level Savings
| Instead of... | Consider... | Savings |
|--------------|-------------|---------|
| ALB + EC2 always-on | API Gateway + Lambda | Pay per request, not per hour |
| RDS Multi-AZ for dev | RDS Single-AZ or Aurora Serverless v2 | 50%+ for dev environments |
| ElastiCache for simple caching | DynamoDB DAX or Lambda edge caching | Depends on pattern |
| SQS polling with Lambda | SQS event source mapping (built-in) | Fewer Lambda invocations |
| Separate CloudFront per API | Single distribution with behaviors | Simpler, often cheaper |
| Provisioned DynamoDB capacity | On-demand for variable workloads | No over-provisioning |

### Monitoring Costs
```typescript
// Budget alarm in CDK
new budgets.CfnBudget(this, 'MonthlyBudget', {
  budget: {
    budgetName: 'monthly-budget',
    budgetLimit: { amount: 500, unit: 'USD' },
    budgetType: 'COST',
    timeUnit: 'MONTHLY',
  },
  notificationsWithSubscribers: [{
    notification: {
      comparisonOperator: 'GREATER_THAN',
      threshold: 80,
      thresholdType: 'PERCENTAGE',
      notificationType: 'ACTUAL',
    },
    subscribers: [{
      subscriptionType: 'EMAIL',
      address: 'team@company.com',
    }],
  }],
});
```

## IAM Security Patterns

### Least Privilege Template
```typescript
// ❌ NEVER DO THIS
handler.addToRolePolicy(new iam.PolicyStatement({
  actions: ['s3:*'],
  resources: ['*'],
}));

// ✅ DO THIS — specific actions on specific resources
handler.addToRolePolicy(new iam.PolicyStatement({
  actions: ['s3:GetObject', 's3:PutObject'],
  resources: [bucket.arnForObjects('uploads/*')],
}));
```

## Response Format

When working with AWS:
1. **Architecture Diagram:** ASCII or description of components and data flow
2. **CDK Implementation:** TypeScript CDK code with security and cost considerations
3. **Cost Estimate:** Monthly cost projection for the architecture
4. **Security Review:** IAM permissions, encryption, network access
5. **Operational Concerns:** Monitoring, alerting, scaling limits, disaster recovery
