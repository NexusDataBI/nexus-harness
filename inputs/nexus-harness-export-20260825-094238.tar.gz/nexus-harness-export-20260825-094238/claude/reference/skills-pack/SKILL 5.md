---
name: owasp-security
description: Use when conducting security reviews, code audits, threat modeling, or implementing security controls. Trigger on mentions of OWASP, Top 10, ASVS, security audit, penetration testing, vulnerability assessment, compliance, secure SDLC, threat modeling, or security requirements. Also trigger when designing authentication systems, authorization frameworks, API security, or reviewing infrastructure security configurations.
---

# OWASP Security Skill

## Purpose
Apply OWASP Top 10:2025 and ASVS (Application Security Verification Standard) systematically to code reviews, security audits, and secure development practices.

## OWASP Top 10:2025 — Quick Reference

| # | Category | Key Risk | Primary Defense |
|---|----------|----------|----------------|
| A01 | Broken Access Control | Users acting outside permissions | Deny by default, enforce server-side, test authz on every request |
| A02 | Cryptographic Failures | Sensitive data exposure | Encrypt at rest + transit, strong algorithms, proper key management |
| A03 | Injection | SQLi, XSS, Command Injection | Input validation, parameterized queries, output encoding |
| A04 | Insecure Design | Flawed architecture | Threat modeling, secure design patterns, abuse case testing |
| A05 | Security Misconfiguration | Default credentials, open ports | Hardened configs, automated verification, minimal installs |
| A06 | Vulnerable Components | Known CVEs in dependencies | SCA scanning, dependency updates, SBOM management |
| A07 | Auth & Identity Failures | Broken authentication | MFA, session management, credential stuffing protection |
| A08 | Data Integrity Failures | Untrusted deserialization, CI/CD | Input validation, signed updates, pipeline security |
| A09 | Logging & Monitoring Gaps | No detection of attacks | Centralized logging, alerting, incident response plans |
| A10 | SSRF | Server-side request forgery | Input validation, allowlists, network segmentation |

## Security Code Review Checklist

### Per Language Quick Checks

**JavaScript/TypeScript:**
- [ ] No `eval()`, `Function()`, or `setTimeout(string)`
- [ ] No `innerHTML` or `document.write()` with user data
- [ ] CSP headers configured
- [ ] `npm audit` clean / no known vulnerable deps
- [ ] Prototype pollution prevention (Object.freeze, Map instead of {})
- [ ] No secrets in client-side code or .env committed to repo

**Python:**
- [ ] No `eval()`, `exec()`, `pickle.loads()` with untrusted data
- [ ] No `yaml.load()` — use `yaml.safe_load()`
- [ ] No `os.system()` or `subprocess` with shell=True and user input
- [ ] SQL via ORM or parameterized queries only
- [ ] No `DEBUG=True` in production Django/Flask
- [ ] `bandit` scan clean

**Go:**
- [ ] No `html/template` mixed with `text/template` (XSS risk)
- [ ] Proper error handling (no swallowed errors hiding security issues)
- [ ] Context timeouts on all external calls
- [ ] No `unsafe` package usage without justification
- [ ] `gosec` scan clean

**Java/Kotlin:**
- [ ] No `Runtime.exec()` with user input
- [ ] XML parsers configured to prevent XXE (disable external entities)
- [ ] Deserialization restricted to known classes
- [ ] Spring Security or equivalent framework properly configured
- [ ] No sensitive data in exception messages

### API Security Checklist
- [ ] Authentication required on all non-public endpoints
- [ ] Authorization checked per-resource, not just per-role
- [ ] Rate limiting implemented (per-user and per-IP)
- [ ] Input validation: max lengths, allowed characters, type checking
- [ ] Response filtering: don't return more data than requested
- [ ] CORS restricted to known origins
- [ ] No sensitive data in URL parameters (use request body)
- [ ] API versioning with deprecation policy
- [ ] Request size limits
- [ ] Pagination enforced on list endpoints (prevent data dump)

### Infrastructure Security
- [ ] HTTPS everywhere (HSTS enabled)
- [ ] Database not publicly accessible
- [ ] Secrets in vault/env vars (not in code or config files)
- [ ] Minimal IAM permissions (principle of least privilege)
- [ ] Security groups/firewall rules reviewed
- [ ] Logging enabled for auth events, admin actions, errors
- [ ] Automated dependency vulnerability scanning in CI/CD
- [ ] Container images scanned for vulnerabilities
- [ ] Backups encrypted and tested for restoration

## Threat Modeling Process (STRIDE)

When designing a new feature or system:

1. **Decompose the system:** Draw data flow diagrams showing trust boundaries
2. **Apply STRIDE per component:**

| Threat | Description | Question to Ask |
|--------|-------------|----------------|
| **S**poofing | Pretending to be someone else | How do we verify identity? |
| **T**ampering | Modifying data in transit/at rest | How do we detect changes? |
| **R**epudiation | Denying an action occurred | Do we have audit logs? |
| **I**nformation Disclosure | Accessing unauthorized data | What data could leak? |
| **D**enial of Service | Making the system unavailable | What are the rate limits? |
| **E**levation of Privilege | Gaining unauthorized permissions | What if roles are bypassed? |

3. **Rate each threat:** Likelihood × Impact = Risk Score
4. **Define mitigations:** For each high/critical risk, implement a defense
5. **Verify mitigations:** Write security test cases

## Security Testing Guidance

### Types of Security Tests
- **SAST (Static Analysis):** CodeQL, Semgrep, Bandit, gosec — run in CI
- **DAST (Dynamic Analysis):** OWASP ZAP, Burp Suite — test running application
- **SCA (Software Composition Analysis):** Snyk, Dependabot — check dependencies
- **Secret Scanning:** truffleHog, git-secrets — prevent credential leaks
- **Penetration Testing:** Manual testing of business logic flaws

### Minimum Security Test Cases
For any feature handling sensitive data:
```
- [ ] Test with SQL injection payloads: ' OR 1=1 --, UNION SELECT
- [ ] Test with XSS payloads: <script>alert(1)</script>, javascript:alert(1)
- [ ] Test IDOR: access resource with different user's ID
- [ ] Test missing auth: call endpoint without token
- [ ] Test expired auth: call endpoint with expired token
- [ ] Test privilege escalation: regular user calling admin endpoint
- [ ] Test rate limiting: send 100+ rapid requests
- [ ] Test oversized input: send 10MB payload to text field
- [ ] Test path traversal: ../../etc/passwd in file parameters
```

## Response Format

When conducting security reviews or implementing security controls:

1. **Threat Assessment:** What are the security-relevant aspects of this code/feature?
2. **Vulnerabilities Found:** List each issue with severity (Critical/High/Medium/Low)
3. **Remediation:** Specific code changes to fix each issue
4. **Verification:** How to test that the fix works
5. **Hardening Recommendations:** Additional defenses beyond the minimum fix
