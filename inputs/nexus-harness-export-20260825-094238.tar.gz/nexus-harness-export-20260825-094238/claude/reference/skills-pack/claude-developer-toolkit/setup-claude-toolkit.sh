#!/bin/bash
# =============================================================================
# setup-claude-toolkit.sh
# Instala o toolkit completo de produtividade Claude para desenvolvedores
#
# Uso: chmod +x setup-claude-toolkit.sh && ./setup-claude-toolkit.sh
# =============================================================================

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     Claude Developer Toolkit — Setup Script      ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════╝${NC}"
echo ""

# --- Paths ---
CLAUDE_HOME="${HOME}/.claude"
CLAUDE_SKILLS="${CLAUDE_HOME}/skills"
CLAUDE_COMMANDS="${CLAUDE_HOME}/commands"
CLAUDE_AGENTS="${CLAUDE_HOME}/agents"

# --- Step 1: CLAUDE.md Global ---
echo -e "${GREEN}[1/6] Instalando CLAUDE.md global...${NC}"
mkdir -p "$CLAUDE_HOME"
if [ -f "$CLAUDE_HOME/CLAUDE.md" ]; then
  echo -e "${YELLOW}  → CLAUDE.md já existe. Salvando backup em CLAUDE.md.backup${NC}"
  cp "$CLAUDE_HOME/CLAUDE.md" "$CLAUDE_HOME/CLAUDE.md.backup"
fi
cp claude-md/CLAUDE.md.global "$CLAUDE_HOME/CLAUDE.md"
echo -e "  ✅ Instalado em ${CLAUDE_HOME}/CLAUDE.md"

# --- Step 2: Slash Commands ---
echo -e "${GREEN}[2/6] Instalando slash commands...${NC}"
mkdir -p "$CLAUDE_COMMANDS"
for cmd in slash-commands/*.md; do
  cmd_name=$(basename "$cmd")
  cp "$cmd" "$CLAUDE_COMMANDS/$cmd_name"
  echo -e "  ✅ /${cmd_name%.md}"
done

# --- Step 3: Custom Agents ---
echo -e "${GREEN}[3/6] Instalando custom agents...${NC}"
mkdir -p "$CLAUDE_AGENTS"
for agent in agents/*.md; do
  agent_name=$(basename "$agent")
  cp "$agent" "$CLAUDE_AGENTS/$agent_name"
  echo -e "  ✅ ${agent_name%.md}"
done

# --- Step 4: Hooks ---
echo -e "${GREEN}[4/6] Instalando hooks...${NC}"
if [ -f "$CLAUDE_HOME/hooks.json" ]; then
  echo -e "${YELLOW}  → hooks.json já existe. Salvando backup em hooks.json.backup${NC}"
  cp "$CLAUDE_HOME/hooks.json" "$CLAUDE_HOME/hooks.json.backup"
fi
cp hooks/hooks.json "$CLAUDE_HOME/hooks.json"
echo -e "  ✅ Hooks instalados (auto-format + comando destrutivo bloqueado)"

# --- Step 5: Skills (SKILL.md files for Claude Code) ---
echo -e "${GREEN}[5/6] Instalando skills locais...${NC}"
mkdir -p "$CLAUDE_SKILLS"
SKILLS_SOURCE="../skills-output"  # Ajuste este path se necessário
if [ -d "$SKILLS_SOURCE" ]; then
  for dir in "$SKILLS_SOURCE"/0*; do
    if [ -d "$dir" ] && [ -f "$dir/SKILL.md" ]; then
      skill_name=$(basename "$dir" | sed 's/^[0-9]*-//')
      mkdir -p "$CLAUDE_SKILLS/$skill_name"
      cp "$dir/SKILL.md" "$CLAUDE_SKILLS/$skill_name/"
      echo -e "  ✅ $skill_name"
    fi
  done
else
  echo -e "${YELLOW}  → Diretório de skills não encontrado. Copie manualmente os SKILL.md para ${CLAUDE_SKILLS}/${NC}"
fi

# --- Step 6: Community Skills (git clone) ---
echo -e "${GREEN}[6/6] Instalando skills da comunidade...${NC}"

if command -v git &> /dev/null; then
  # obra/superpowers
  if [ ! -d "$CLAUDE_SKILLS/superpowers" ]; then
    echo -e "  → Clonando obra/superpowers..."
    git clone --depth 1 https://github.com/obra/superpowers "$CLAUDE_SKILLS/superpowers" 2>/dev/null && \
      echo -e "  ✅ superpowers" || \
      echo -e "${YELLOW}  ⚠️ Falha ao clonar superpowers (verifique conexão)${NC}"
  else
    echo -e "  → superpowers já existe, atualizando..."
    cd "$CLAUDE_SKILLS/superpowers" && git pull --quiet 2>/dev/null && cd - > /dev/null
    echo -e "  ✅ superpowers (atualizado)"
  fi
else
  echo -e "${YELLOW}  ⚠️ git não encontrado. Instale git para clonar skills da comunidade.${NC}"
fi

# --- Summary ---
echo ""
echo -e "${BLUE}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║              Setup Concluído!                    ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "O que foi instalado:"
echo -e "  ${GREEN}✅${NC} CLAUDE.md global           → ${CLAUDE_HOME}/CLAUDE.md"
echo -e "  ${GREEN}✅${NC} 6 Slash commands           → ${CLAUDE_COMMANDS}/"
echo -e "  ${GREEN}✅${NC} 2 Custom agents            → ${CLAUDE_AGENTS}/"
echo -e "  ${GREEN}✅${NC} Hooks (format + safety)    → ${CLAUDE_HOME}/hooks.json"
echo -e "  ${GREEN}✅${NC} 12 Skills (SKILL.md)       → ${CLAUDE_SKILLS}/"
echo -e "  ${GREEN}✅${NC} superpowers (community)    → ${CLAUDE_SKILLS}/superpowers/"
echo ""
echo -e "${YELLOW}Próximos passos:${NC}"
echo -e "  1. Abra Claude Code e teste: /commit, /review, /plan"
echo -e "  2. Configure MCP servers: claude mcp add context7 --transport http https://mcp.context7.com/mcp"
echo -e "  3. Configure GitHub MCP: claude mcp add github -- npx -y @modelcontextprotocol/server-github"
echo -e "     (necessário: export GITHUB_TOKEN=seu-token-aqui)"
echo -e "  4. Para Claude.ai: faça upload dos ZIPs em Settings → Customize → Skills"
echo -e "  5. Cole o anti-sycophancy prompt nas Custom Instructions do seu Claude Project"
echo ""
echo -e "${YELLOW}Skills CLI-only que precisam de setup adicional:${NC}"
echo -e "  - Shannon (pentest): npx skills add unicodeveloper/shannon (requer Docker)"
echo -e "  - last30days: git clone + OPENAI_API_KEY + XAI_API_KEY"
echo -e "  - Veja INSTALL-CLI-SKILLS.md para detalhes"
