---
description: Code review focado em bugs, segurança e qualidade
allowed-tools: Read, Grep, Glob, Bash
---

Faça um code review rigoroso das mudanças atuais.

```bash
!git diff --cached --name-only 2>/dev/null || git diff --name-only
```

```bash
!git diff --cached 2>/dev/null || git diff
```

## Processo de Review

### 1. Visão Geral
- Quais arquivos foram modificados e por quê?
- A mudança é coesa (faz UMA coisa) ou mistura concerns?

### 2. Bugs & Lógica (PRIORIDADE MÁXIMA)
- Há erros lógicos, off-by-one, null/undefined não tratados?
- Race conditions, deadlocks, memory leaks?
- Edge cases não cobertos?
- Inputs não validados?

### 3. Segurança
- SQL injection, XSS, IDOR, SSRF?
- Secrets hardcoded?
- Permissões verificadas em cada endpoint?
- Dados sensíveis em logs?

### 4. Performance
- Queries N+1?
- Operações O(n²) que poderiam ser O(n)?
- Dados carregados desnecessariamente?
- Índices faltando para queries frequentes?

### 5. Manutenibilidade
- Nomes claros e descritivos?
- Funções com responsabilidade única?
- Código duplicado que deveria ser extraído?
- Testes cobrindo os novos caminhos?

## Formato da Resposta

Para cada issue encontrada:
```
🔴 CRÍTICO / 🟡 IMPORTANTE / 🔵 SUGESTÃO

Arquivo: path/to/file.ts:42
Problema: [descrição concisa]
Risco: [o que pode acontecer se não corrigir]
Fix sugerido: [código ou direção]
```

Ao final, dê um veredito: APROVADO ✅ / PRECISA DE AJUSTES ⚠️ / BLOQUEAR 🚫
