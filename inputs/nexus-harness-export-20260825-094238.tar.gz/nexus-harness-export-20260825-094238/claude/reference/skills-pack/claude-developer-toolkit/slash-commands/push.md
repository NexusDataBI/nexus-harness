---
description: Push seguro com verificações pré-push (testes, lint, branch protection)
allowed-tools: Bash, Read
---

Execute push seguro com verificações:

## Pré-checks

1. **Verificar branch atual** (NUNCA push direto na main):
```bash
!git branch --show-current
```

2. **Verificar se há mudanças não commitadas:**
```bash
!git status --short
```

3. **Rodar testes:**
```bash
!pnpm test 2>&1 | tail -20
```

4. **Rodar linter:**
```bash
!pnpm lint 2>&1 | tail -10
```

## Decisão

- Se branch é `main` ou `master`: **BLOQUEAR**. Diga para criar uma feature branch.
- Se há mudanças não commitadas: **AVISAR**. Pergunte se deve commitar primeiro.
- Se testes falharam: **BLOQUEAR**. Mostre os erros e sugira fixes.
- Se lint falhou: **AVISAR**. Ofereça rodar auto-fix.

## Push

Se tudo passar:
```bash
git push origin HEAD
```

Informe o resultado e sugira criar um PR se ainda não existir.
