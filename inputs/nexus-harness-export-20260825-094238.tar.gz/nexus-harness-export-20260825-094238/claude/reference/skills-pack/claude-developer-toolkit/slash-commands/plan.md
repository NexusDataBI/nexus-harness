---
description: Planejamento estruturado antes de implementar — Explore → Plan → Spec → Execute
allowed-tools: Read, Grep, Glob, Bash
argument-hint: descreva a feature ou tarefa a ser planejada
---

Siga o workflow estruturado de planejamento para a tarefa: $ARGUMENTS

## Fase 1: EXPLORE
Explore o codebase para entender o contexto relevante:
- Quais arquivos, módulos e padrões existentes são relevantes?
- Como funcionalidades similares foram implementadas?
- Quais dependências e contratos existem?

Resuma o que encontrou antes de prosseguir.

## Fase 2: PLAN
Proponha 2-3 abordagens começando pela mais simples:

Para cada abordagem:
- **Descrição:** O que muda e como
- **Arquivos afetados:** Lista completa
- **Prós:** Vantagens
- **Contras:** Desvantagens e riscos
- **Estimativa:** Complexidade (baixa/média/alta)

Recomende uma abordagem com justificativa.

## Fase 3: SPEC
Crie um arquivo `plan.md` na raiz do projeto com:

```markdown
# Spec: [Nome da Feature]

## Objetivo
[Uma frase descrevendo o resultado final]

## Abordagem escolhida
[Qual e por quê]

## Requisitos
- [ ] Requisito funcional 1
- [ ] Requisito funcional 2
- [ ] Requisito não-funcional (performance, segurança)

## Milestones
### M1: [Nome] (estimativa: Xh)
- [ ] Tarefa 1 (~5min)
- [ ] Tarefa 2 (~5min)
- [ ] Tarefa 3 (~5min)

### M2: [Nome] (estimativa: Xh)
- [ ] Tarefa 4
- [ ] Tarefa 5

## Edge Cases
- [caso 1]
- [caso 2]

## Riscos
- [risco 1] → mitigação: [...]
- [risco 2] → mitigação: [...]

## Definição de Pronto
- [ ] Todos os testes passando
- [ ] Code review feito
- [ ] Documentação atualizada
```

Salve o arquivo e pergunte se deve começar a execução pelo Milestone 1.
