---
description: Cria Pull Request com descrição estruturada a partir do diff
allowed-tools: Bash, Read, Grep, Glob
---

Crie um Pull Request para a branch atual.

## Coleta de Informações

```bash
!git branch --show-current
```

```bash
!git log main..HEAD --oneline
```

```bash
!git diff main..HEAD --stat
```

## Gerar PR

Com base nos commits e diff, gere:

### Título
Formato: `<type>(<scope>): <descrição>`
Mesmo padrão de Conventional Commits.

### Descrição (template)
```markdown
## O que muda
[Resumo das mudanças em 2-3 frases]

## Por que
[Contexto e motivação]

## Como testar
1. [Passo 1]
2. [Passo 2]
3. [Verificação esperada]

## Checklist
- [ ] Testes adicionados/atualizados
- [ ] Documentação atualizada (se aplicável)
- [ ] Sem secrets hardcoded
- [ ] Self-review feito
- [ ] Funciona em mobile (se UI)

## Screenshots (se UI)
[se aplicável]
```

### Criar o PR via GitHub CLI:
```bash
gh pr create --title "<título>" --body "<descrição>" --base main
```

Se `gh` não estiver disponível, mostre o link direto:
```bash
!echo "https://github.com/$(git remote get-url origin | sed 's/.*github.com[:/]//' | sed 's/.git$//')/compare/main...$(git branch --show-current)"
```
