---
description: Gera commit message usando Conventional Commits a partir do diff atual
allowed-tools: Bash, Read, Glob, Grep
---

Analise as mudanças staged (ou todas as mudanças se nada estiver staged):

```bash
!git diff --cached --stat
```

```bash
!git diff --cached
```

Se não houver mudanças staged, analise o diff não-staged:
```bash
!git diff --stat
```

Com base no diff acima, gere uma commit message seguindo Conventional Commits:

## Formato
```
<type>(<scope>): <descrição curta em inglês>

<corpo opcional: o que mudou e por quê>

<footer opcional: breaking changes, issues fechadas>
```

## Types
- `feat`: Nova funcionalidade
- `fix`: Correção de bug
- `refactor`: Refatoração sem mudar comportamento
- `test`: Adição/modificação de testes
- `docs`: Documentação
- `style`: Formatação (sem mudança de lógica)
- `chore`: Tarefas de manutenção, deps, CI
- `perf`: Melhoria de performance

## Regras
- Descrição curta em inglês, imperativo, máximo 72 caracteres
- Scope é o módulo/área afetada (auth, api, db, ui, etc.)
- Se houver mudanças em múltiplas áreas, use o scope mais significativo
- Breaking changes: adicione `BREAKING CHANGE:` no footer
- Se o diff for grande (>10 arquivos), agrupe as mudanças no corpo

Apresente a commit message sugerida e pergunte se devo executar o commit.
