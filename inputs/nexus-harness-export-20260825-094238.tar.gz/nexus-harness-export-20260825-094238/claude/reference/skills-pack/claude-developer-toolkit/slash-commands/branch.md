---
description: Cria feature branch com nome padronizado e setup inicial
allowed-tools: Bash
argument-hint: descrição curta da feature (ex: "add dark mode")
---

Crie uma feature branch para: $ARGUMENTS

## Processo

1. Garanta que estamos na branch mais atualizada:
```bash
git checkout main && git pull origin main
```

2. Crie a branch com nome padronizado:
- Formato: `feat/descricao-kebab-case` ou `fix/descricao-kebab-case`
- Máximo 50 caracteres no nome
- Sem caracteres especiais

3. Faça checkout da nova branch

4. Confirme o resultado:
```bash
git branch --show-current
```

Informe o nome da branch criada e que está pronta para trabalho.
