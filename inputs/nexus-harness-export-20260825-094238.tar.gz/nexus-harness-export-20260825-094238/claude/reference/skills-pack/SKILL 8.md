---
name: content-research-writer
description: Use when creating long-form content that requires research, citations, and structured writing — such as blog posts, technical articles, reports, whitepapers, case studies, or documentation. Trigger on mentions of writing articles, blog posts, technical content, research summaries, content with sources, or any request that involves both researching a topic and producing written content about it. Also trigger when the user wants to improve hooks, outlines, or iterate on written sections.
---

# Content Research Writer

## Purpose
Produce high-quality, research-backed written content through a structured workflow: research → outline → draft → iterate. Every claim should be supportable, every section should serve a purpose, and the final output should be publication-ready.

## Workflow

### Phase 1: Research & Discovery
1. **Clarify the brief:** Audience, goal, tone, length, publication channel
2. **Research the topic:** Gather facts, data points, expert opinions, counter-arguments
3. **Identify the angle:** What's the unique perspective? What's NOT being said elsewhere?
4. **Collect evidence:** Statistics, case studies, examples, quotes (with sources)

### Phase 2: Structure & Outline
1. **Write the thesis:** One sentence that captures the core argument
2. **Create the outline:**
   ```
   ## Working Title: [Compelling, specific title]
   
   ### Hook (first 2-3 sentences)
   - [What grabs attention? A surprising fact? A relatable problem?]
   
   ### Section 1: [Setup — establish the problem/context]
   - Key point A (supported by: [source])
   - Key point B (supported by: [source])
   
   ### Section 2: [Development — the meat of the argument]
   - Key point C (supported by: [data/example])
   - Key point D (supported by: [case study])
   
   ### Section 3: [Resolution — what to do about it]
   - Actionable takeaway 1
   - Actionable takeaway 2
   
   ### Conclusion
   - [Circle back to the hook, reinforce the thesis]
   
   ### Sources
   - [List all references]
   ```
3. **Review the outline with the user** before drafting

### Phase 3: Drafting
1. **Write section by section,** not all at once
2. **Each section should:**
   - Open with a transition from the previous section
   - Make ONE clear point
   - Support it with evidence (data, examples, expert opinion)
   - Close with a connection to the next section
3. **Apply the "so what?" test** to every paragraph — if the reader can ask "so what?", the paragraph needs work

### Phase 4: Revision
1. **First pass — Structure:** Does the argument flow logically? Are sections in the right order?
2. **Second pass — Clarity:** Can every sentence be simplified? Remove jargon without losing precision.
3. **Third pass — Evidence:** Is every claim supported? Are sources credible?
4. **Fourth pass — Engagement:** Is the hook strong? Are there boring stretches? Would YOU keep reading?
5. **Final pass — Polish:** Grammar, formatting, metadata (title, meta description, tags)

## Writing Quality Checklist

### Hook Strength
- [ ] First sentence creates curiosity or stakes
- [ ] Reader knows within 3 sentences what this content is about and why it matters to THEM
- [ ] No generic openings ("In today's world...", "It's no secret that...")

### Structure
- [ ] Each section has ONE main idea
- [ ] Sections build on each other (not just a list of loosely related points)
- [ ] Transitions connect sections logically
- [ ] Subheadings are specific (not "Overview" or "Introduction")

### Evidence & Credibility
- [ ] Major claims have supporting data or examples
- [ ] Sources are credible and recent
- [ ] Counter-arguments are acknowledged (shows intellectual honesty)
- [ ] Technical accuracy verified

### Readability
- [ ] Sentences average 15-20 words (vary length for rhythm)
- [ ] One idea per paragraph
- [ ] Active voice dominant (not "it was found that...")
- [ ] Technical terms explained on first use
- [ ] Formatting aids scanning: subheadings, bold key phrases, short paragraphs

### SEO (if applicable)
- [ ] Primary keyword in title, H1, first paragraph
- [ ] Natural keyword usage (not stuffed)
- [ ] Meta description compelling and under 160 characters
- [ ] Internal/external links where relevant
- [ ] Alt text on images

## Content Types & Formats

| Type | Structure | Length | Tone |
|------|-----------|--------|------|
| Blog post | Hook → Problem → Solution → CTA | 1,000-2,500 words | Conversational |
| Technical tutorial | Overview → Steps → Troubleshooting | 1,500-4,000 words | Instructional, clear |
| Case study | Challenge → Approach → Results → Learnings | 1,000-2,000 words | Professional, data-driven |
| Whitepaper | Executive summary → Analysis → Recommendations | 3,000-8,000 words | Formal, authoritative |
| Newsletter | TL;DR → 3-5 curated items with commentary | 500-1,000 words | Personal, opinionated |

## Response Format

When creating content:
1. **Confirm the brief** (audience, goal, format, length)
2. **Present the outline** with thesis and section summaries
3. **Draft section by section,** checking in between
4. **Deliver the final piece** with metadata (title, description, tags, sources)
