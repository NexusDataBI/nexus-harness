#!/bin/bash
# install-cli-skills.sh — Instala skills CLI-only para Claude Code
set -e

SKILLS_DIR="${HOME}/.claude/skills"
mkdir -p "$SKILLS_DIR"

echo "=== Instalando obra/superpowers ==="
if [ ! -d "$SKILLS_DIR/superpowers" ]; then
  git clone https://github.com/obra/superpowers "$SKILLS_DIR/superpowers"
  echo "  ✅ Instalado"
else
  echo "  → Já existe, atualizando..."
  cd "$SKILLS_DIR/superpowers" && git pull && cd -
fi

echo "=== Instalando Skill Seekers ==="
if [ ! -d "$SKILLS_DIR/skill-seekers" ]; then
  git clone https://github.com/yusufkaraaslan/Skill_Seekers "$SKILLS_DIR/skill-seekers"
  echo "  ✅ Instalado"
else
  echo "  → Já existe, atualizando..."
  cd "$SKILLS_DIR/skill-seekers" && git pull && cd -
fi

echo "=== Instalando last30days ==="
if [ ! -d "$SKILLS_DIR/last30days" ]; then
  git clone https://github.com/mvanhorn/last30days-skill "$SKILLS_DIR/last30days"
  echo "  ✅ Instalado"
else
  echo "  → Já existe, atualizando..."
  cd "$SKILLS_DIR/last30days" && git pull && cd -
fi

echo ""
echo "=== Concluído ==="
echo "⚠️  Shannon: instale via 'npx skills add unicodeveloper/shannon' (requer Docker)"
echo "⚠️  last30days: configure OPENAI_API_KEY e XAI_API_KEY"
