---
name: webapp-testing
description: Use when testing web applications, verifying frontend functionality, debugging UI behavior, capturing screenshots, or automating browser interactions. Trigger on mentions of Playwright, browser testing, E2E tests, end-to-end tests, UI testing, screenshot comparison, visual regression, form testing, navigation testing, or when the user wants to verify a web application works correctly.
---

# Webapp Testing — Playwright Automation

## Purpose
Test and validate web applications using Playwright for UI verification, debugging, and automated quality assurance.

## Setup

```bash
# Install Playwright
npm init playwright@latest
# or
pip install playwright
playwright install
```

### Project Structure
```
tests/
├── e2e/
│   ├── auth.spec.ts       # Login, registration, password reset
│   ├── dashboard.spec.ts  # Main app functionality
│   └── settings.spec.ts   # User settings
├── fixtures/
│   └── test-data.ts       # Shared test data
├── pages/                 # Page Object Model
│   ├── login.page.ts
│   └── dashboard.page.ts
└── playwright.config.ts
```

## Essential Patterns

### Page Object Model (Recommended)
```typescript
// pages/login.page.ts
export class LoginPage {
  constructor(private page: Page) {}

  async goto() {
    await this.page.goto('/login');
  }

  async login(email: string, password: string) {
    await this.page.fill('[data-testid="email"]', email);
    await this.page.fill('[data-testid="password"]', password);
    await this.page.click('[data-testid="login-button"]');
  }

  async expectError(message: string) {
    await expect(this.page.locator('[data-testid="error-message"]'))
      .toHaveText(message);
  }

  async expectRedirectToDashboard() {
    await expect(this.page).toHaveURL('/dashboard');
  }
}
```

### Test Structure
```typescript
// e2e/auth.spec.ts
import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/login.page';

test.describe('Authentication', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.goto();
  });

  test('successful login redirects to dashboard', async () => {
    await loginPage.login('user@test.com', 'validpassword');
    await loginPage.expectRedirectToDashboard();
  });

  test('invalid credentials show error', async () => {
    await loginPage.login('user@test.com', 'wrongpassword');
    await loginPage.expectError('Invalid email or password');
  });

  test('empty form shows validation errors', async ({ page }) => {
    await page.click('[data-testid="login-button"]');
    await expect(page.locator('[data-testid="email-error"]'))
      .toBeVisible();
  });
});
```

### Visual Regression Testing
```typescript
test('dashboard matches snapshot', async ({ page }) => {
  await page.goto('/dashboard');
  await page.waitForLoadState('networkidle');
  await expect(page).toHaveScreenshot('dashboard.png', {
    maxDiffPixelRatio: 0.01,
  });
});
```

### API Mocking for Isolated Tests
```typescript
test('handles API error gracefully', async ({ page }) => {
  // Mock the API to return an error
  await page.route('**/api/data', route => {
    route.fulfill({
      status: 500,
      body: JSON.stringify({ error: 'Internal Server Error' }),
    });
  });

  await page.goto('/dashboard');
  await expect(page.locator('[data-testid="error-banner"]'))
    .toContainText('Something went wrong');
});
```

### Mobile & Responsive Testing
```typescript
// playwright.config.ts
export default defineConfig({
  projects: [
    { name: 'Desktop Chrome', use: { ...devices['Desktop Chrome'] } },
    { name: 'Mobile Safari', use: { ...devices['iPhone 14'] } },
    { name: 'Tablet', use: { viewport: { width: 768, height: 1024 } } },
  ],
});
```

## Debugging Techniques

```bash
# Run with headed browser (see what's happening)
npx playwright test --headed

# Run with debug mode (step through)
npx playwright test --debug

# Generate tests by recording actions
npx playwright codegen http://localhost:3000

# View test report
npx playwright show-report
```

## Test Checklist for Web Apps

- [ ] Auth flow: login, logout, session expiry, password reset
- [ ] Navigation: all routes reachable, back/forward works, deep links
- [ ] Forms: validation, submission, error states, empty states
- [ ] Data display: tables, lists, pagination, sorting, filtering
- [ ] Responsive: mobile, tablet, desktop breakpoints
- [ ] Accessibility: keyboard navigation, screen reader labels, focus management
- [ ] Error handling: network failures, 404 pages, API errors
- [ ] Performance: page load time, interaction responsiveness
