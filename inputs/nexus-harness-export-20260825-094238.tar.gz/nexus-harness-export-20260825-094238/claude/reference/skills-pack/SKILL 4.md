---
name: changelog-generator
description: Use when the user asks to generate release notes, changelogs, or version summaries from git history. Trigger on mentions of changelog, release notes, CHANGELOG.md, version bump, "what changed", git log summary, or preparing a release. Also trigger when the user asks to document changes between branches, tags, or commits for stakeholders.
---

# Changelog Generator Skill

## Purpose
Transform raw git history into professional, user-facing changelogs. Technical commits become readable release notes that stakeholders, users, and team members can understand.

## Changelog Format (Keep a Changelog Standard)

Follow the [Keep a Changelog](https://keepachangelog.com/) convention:

```markdown
# Changelog

## [1.2.0] - 2026-03-23

### Added
- User profile avatar upload with automatic resizing to 256x256px
- Dark mode toggle in settings (persists across sessions)
- API rate limiting: 100 requests/minute per user

### Changed
- Dashboard load time reduced from 3.2s to 0.8s via query optimization
- Password requirements now enforce 12+ characters minimum
- Upgraded React from 18.2 to 19.0

### Fixed
- Login form no longer submits on Enter when fields are empty
- CSV export now correctly handles unicode characters in filenames
- Memory leak in WebSocket connection on mobile browsers

### Deprecated
- `/api/v1/users` endpoint — use `/api/v2/users` instead (removal in v2.0)

### Removed
- Legacy PDF report generator (replaced by new reporting module in v1.1)

### Security
- Patched XSS vulnerability in markdown preview component
- Updated jsonwebtoken to 9.x to resolve CVE-2024-XXXXX
```

## Workflow

### Step 1: Identify the range
Determine what commits to analyze:
- Between two tags: `git log v1.1.0..v1.2.0 --oneline`
- Between two branches: `git log main..release/1.2 --oneline`
- Since last release: `git log $(git describe --tags --abbrev=0)..HEAD --oneline`

### Step 2: Categorize commits
Map each commit to a changelog category using Conventional Commits prefixes:

| Prefix | Category | User-facing? |
|--------|----------|-------------|
| `feat:` | Added | ✅ Yes |
| `fix:` | Fixed | ✅ Yes |
| `perf:` | Changed (performance) | ✅ Yes |
| `security:` / `vuln:` | Security | ✅ Yes |
| `deprecate:` | Deprecated | ✅ Yes |
| `remove:` | Removed | ✅ Yes |
| `refactor:` | — | ❌ Skip (internal) |
| `test:` | — | ❌ Skip (internal) |
| `docs:` | — | ❌ Skip (unless user-facing docs) |
| `chore:` | — | ❌ Skip (internal) |
| `ci:` | — | ❌ Skip (internal) |
| `style:` | — | ❌ Skip (internal) |

### Step 3: Rewrite for humans
Transform technical commits into user-friendly descriptions:

**BAD (raw commit):** `fix: resolve race condition in useEffect cleanup for ws connections`
**GOOD (user-facing):** `Fixed intermittent disconnection issues on mobile browsers`

**BAD:** `feat: impl RBAC middleware w/ JWT claims validation`
**GOOD:** `Added role-based access control — admins can now manage team permissions`

**Rules for rewriting:**
- Focus on WHAT changed for the user, not HOW it was implemented
- Use active voice: "Added..." not "A feature was added..."
- Be specific: "Reduced page load by 60%" not "Improved performance"
- Include context when helpful: "Fixed CSV export for files with special characters"
- Group related changes: 5 commits about the same feature = 1 changelog entry

### Step 4: Add context for breaking changes
If any change breaks backward compatibility, call it out prominently:

```markdown
### ⚠️ Breaking Changes
- API authentication now requires Bearer [REDACTED] header (previously accepted query parameter)
  - **Migration:** Replace `?token=xxx` with `Authorization: Bearer [REDACTED]` header
  - **Deadline:** Query parameter support will be removed in v2.1 (June 2026)
```

### Step 5: Add metadata
- Version number (follow SemVer: MAJOR.MINOR.PATCH)
- Release date
- Link to full diff: `[1.2.0]: https://github.com/org/repo/compare/v1.1.0...v1.2.0`
- Contributors (optional but appreciated)

## SemVer Decision Guide

| Type of Change | Version Bump | Example |
|---------------|-------------|---------|
| Breaking API change | MAJOR (X.0.0) | Remove endpoint, change response format |
| New feature (backward compatible) | MINOR (0.X.0) | Add endpoint, new config option |
| Bug fix (backward compatible) | PATCH (0.0.X) | Fix calculation error, UI glitch |

## Output Formats

Produce changelogs in the format most useful for the context:
- **CHANGELOG.md** — Full Markdown file for the repository
- **GitHub Release Notes** — Formatted for GitHub Releases with emoji headers
- **Slack/Team Update** — Condensed summary for team channels
- **User-Facing Blog Post** — Narrative format for product updates

Always ask the user which format they need if not specified.
