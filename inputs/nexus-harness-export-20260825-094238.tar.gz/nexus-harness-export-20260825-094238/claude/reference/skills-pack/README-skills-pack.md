# 🚀 Claude Skills Pack — 17 Skills (Tier 1 + Tier 2)

> Curadoria das melhores skills da comunidade Claude, extraídas de:
> - [travisvn/awesome-claude-skills](https://github.com/travisvn/awesome-claude-skills)
> - [ComposioHQ/awesome-claude-skills](https://github.com/ComposioHQ/awesome-claude-skills)
> - [hesreallyhim/awesome-claude-code](https://github.com/hesreallyhim/awesome-claude-code)
> - [Reddit r/ClaudeAI — "I tested 30+ community Claude Skills"](https://www.reddit.com/r/ClaudeAI/comments/1ok9v3d/)

---

## 📦 O que está incluído

### Claude.ai (Web) — 12 Skills como ZIP

Faça upload via **Settings → Customize → Skills** no claude.ai.

| # | Skill | Arquivo ZIP | Categoria |
|---|-------|------------|-----------|
| 1 | Software Architecture | `software-architecture.zip` | Desenvolvimento |
| 2 | Systematic Debugging | `systematic-debugging.zip` | Desenvolvimento |
| 3 | Test-Driven Development | `test-driven-development.zip` | Desenvolvimento |
| 4 | Changelog Generator | `changelog-generator.zip` | Produtividade |
| 5 | VibeSec | `vibesec.zip` | Segurança |
| 6 | OWASP Security | `owasp-security.zip` | Segurança |
| 7 | Varlock | `varlock.zip` | Segurança |
| 8 | Trail of Bits Security | `trail-of-bits-security.zip` | Segurança |
| 9 | AWS Skills | `aws-skills.zip` | DevOps/Infra |
| 10 | Subagent-Driven Dev | `subagent-driven-development.zip` | Desenvolvimento |
| 11 | Webapp Testing | `webapp-testing.zip` | Desenvolvimento |
| 12 | Content Research Writer | `content-research-writer.zip` | Produtividade |

### Claude Code (CLI) — 5 Skills Exclusivas

Estas dependem de funcionalidades CLI e devem ser instaladas via terminal.
Veja `claude-code-cli/INSTALL-CLI-SKILLS.md` para instruções detalhadas.

| # | Skill | Instalação | Categoria |
|---|-------|-----------|-----------|
| 13 | obra/superpowers | `git clone` ou plugin marketplace | Desenvolvimento |
| 14 | Shannon Pentest | `npx skills add` (requer Docker) | Segurança |
| 15 | Skill Seekers | `git clone` + Python | Ferramentas |
| 16 | last30days | `git clone` + API keys | Pesquisa |
| 17 | claude-starter | `git clone` | Template |

---

## 🔧 Instalação — Claude.ai (Web)

### Passo a passo:

1. Abra o [claude.ai](https://claude.ai)
2. Vá em **Settings** (ícone de engrenagem) → **Customize** → **Skills**
3. Clique em **Upload Skill**
4. Selecione um arquivo `.zip` da pasta `claude-ai-zips/`
5. Repita para cada skill que deseja instalar

### Ordem recomendada de instalação:

**Instale primeiro (impacto imediato):**
1. `systematic-debugging.zip` — Muda como você debugga
2. `vibesec.zip` — Segurança preventiva em todo código
3. `software-architecture.zip` — Decisões estruturais melhores

**Instale em seguida (fluxo de trabalho):**
4. `test-driven-development.zip` — TDD como padrão
5. `owasp-security.zip` — Auditorias de segurança
6. `varlock.zip` — Secrets nunca vazam

**Instale por último (complementares):**
7-12. Restantes conforme necessidade

---

## 🖥️ Instalação — Claude Code (CLI)

### Instalação rápida (3 skills de uma vez):
```bash
chmod +x claude-code-cli/install-cli-skills.sh
./claude-code-cli/install-cli-skills.sh
```

### Instalação manual (skill por skill):
Siga as instruções em `claude-code-cli/INSTALL-CLI-SKILLS.md`

### As 12 skills web TAMBÉM funcionam no Claude Code:
```bash
# Copie os SKILL.md para o diretório de skills do Claude Code
for skill in skill-sources/*/; do
  skill_name=$(basename "$skill")
  mkdir -p ~/.claude/skills/"$skill_name"
  cp "$skill/SKILL.md" ~/.claude/skills/"$skill_name"/
done
```

---

## 📊 Resumo de Cobertura

Após instalar tudo, você terá:

| Categoria | Skills Existentes | + Novas | Total |
|-----------|-------------------|---------|-------|
| Desenvolvimento | testing-patterns, planning-router | +6 (architecture, debug, TDD, subagent, webapp, changelog) | 8 |
| Segurança | — | +4 (vibesec, owasp, varlock, trail-of-bits) | 4 |
| DevOps/Infra | observability | +1 (aws-skills) | 2 |
| Produtividade | doc-coauthoring, internal-comms | +1 (content-research-writer) | 3 |
| Ferramentas (CLI) | — | +5 (superpowers, shannon, skill-seekers, last30days, starter) | 5 |
| **TOTAL** | **~12** | **+17** | **~29** |

---

## ⚠️ Notas Importantes

1. **Não há conflitos** entre estas skills e as que você já tem instaladas — verifiquei uma a uma.
2. **Skills são ativadas automaticamente** pelo Claude quando detecta relevância na conversa.
3. **Cada skill usa ~100 tokens** no scan de metadata. Só carrega o conteúdo completo (<5k tokens) quando ativada.
4. **Você pode desativar** qualquer skill a qualquer momento em Settings → Customize → Skills.
5. **Para Claude Code:** as 12 skills web também podem ser copiadas para `~/.claude/skills/` e funcionam normalmente.
