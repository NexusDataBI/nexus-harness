# Nexus Harness Export — 2026-08-25

Backup pessoal do harness Cursor + Claude Code + Codex + skills compartilhadas.
Secrets, sessões, caches e plugins baixados **não** entram neste pacote.

Export anterior (sanitizado p/ terceiros, 2026-08-08): `Desktop/claude-cursor-harness-sanitized-20260808-140728`.
Este pacote é o dump **completo para você**, com identidade Nexus/Rubens preservada.

## Layout

```
AGENTS.md                         constituição Cursor/Codex (~/)
README.md
MANIFEST.json
SYMLINK-MAP.json
claude/                           ~/.claude (subset harness)
  CLAUDE.md  agents/  commands/  hooks/  rules/  skills/
  settings.template.json  mcp.template.json  scheduled-tasks/
  token-optimizer/  docs/  reference/  tools/context-mode (sem node_modules)
agents-skills/                    ~/.agents/skills  (fonte compartilhada)
cursor/                           ~/.cursor (subset harness)
  skills/  commands/  USER_RULES.md  mcp.template.json  cli-config.json
codex/                            ~/.codex (subset harness)
  AGENTS.md  agents/  skills/  config.template.toml
harness-sync/                     coordenador Cursor/Claude → Codex
```

## O que NÃO veio

- `auth.json`, `.env`, tokens MCP (redacted nos templates)
- sessões, transcripts, backups, logs, telemetry
- `plugins/cache` e marketplaces baixados
- skills built-in do Cursor (`~/.cursor/skills-cursor`)
- vault Obsidian
- `~/.claude/security/` (venv)
- `node_modules` / `.git` / `__pycache__`

## Restaurar (mesma máquina)

```bash
# Constituição
cp AGENTS.md ~/AGENTS.md
cp claude/CLAUDE.md ~/.claude/CLAUDE.md

# Claude
cp -R claude/agents ~/.claude/
cp -R claude/skills ~/.claude/
cp -R claude/hooks ~/.claude/
cp -R claude/rules ~/.claude/
cp -R claude/commands ~/.claude/
cp -R claude/scheduled-tasks ~/.claude/
chmod +x ~/.claude/hooks/*.sh ~/.claude/statusline-command.sh

# Skills compartilhadas
mkdir -p ~/.agents/skills
cp -R agents-skills/* ~/.agents/skills/

# Cursor
cp cursor/USER_RULES.md  # cole em Settings → Rules
cp -R cursor/skills ~/.cursor/
cp -R cursor/commands ~/.cursor/
# mcp.template.json → ~/.cursor/mcp.json  (recoloque tokens)

# Codex
cp codex/AGENTS.md ~/.codex/AGENTS.md
cp -R codex/agents ~/.codex/
# config.template.toml → merge em ~/.codex/config.toml
```

Settings reais **não** foram copiados crus: use os `*.template.*` e recoloque credenciais.

## Mental model

1. CLAUDE.md / AGENTS.md = constituição (sempre on)
2. rules/ = detalhe sob demanda
3. skills/ = playbooks
4. agents/ = especialistas
5. hooks/ = guardrails
6. harness-sync = publicação Cursor/Claude → Codex
