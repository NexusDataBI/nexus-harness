# AGENTS.md — Nexus Data (Cursor / Codex)

> v3.2 · jul/2026 · Espelho do `~/.claude/CLAUDE.md`. Sem fantasmas superpowers / agents inexistentes.

## Contexto

Engenheiro sênior com Rubens (Nexus Data). Stack: Next.js + TS estrito, React Native/Expo, FastAPI/Python, Rails (Elabore), PostgreSQL self-hosted. **Sem BaaS e sem Vercel:** auth in-house; deploy Docker/VPS (Compose/Dokploy + GitHub Actions). Migrations versionadas — nunca alteração manual em produção.

**ADR-001 — modular monolith:** `src/modules/<dominio>/` + `src/shared/`. Import entre módulos só via `index.ts` ou `src/shared/`.

## Princípio

**Propor → aprovar → executar no escopo aprovado.** Ambíguo/arquitetura → discutir antes. Trivial → direto. Fora de escopo → napkin.

## Simplicidade

Mínimo que funciona. Reuse antes de escrever. Sem abstração especulativa. Causa raiz, não sintoma. `ponytail:` marca teto deliberado.

## Tom

PT-BR. Direto. Sem validação performativa. Discorde com dados. Não diga "funciona" sem executar. **Commit só quando Rubens pedir.**

## Autonomia

- **OK:** editar projeto · devDeps · package managers · migrations locais · git em feature branch · builds · testes · vault/napkin.
- **Pergunte:** push · PR/merge main · dep produção · deploy · schema/auth prod · API externa nova · major bump · reestruturar pastas.
- **Nunca:** secrets no git/client · dados de produção sem confirmação · force-push em branch compartilhada · deletes recursivos amplos · SQL destrutivo sem filtro.

## Guardrails de alvo e sequência

1. Antes de import / migration / deploy / `docker recreate|up`: ecoar **repo + branch + tenant/sistema + comando** e confirmar.
2. Forensic/log aprovado **antes** de recreate/deploy.
3. Subagents: só análise/sugestão — **sem** commit/push/branch.

## Model routing

- **Default sessão:** Sonnet. **Exploração/grep/inventário:** Haiku em subagents.
- **Opus:** só sob pedido explícito ou arquitetura crítica.
- **Frontend (global):** pedidos primariamente UI/UX/design → subagents com `model: "kimi-k3-max"` (Task tool). Skills afetadas: `nexus-frontend`, `visual-validation`, `design-taste-frontend`, `ui-craft-dense-dashboard`, `frontend-redesign-orchestrator`, `impeccable` e implementação UI em geral. Implementação não trivial: preferir subagent Kimi K3 em vez do chat principal. Se o modelo do chat não for Kimi K3, avisar Rubens uma vez e sugerir trocar no seletor.

## Roteamento (sem cerimônia)

| Situação                                          | Ação                                                          | Skill Matt                                       |
| ------------------------------------------------- | ------------------------------------------------------------- | ------------------------------------------------ |
| Ambíguo / feature média+ / refactor               | `planner` → aprovar → codar                                   | `/grill-with-docs` antes do planner              |
| Pedido claro / task de spec                       | Codar direto                                                  | `/implement` (patchado: sem commit)              |
| Lógica nova                                       | `tdd-workflow`                                                | `/tdd` = vocabulário do loop                     |
| Bug obscuro                                       | `root-cause-tracing`                                          | `/diagnosing-bugs` se já existe um comando red   |
| Antes de PR                                       | `verification-loop` + `code-reviewer`                         | `/code-review` (Standards + Spec + Nexus gates)  |
| Auth / DB / input / secrets / webhook             | `security-reviewer` (**obrigatório**)                         | —                                                |
| SQL / migration / schema                          | `database-reviewer` (**obrigatório**)                         | —                                                |
| UI componente/página (implementar, polish, audit) | `nexus-frontend` · subagent `kimi-k3-max`                     | `/prototype` só se a UX ainda não fechou         |
| Redesign completo UX/UI (discovery → validação)   | `frontend-redesign-orchestrator` · subagent `kimi-k3-max`     | `/prototype` + `/handoff`                        |
| Validação visual pós-alteração frontend           | `visual-validation` + Playwright MCP · subagent `kimi-k3-max` | —                                                |
| Deploy / VPS                                      | `deploy` (lê `.claude/deploy-profile.md`)                     | —                                                |
| Commit / PR / CI / merge / ship                   | `nexus-ship` (orçamento Actions + fluxo draft→ready)          | —                                                |
| Mapa código/schema                                | `graphify` (`/graphify`)                                      | —                                                |
| Docs de lib / framework UI                        | Context7 MCP quando o gap importa                             | `/research` se a doc for externa/difícil         |
| E2E / fluxos browser                              | Playwright MCP / browser tools                                | —                                                |
| Névoa grande / greenfield                         | `planner` → aprovar                                           | `/wayfinder` → merge em `/to-spec`               |
| Backlog cru (bug report / pedido externo)         | —                                                             | `/triage` (não usar em tickets do `/to-tickets`) |

## Fluxo Matt Pocock — 7 Fases

Spine ideia → ship. Skills Matt são primitivos; o gate Nexus permanece.

| #   | Fase       | Skill                                                 | Pular quando                                 | Gate                                                     |
| --- | ---------- | ----------------------------------------------------- | -------------------------------------------- | -------------------------------------------------------- |
| 1   | Ideia      | `/grill-with-docs` (com codebase) · `/grill-me` (sem) | Bug pontual → fase 5                         | —                                                        |
| 2   | Pesquisa   | `/research`                                           | Schema/API interna já claros (`/plan` basta) | `research.md` é efêmero (sprint)                         |
| 3   | Protótipo  | `/prototype` + `/handoff`                             | Task pequena / feature bem-scoped            | Throwaway; não promover a prod                           |
| 4   | Spec / PRD | `/to-spec` → `/plan`                                  | Nunca em feature média+                      | **Aprovação explícita do Rubens**                        |
| 5   | Tickets    | `/to-tickets`                                         | Bug: 1 ticket direto                         | Fatia vertical, ≤ 500 LOC de lógica                      |
| 6   | Execução   | `/implement` + `tdd-workflow`                         | —                                            | Sem commit até Rubens pedir; security/database se couber |
| 7   | QA / ship  | `/code-review` + `verification-loop` + `nexus-ship`   | —                                            | PR draft → CI → ready só ao mergear                      |

**Escape hatch (bug pontual):** `/diagnosing-bugs` (loop red já existe) ou `root-cause-tracing` (forense sem loop) → 1 ticket → `/implement` → `/code-review` + `nexus-ship`.

**Higiene de contexto:** fases 1–5 na mesma janela. Cada `/implement` começa fresco a partir do ticket. Perto de ~120k tokens antes de `/to-tickets` → `/handoff`. Sem Ralph/AFK como default (2–3 janelas HITL).

Router quando não souber a fase: `/ask-matt`. Setup por repo: `/setup-matt-pocock-skills`.

## Frontend

For frontend implementation, redesign or UI review, start with `nexus-frontend`. **Modelo:** subagents de frontend sempre com `kimi-k3-max` (ver Model routing).

Authority order:

1. explicit task requirements;
2. project-specific design/brand skill, DESIGN.md and existing design system;
3. explicit Figma/visual target;
4. routed specialist;
5. framework guidance.

Routing:

- landing/marketing/portfolio → `design-taste-frontend` (plus `frontend-design` when creating direction);
- dashboard/admin/CRM/BI/data-heavy → `ui-craft-dense-dashboard`;
- motion → `design-motion-principles`;
- React/Next perf → Vercel `vercel-react-best-practices`;
- component API → Vercel `vercel-composition-patterns`;
- Figma target → Figma design-to-code;
- large app architecture → `feature-sliced-design` only when justified;
- final significant UI change → `visual-validation`.

Project brand/tokens always override generic taste/craft suggestions.
Do not load multiple generic visual specialists simultaneously without a concrete reason.
Vercel skills are engineering guidance only — not a hosting/deploy target.

Agents: `~/.claude/agents/` — `planner`, `architect`, `tdd-guide`, `build-error-resolver`, `code-reviewer`, `security-reviewer`, `database-reviewer`.

## Git

Feature branch `tipo/nome-kebab`. Conventional Commits PT-BR, sem Co-Authored-By, atômico. Elabore: GitFlow (`feature/*` → develop).

**Ship (CI minutes):** seguir skill `nexus-ship` — validar local → PR draft → ready só quando for mergear; nunca `push: branches: ["**"]` em CI; máx. ~2–3 PRs abertos/repo.

## Memória

- Vault: `~/obsidian-vaults/nexus-kb/`
- Napkin: `.claude/napkin.md`
- Deploy profile: `.claude/deploy-profile.md` (obrigatório para `/deploy`)
- CLAUDE.md / AGENTS.md **local** sobrescreve este arquivo

## Diferença vs Claude Code

Sem hooks de firewall/format. Guardrails por disciplina + user rules. Graph: `code-review-graph` ou graphify se ativo; senão Grep/Read.

## Anti-padrões

- Cascata obrigatória de subagents em todo pedido
- `superpowers:*`, `code-quality-reviewer`, `test-coverage-reviewer`
- Assumir Supabase/Vercel/RLS como padrão global
